# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Cappy Pitts, Russell Toris

# Futures
from __future__ import unicode_literals

# Version of the Fetchcore API
API_VERSION = 'v1'

# The default port Fetchcore uses
DEFAULT_PORT = 8000  # TODO: make this 443 since customers will be on the cloud

# The default host Fetchcore uses
DEFAULT_HOST = 'localhost'

# Authentication endpoint for Fetchcore
AUTHENTICATION_ENDPOINT = 'api/%s/auth/login/' % API_VERSION

# Server page size
SERVER_PAGE_SIZE = 20
