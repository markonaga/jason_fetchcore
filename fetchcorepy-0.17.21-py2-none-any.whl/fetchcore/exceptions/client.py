class ConnectionError(Exception):
    pass


class RequestException(Exception):
    def __init__(self, message, url, code, json={}):
        super(RequestException, self).__init__(message)
        self.url = url
        self.code = code
        self.json = json


class BadRequest(RequestException):
    pass


class Unauthorized(RequestException):
    pass


class Forbidden(RequestException):
    pass


class NotFound(RequestException):
    pass


class MethodNotAllowed(RequestException):
    pass


class Conflict(RequestException):
    pass


class InternalServerError(RequestException):
    pass
