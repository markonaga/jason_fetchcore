# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts


# This error is thrown when the user tries to set a property with a value that does not match its resource's schema
class ValidationError(Exception):
    pass


# This error is thrown when the user tries to get a property that has not been set yet
class UndefinedFieldError(Exception):
    pass


# This error is thrown when the user tries to set a property that contains extra keywords for initialization
class KeyWordArgumentError(Exception):
    pass


class UnsupportedOperation(Exception):
    pass


class DoesNotExist(Exception):
    pass
