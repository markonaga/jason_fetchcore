# Copyright 2016 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Russell Toris

# Futures
from __future__ import unicode_literals

# Standard Library
import Queue
import logging
from math import cos, sin

# fetchcore
from fetchcore import __version__
from fetchcore.client.client import DEFAULT_TIMEOUT
from fetchcore.client.http_client import HttpClient
from fetchcore.client.websocket_client import WebSocketClient
from fetchcore.settings import DEFAULT_HOST, DEFAULT_PORT

from fetchcore.definitions import AreaTypes, Shapes
from fetchcore.exceptions import UndefinedFieldError, ConnectionError
import io
from PIL import Image, ImageDraw


class FetchcoreClient(object):
    """
    The main fetchcore client which manages and contains an HTTP client and various WebSocket clients.
    """

    def __init__(self, username, password, host=DEFAULT_HOST, port=DEFAULT_PORT, handle_reconnect=False, ssl=False):
        """Create a new fetchcore client.

        :param username: Username for login.
        :param password: Password for login.
        :param host: Host address of the server.
        :param port: Port to connect to on the server.
        :param ssl: Whether or not to use SSL protocols when connecting clients.
        """

        # Internal clients
        self.ssl = ssl
        self.__http_client = HttpClient(username, password, host, port, handle_reconnect=handle_reconnect, ssl=ssl)
        self.handle_reconnect = handle_reconnect
        self.__websocket_clients = {}
        # Connection information
        self.__password = password

    def __getattr__(self, item):
        """Magic method called only when attempting to access an attribute undefined in the class definition.

        This will allow proxying of method calls first to the *__http_client*, if it exists, and from the superclass
        otherwise.

        :param item: The name of the attribute being accessed.
        :type item: str

        :returns: The requested attribute from either the __http_client or the superclass.
        :raises: AttributeError if the attribute was not found in the __http_client or superclass.

        Example::
            client = FetchcoreClient('user', 'pass')
            client.connect()
            client.get('robots', 14)  # Calls .get() on client.__http_client instead
        """
        if self.__http_client:
            return getattr(self.__http_client, item)
        else:
            return super(FetchcoreClient, self).__getattr__(item)

    @property
    def username(self):
        """Get the username for this client.

        :return: The username for this client.
        """
        return self.http_client.username

    @property
    def is_connected(self):
        return self.__http_client.is_connected and all(ws.is_connected for ws in self.__websocket_clients.values())

    @property
    def host(self):
        """Get the host address for this client.

        :return: The host address for this client.
        """
        return self.http_client.host

    @property
    def port(self):
        """Get the port for this client.

        :return: The port for this client.
        """
        return self.http_client.port

    @property
    def http_client(self):
        """Get the HTTP client for this fetchcore client.

        :return: The HTTP client for this fetchcore client.
        """
        return self.__http_client

    def connect(self, timeout=DEFAULT_TIMEOUT):
        """Connect and authenticate to the server.

        :param timeout: The timeout (in seconds) for the connection.
        :raise: fetchcore.exceptions.ConnectionError Thrown if there is a problem creating communicating with fetchcore.
        """
        was_connected = self.is_connected
        # Connect all fetchcore clients
        self.__http_client.connect()
        self.connect_websocket_clients(timeout)
        # Check the version
        if not was_connected:
            server_version = self.version()
            if __version__[:__version__.rfind('.')] != server_version[:server_version.rfind('.')]:
                logging.warn(
                    "Fetchcore server is version %s and your SDK is version %s, please upgrade to the correct SDK."
                    % (server_version, __version__)
                )

    def connect_websocket_clients(self, timeout=DEFAULT_TIMEOUT):
        # TODO: Comments
        # TODO: Make a bigger for loop and have try-except + logging for different ws clients with unsuccessful connects
        [websocket_client.connect(timeout) for websocket_client in self.__websocket_clients.values()]

    def disconnect(self, timeout=DEFAULT_TIMEOUT):
        """Disconnect and destroy your sessions to the fetchcore server.

        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        # Disconnect all fetchcore clients
        self.__http_client.disconnect(timeout)
        [websocket_client.disconnect(timeout) for websocket_client in self.__websocket_clients.values()]
        self.__websocket_clients = {}

    def reset_auth_tokens(self):
        self.__http_client._auth_token = None
        for websocket_client in self.__websocket_clients.values():
            websocket_client._auth_token = None

    def get_client_for_channel(self, channel):
        """Get the currently-stored websocket client for **channel**.

        :param channel: The channel the desired client is connected to.
        :type channel: str

        :returns: A WebSocketClient instance if one exists for that channel. None otherwise."""
        return self.__websocket_clients.get(channel)

    def subscribe_to_logs(self, callback, timeout=DEFAULT_TIMEOUT):
        """Subscribe to all changes in logs. When a new log is created, the given callback will be called with that log.

        The callback function will get the following:
          * **resource**: The resource object parsed from the stream.
          * **action**: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * **type**: The type of resource (e.g., LOG, or TASK).

        :param callback: The callback function to call when a new log is created.
        :param timeout: The timeout (in seconds) for the connection.
        """
        self.__subscribe('logs', callback, timeout=timeout)

    def unsubscribe_from_logs(self, callbacks=None, timeout=DEFAULT_TIMEOUT):
        """Unsubscribe the given callbacks from the logs stream.

        If called without callbacks, all callbacks are removed.

        :param callbacks: The array of callbacks to unsubscribe from.
        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        self.__unsubscribe('logs', callbacks, timeout=timeout)

    def subscribe_to_tasks(self, callback, robot_name=None, timeout=DEFAULT_TIMEOUT):
        """Subscribe to changes tasks logs. When a new log is created, modified, or deleted, the given callback will be
        called with the task. An option robot name can be given to subscribe to only a specific robot's tasks.

        The callback function will get the following:
          * **resource**: The resource object parsed from the stream.
          * **action**: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * **type**: The type of resource (e.g., LOG, or TASK).

        :param callback: The callback function to call when a task is created, modified, or deleted.
        :param robot_name: An optional robot name subscribe to.
        :param timeout: The timeout (in seconds) for the connection.
        """
        self.__subscribe('tasks', callback, arguments=([robot_name] if robot_name else None), timeout=timeout)

    def unsubscribe_from_tasks(self, callbacks=None, robot_name=None, timeout=DEFAULT_TIMEOUT):
        """Unsubscribe the given callbacks from the tasks stream.

        If called without callbacks, all callbacks are removed.

        :param callbacks: The array of callbacks to unsubscribe from.
        :param robot_name: An optional robot name unsubscribe from.
        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        self.__unsubscribe('tasks', callbacks, arguments=([robot_name] if robot_name else None), timeout=timeout)

    def subscribe_to_robots(self, callback, robot_name=None, timeout=DEFAULT_TIMEOUT):
        """Subscribe to robot changes. When a new robot is created, modified, or deleted, the given callback will be
        called with the task. An option robot name can be given to subscribe to only a specific robot's changes.

        The callback function will get the following:
          * **resource**: The resource object parsed from the stream.
          * **action**: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * **type**: The type of resource (ROBOT).

        Because the robot state is the current stream consistently sending messages to the server, this stream will
        handle the responsibility of reconnecting to the server.

        :param callback: The callback function to call when a robot is created, modified, or deleted.
        :param robot_name: An optional robot name subscribe to.
        :param timeout: The timeout (in seconds) for the connection.
        """
        self.__subscribe('robots', callback, arguments=([robot_name] if robot_name else None), timeout=timeout,
                         on_connect=self.connect if self.handle_reconnect else None)

    def unsubscribe_from_robots(self, callbacks=None, robot_name=None, timeout=DEFAULT_TIMEOUT):
        """
        Unsubscribe the given callbacks from the robots stream.

        If called without callbacks, all callbacks are removed.

        :param callbacks: The array of callbacks to unsubscribe from.
        :param robot_name: An optional robot name unsubscribe from.
        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        self.__unsubscribe('robots', callbacks, arguments=([robot_name] if robot_name else None), timeout=timeout)

    def subscribe_to_map(self, callback=None, map_id=None, version='HEAD', timeout=DEFAULT_TIMEOUT):
        """Subscribe to map changes.
        The connection created through this method can be used to publish zone updates, as well.

        The callback function will get the following:
          * **resource**: The resource object parsed from the stream.
          * **action**: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * **type**: The type of resource (MAP).

        :param callback: The callback function to call when a zone is created, modified, or deleted.
        :param map_id: An optional map ID to subscribe to.
        :param version: The type of versioning to follow (either 'HEAD' or 'draft'). Only applied if map_id is provided.
        :param timeout: The timeout (in seconds) for the connection
        """
        self.__subscribe('maps', callback, arguments=([map_id, 'revisions', version] if map_id else None),
                         timeout=timeout)

    def unsubscribe_from_map(self, callbacks=None, map_id=None, timeout=DEFAULT_TIMEOUT):
        """Unsubscribe the given callbacks from the maps stream. If called without callbacks, all callbacks are
        removed.

        :param callbacks: The array of callbacks to unsubscribe from.
        :param map_id: An optional map ID to unsubscribe from.
        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        self.__unsubscribe('maps', callbacks, arguments=([map_id] if map_id else None), timeout=timeout)

    def subscribe_to_settings(self, callback, timeout=DEFAULT_TIMEOUT):
        """Subscribe to all changes in settings. When a new setting is created, the given callback will be called with
        that setting.

        The callback function will get the following:
          * **resource**: The resource object parsed from the stream.
          * **action**: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * **type**: The type of resource (e.g., LOG, or TASK).

        :param callback: The callback function to call when a new setting is created.
        :param timeout: The timeout (in seconds) for the connection.
        """
        self.__subscribe('settings', callback, timeout=timeout)

    def unsubscribe_from_settings(self, callbacks=None, timeout=DEFAULT_TIMEOUT):
        """Unsubscribe the given callbacks from the settings stream.

        If called without callbacks, all callbacks are removed.

        :param callbacks: The array of callbacks to unsubscribe from.
        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        self.__unsubscribe('settings', callbacks, timeout=timeout)

    def version(self):
        self.http_client.connect()
        response = self.http_client.get('system')
        return response['version']

    def __subscribe(self, stream, callback, arguments=None, timeout=DEFAULT_TIMEOUT, on_connect=None):
        """A helper function to subscribe to a stream.

        :param stream: The name of the stream to subscribe to.
        :param callback: The callback function for the stream.
        :param arguments: An optional array of arguments to pass to the stream.
        :param timeout: The timeout (in seconds) for the connection.
        """
        # Create an ID based on the arguments
        stream_id = self.__get_stream_id(stream, arguments)

        # Check if we have already subscribed
        if stream_id not in self.__websocket_clients:
            client = WebSocketClient(self.username, self.__password, self.host, self.port,
                                     stream=stream_id, arguments=arguments, handle_reconnect=self.handle_reconnect,
                                     on_connect=on_connect, ssl=self.ssl,
                                     auth_token=self.http_client.get_authentication_token())
            client.connect(timeout)
            if not client.is_connected:
                # Connection was not successful, so return instead.
                    raise ConnectionError("Attempted to subscribe to '%s' but client failed to connect." % stream)
            self.__websocket_clients[stream_id] = client

        self.__websocket_clients[stream_id].register_callback(callback)

    def __unsubscribe(self, stream, callbacks, arguments=None, timeout=DEFAULT_TIMEOUT):
        """A helper function to unsubscribe from a stream.

        :param stream: The name of the stream to subscribe to.
        :param callback: The callback function for the stream.
        :param arguments: An optional array of arguments to pass to the stream.
        :param timeout: The timeout (in seconds) for the connection.
        """
        # Create an ID based on the arguments
        stream_id = self.__get_stream_id(stream, arguments)

        # Check if we have already subscribed
        if stream_id in self.__websocket_clients:
            for callback in callbacks or []:
                self.__websocket_clients[stream_id].deregister_callback(callback)

            # If there are no more, we can unsubscribe
            if self.__websocket_clients[stream_id].num_callbacks is 0 or callbacks is None:
                self.__websocket_clients[stream_id].disconnect(timeout)
                del self.__websocket_clients[stream_id]

    @staticmethod
    def __get_stream_id(stream, arguments=None):
        """Create a stream ID based on the stream name and optional arguments. This is what will be stored in the set of
            streams internally.

        :param stream: The name of the stream.
        :param arguments: An optional array of arguments to pass to the stream.
        :return: The ID of the stream used internally to keep track of active stream subscriptions.
        """
        # Create an ID based on the arguments
        stream_id = stream
        for argument in arguments or []:
            stream += '-%s' % str(argument)
        return stream_id

    # TODO: Move these members up? Also provide docstrings for these
    ROBOT_UNKNOWN_COLOR = (205, 205, 205)
    ROBOT_FREE_COLOR = (254, 254, 254)
    ROBOT_KEEPOUT_COLOR = (0, 0, 0)

    DOCK_CLEAR_WIDTH = 0.75
    DOCK_CLEAR_HEIGHT = 0.85

    def generate_speedlimit_image(self, map_resource):
        """Generate a speed-limit image by applying annotations in a Map resource to the image data stored in its image
            field.

        :param map_**resource**: The resource to generate a speedlimit image from.
        :type map_**resource**: :class:`fetchcore.resources.maps.Map`
        :return: The image data for a speedlimit image corresponding to fields in **map_resource**.
        """
        try:
            # map_id = map_resource.id
            image_data = map_resource.image
        except UndefinedFieldError as e:
            # Either ID or base image data isn't set, so can't do anything
            print "No ID or base image data to process: %s" % e  # TODO: Make this a logging call instead
            return None

        if not image_data:
            print "Map resource does not appear to have image data."
            return None

        try:
            areas = map_resource.areas
        except UndefinedFieldError:
            map_resource.refresh(client=self)
            areas = map_resource.areas
        #
        # if not areas:
        #     print "No areas found for map with ID %s." % map_id  # TODO: Make this a logging call instead
        #     return image_data  # TODO: Make it return a blank map as opposed to the original image data

        scale = 1.0 / map_resource.resolution
        speedlimit_image = Image.open(io.BytesIO(image_data))
        width, height = speedlimit_image.size
        speedlimit_image = Image.new("RGB", (width, height), self.ROBOT_FREE_COLOR)
        speedlimit_draw = ImageDraw.Draw(speedlimit_image)

        speedlimit_areas = Queue.PriorityQueue()
        for area in areas:
            if area.type == AreaTypes.SPEED_LIMIT:
                # Organize speed limit areas by value
                try:
                    speedlimit_areas.put((100 - int(area.value * 100), area))
                except UndefinedFieldError:
                    print "Speedlimit area %s was provided without necessary field 'value' during map generation." \
                          % area.id
                    continue

        while not speedlimit_areas.empty():
            priority, area = speedlimit_areas.get()
            speed_color = tuple(int(round(area.value * color)) for color in (254, 254, 254))
            self.__draw_areas(speedlimit_draw, [area], scale, map_resource.x, map_resource.y, height, speed_color)

        speedlimit_image_bytes = io.BytesIO()
        speedlimit_image.save(speedlimit_image_bytes, format="PNG")

        return speedlimit_image_bytes.getvalue()

    def generate_keepout_image(self, map_resource):
        """Generate a keepout image by applying annotations in a Map resource to the image data stored in its image
            field.

        :param map_**resource**: The resource to generate a keepout image from.
        :type map_**resource**: :class:`fetchcore.resources.maps.Map`
        :return: The image data for a keepout image corresponding to fields in **map_resource**.
        """
        try:
            map_id = map_resource.id
            image_data = map_resource.image
        except UndefinedFieldError as e:
            # Either ID or base image data isn't set, so can't do anything
            print "No ID or base image data to process: %s." % e  # TODO: Make this a logging call instead
            return None

        if not image_data:
            print "Map resource does not appear to have image data."
            return None

        try:
            areas = map_resource.areas
        except UndefinedFieldError:
            map_resource.refresh(client=self)
            areas = map_resource.areas

        try:
            docks = map_resource.docks
        except UndefinedFieldError:
            map_resource.refresh(client=self)
            docks = map_resource.docks

        if not areas and not docks:
            print "No areas found for map with ID %s." % map_id  # TODO: Make this a logging call instead
            return image_data

        scale = 1.0 / map_resource.resolution
        keepout_image = Image.open(io.BytesIO(image_data))
        keepout_image = keepout_image.convert("RGB")
        width, height = keepout_image.size
        keepout_draw = ImageDraw.Draw(keepout_image)

        keepout_areas = []
        free_areas = []
        for area in areas or []:
            if area.type == AreaTypes.KEEPOUT:
                keepout_areas.append(area)
            elif area.type == AreaTypes.FREE:
                free_areas.append(area)

        # We should establish virtual free areas around docks, so we'll generate them here
        for dock in docks or []:

            sin_t = sin(dock.theta)
            cos_t = cos(dock.theta)
            clear_x = self.DOCK_CLEAR_WIDTH / 2
            clear_y = self.DOCK_CLEAR_HEIGHT / 2

            points = []
            delta_x = [-clear_x, -clear_x, clear_x, clear_x]
            delta_y = [-clear_y, clear_y, clear_y, -clear_y]
            for dx, dy in zip(delta_x, delta_y):
                rotated_x = (dx * cos_t) - (dy * sin_t)
                rotated_y = (dx * sin_t) + (dy * cos_t)
                points.append(dict(x=dock.x + rotated_x, y=dock.y + rotated_y))

            from fetchcore.resources.maps.area import Area
            dock_free_area = Area(shape=Shapes.POLYGON, type=AreaTypes.FREE, points=points, map=map_id)
            free_areas.append(dock_free_area)

        # Keepout areas take priority over free areas, so apply them second
        self.__draw_areas(keepout_draw, free_areas, scale, map_resource.x, map_resource.y, height,
                          self.ROBOT_FREE_COLOR)

        self.__draw_areas(keepout_draw, keepout_areas, scale, map_resource.x, map_resource.y, height,
                          self.ROBOT_KEEPOUT_COLOR)

        keepout_image_bytes = io.BytesIO()
        keepout_image.save(keepout_image_bytes, format="PNG")

        return keepout_image_bytes.getvalue()

    @staticmethod
    def __draw_areas(draw, areas, scale, origin_x, origin_y, height, color):
        """Draw a list of Areas onto a Draw object.

        :param draw: The Draw object to draw on.
        :param areas: A list of Areas to draw onto the object.
        :param scale: The scale of meters to pixel.
        :param origin_x: The real-world x-coordinate of the bottom left corner of the image (in meters).
        :param origin_y: The real-world y-coordinate for the bottom left corner of the image (in meters).
        :param height: The height of the image in pixels
        :param color: An RGB tuple of color to apply for the areas.

        :type draw: :class:`PIL.ImageDraw`
        :type areas: A list of :class:`fetchcore.resources.Area` objects
        :type scale: float
        :type origin_x: float
        :type origin_y: float
        :type height: int
        :type color: 3-tuple of integers [0-255]
        """
        for area in areas:
            # Both RECTANGLE and POLYGON shapes should be defined by multiple points, so no point in differentiation.
            usable_points = []
            for point in area.points:
                usable_points.append((int(round((point.x - origin_x) * scale)),
                                      height - int(round((point.y - origin_y) * scale))))
            if len(usable_points) < 3:
                return
            draw.polygon(usable_points, fill=color)
