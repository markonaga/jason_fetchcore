# Copyright 2016 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Russell Toris

# Futures
from __future__ import unicode_literals

# Standard library
import json
import logging
import socket

# HTTP Requests
import requests
import requests.exceptions

# fetchcore
from fetchcore.client.client import Client, Protocol, DEFAULT_TIMEOUT
from fetchcore.settings import DEFAULT_HOST, DEFAULT_PORT, API_VERSION, SERVER_PAGE_SIZE
from fetchcore.utils import Number
from fetchcore import exceptions


class HttpClient(Client):
    """A HTTP client used to talk directly to the fetchcore REST API."""

    # timeout passed into requests, pertaining to connect timeout and read timeout, in seconds
    TIMEOUT = (3.05, 15)

    def __init__(self, username, password, host=DEFAULT_HOST, port=DEFAULT_PORT, handle_reconnect=False,
                 on_connect=None, ssl=False, auth_token=None):
        """Create a new fetchcore HTTP client.

        :param username: Username for login.
        :param password: Password for login.
        :param host: Host address of the server.
        :param port: Port to connect to on the server.
        :param handle_reconnect: Whether to automatically connect/update connection status when making requests
            using this client.
        :param on_connect: A method to run after a successful connection.
        :param ssl: Whether to use an SSL protocol when connecting the client
        """
        super(HttpClient, self).__init__(username, password, Protocol.HTTPS if ssl else Protocol.HTTP, host, port,
                                         auth_token=auth_token)

        # Base URLs of the server
        self.__api_url = self.url + 'api/%s/' % API_VERSION

        # Main request session
        self.__session = requests.Session()

        # Last known IP, updated on connect
        self.ip = '0.0.0.0'

        self.handle_reconnect = handle_reconnect

        self.on_connect = on_connect

    def connect(self, timeout=DEFAULT_TIMEOUT):
        """Connect and authenticate to the server.

        :param timeout: The timeout (in seconds) for the connection.
        :raise: fetchcore.exceptions.ConnectionError Thrown if there is a problem creating communicating with fetchcore.
        """
        # TODO: use timeout in request
        if self.is_connected:
            # Don't connect twice
            return

        # The authentication token for all requests
        try:
            token = self.get_authentication_token(timeout)
        except exceptions.ConnectionError as err:
            if self.handle_reconnect:
                return
            else:
                logging.warn("Failed to get authentication token from server.")
                raise err

        # Retrieve IP (original code: http://stackoverflow.com/a/166589)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((self._Client__host, self._Client__port))
            self.ip = s.getsockname()[0]
        except socket.gaierror:
            raise exceptions.ConnectionError("Failed to connect to %s:%s when retrieving IP." %
                                             (self._Client__host, self._Client__port))
        except Exception as err:
            raise exceptions.ConnectionError(err.message)
        finally:
            s.close()

        # Parse out the token
        self.__session.headers.update({'AUTHORIZATION': 'Token ' + token})
        self._connected = True
        if self.on_connect:
            self.on_connect()

    def disconnect(self, timeout=DEFAULT_TIMEOUT):
        """Disconnect and destroy your session to the fetchcore server.

        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        # Close out the old session
        self.__session.close()
        # Create a fresh session
        self.__session = requests.Session()
        self._connected = False

    def get(self, endpoint, pk=None, page=None, offset=None, amount=None, raw=False):
        """Make a GET request to the given endpoint. Throws an appropriate exception on failure.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param pk: The optional primary key of the entity to get.
        :param page: The optional page to load.
        :param offset: The first n elements to skip when loading.
        :param amount: The number of elements to load (set to any negative integer to try to load all of them).
        :param raw: Whether to return the response body as JSON or a raw data string (defaults to JSON).
        :return: The JSON or raw data response from fetchcore.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a call is made without being connected to fetchcore.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        :raise fetchcore.exceptions.ValidationError: Thrown if only one of offset or amount is set, or more than one of
               [pk, page, offset&amount] is set.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        # Check the named kwargs
        use_pk = pk is not None
        use_page = page is not None
        use_offset = offset is not None or amount is not None
        if int(use_pk) + int(use_page) + int(use_offset) > 1:
            raise exceptions.ValidationError("Can only get by either primary key, page, or offset/amount.")

        if use_page:
            url = self.__build_api_url(endpoint, None) + '?page=' + str(page)
            return self.__handle_response(self.__session.get, url, raw=raw)
        elif use_offset:
            if not Number.is_integer(offset) or not Number.is_integer(amount):
                raise exceptions.ValidationError("Offset and amount must be integers.")
            load_all = amount < 0
            initial_page_offset = offset % SERVER_PAGE_SIZE
            page = offset / SERVER_PAGE_SIZE + 1
            # Do the first page on its own so that if we don't have that page we can stop
            page_data = self.get(endpoint, page=page, raw=False)
            response = {
                'count': page_data['count'],
                'previous': page_data['previous'],
                'results': [],
                'next': page_data['next'],
            }
            page_offset = initial_page_offset

            if len(page_data['results']) >= initial_page_offset:
                while True:
                    if load_all:
                        num_new_results = len(page_data['results'])
                    else:
                        num_new_results = min(amount - len(response['results']),
                                              len(page_data['results']) - page_offset)
                    response['results'] += page_data['results'][page_offset:page_offset + num_new_results]
                    response['next'] = page_data['next']
                    if (not load_all and len(response['results']) >= amount) or page_data['next'] is None:
                        break
                    page += 1
                    page_offset = 0
                    try:
                        page_data = self.get(endpoint, page=page, raw=False)
                    except exceptions.NotFound:
                        # Exit out if the next page is missing, likely a race condition
                        break

            return json.dumps(response) if raw else response
        else:
            return self.__handle_response(self.__session.get, self.__build_api_url(endpoint, pk), raw=raw)

    def post(self, endpoint, data, files=None):
        """Make a POST request to the given endpoint. Throws an appropriate exception on failure.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param data: The data to send with the request as a JSON dictionary.
        :param files: Optional dictionary of objects to send as a multipart-encoded request.
        :return: The JSON response from fetchcore.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a call is made without being connected to fetchcore.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        kwargs = {'data': data, 'files': files} if files else {'json': data}
        return self.__handle_response(self.__session.post, self.__build_api_url(endpoint), **kwargs)

    def put(self, endpoint, pk, data, files=None):
        """Make a PUT request to the given endpoint. Throws an appropriate exception on failure.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param pk: The primary key of the entity to put.
        :param data: The data to send with the request as a JSON dictionary.
        :param files: Optional dictionary of objects to send as a multipart-encoded request.
        :return: The JSON response from fetchcore.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a call is made without being connected to fetchcore.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        kwargs = {'data': data, 'files': files} if files else {'json': data}
        return self.__handle_response(self.__session.put, self.__build_api_url(endpoint, pk), **kwargs)

    def patch(self, endpoint, pk, data, files=None):
        """Make a PATCH request to the given endpoint. Throws an appropriate exception on failure.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param pk: The primary key of the entity to patch.
        :param data: The data to send with the request as a JSON dictionary.
        :param files: Optional dictionary of objects to send as a multipart-encoded request.
        :return: The JSON response from fetchcore.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a call is made without being connected to fetchcore.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        kwargs = {'data': data, 'files': files} if files else {'json': data}
        return self.__handle_response(self.__session.patch, self.__build_api_url(endpoint, pk), **kwargs)

    def delete(self, endpoint, pk):
        """Make a DELETE request to the given endpoint. Throws an appropriate exception on failure. Note that nothing is
        returned as a successful delete request is a 204 No Content.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param pk: The primary key of the entity to delete.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a call is made without being connected to fetchcore.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        # Will throw the exception if an error is detected
        self.__handle_response(self.__session.delete, self.__build_api_url(endpoint, pk))

    def __build_api_url(self, endpoint, pk=None):
        """Build a valid URL by combining the endpoint and the primary key.

        :param endpoint: The endpoint to call (e.g., actions/definitions).
        :param pk: The optional primary key of the entity.
        :return: A valid fetchcore URL to make a request to.
        """
        # Build the URL
        url = self.__api_url + endpoint
        if not url.endswith('/'):
            url += '/'
        if pk is not None:
            url += str(pk)
        if not url.endswith('/'):
            url += '/'
        return url

    # TODO: change to __make_request (see C++ SDK) since we need to catch requests.ConnectionError in all cases
    # TODO: The handle_connect decorator takes care of the exception, but we might need to use the above detail
    def __handle_response(self, action, url, raw=False, **kwargs):
        """Handle the response after making a HTTP request and throw any exceptions if the status is not 20x.

        :param action: The Session method to call for making the HTTP request.
        :param url: The url to make the request to.
        :param raw: Whether to return the response body as JSON or a raw data string (defaults to JSON).
        :return: The JSON dictionary from any 200 or 201 responses, or None if a 204 was encountered.
        :raise fetchcore.exceptions.RequestException: Corresponding subclass thrown for associated HTTP response error.
        """
        try:
            response = action(url, timeout=self.TIMEOUT, **kwargs)
        except requests.exceptions.RequestException as e:
            raise exceptions.ConnectionError('Encountered error while making request to %s, %s', url, e)

        # 200 OKAY or 201 CREATED have a JSON response
        if response.status_code == 200 or response.status_code == 201:
            return response.content if raw else response.json()
        # 204 NO CONTENT is okay, but we have nothing to parse
        elif response.status_code == 204:
            return None
        elif response.status_code == 400:
            self.__log_response_warning(response)
            raise exceptions.BadRequest(response.text, response.url, response.status_code, response.json())
        elif response.status_code == 401:
            self.__log_response_warning(response)
            raise exceptions.Unauthorized(
                response.json().get('detail', response.text), response.url, response.status_code, response.json()
            )
        elif response.status_code == 403:
            self.__log_response_warning(response)
            raise exceptions.Forbidden(
                response.json().get('detail', response.text), response.url, response.status_code, response.json()
            )
        elif response.status_code == 404:
            self.__log_response_warning(response)
            raise exceptions.NotFound("%s Not Found" % response.url, response.url, response.status_code)
        elif response.status_code == 405:
            self.__log_response_warning(response)
            raise exceptions.MethodNotAllowed(
                response.json().get('detail', response.text), response.url, response.status_code, response.json()
            )
        elif response.status_code == 409:
            self.__log_response_warning(response)
            # TODO: verify 409 returns a detail (we have yet to find something that returns a 409)
            raise exceptions.Conflict(
                response.json().get('detail', response.text), response.url, response.status_code, response.json()
            )
        elif response.status_code == 500:
            self.__log_response_error(response)

            raise exceptions.InternalServerError(response.text, response.url, response.status_code)
        else:
            # TODO add other 400 errors if Django even throws them
            raise exceptions.RequestException(response.text, response.url, response.status_code)

    @staticmethod
    def __log_response_warning(response):
        """Log a warning from the HTTP response returned from the requests library.

        :param response: The HTTP response to log.
        """
        logging.warn("%s returned with a %d '%s'" % (response.url, response.status_code, response.text))

    @staticmethod
    def __log_response_error(response):
        """Log an error from the HTTP response returned from the requests library.

        :param response: The HTTP response to log.
        """
        logging.error("%s returned with a %d '%s'" % (response.url, response.status_code, response.text))
