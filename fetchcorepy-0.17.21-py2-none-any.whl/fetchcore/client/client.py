# Copyright 2016 Fetch Robotics, Inc.
# Author(s): Russell Toris, Michael Hwang

# Futures
from __future__ import unicode_literals

# Standard Library

# HTTP Requests
import requests

# fetchcore
from fetchcore import exceptions
from fetchcore import settings
from fetchcore.utils.enum import Enum

# The default timeout (in seconds) for connections/disconnections.
DEFAULT_TIMEOUT = 10

# Supported Protocol for fetchcore.
Protocol = Enum(WS='ws', WSS='wss', HTTP='http', HTTPS='https')


class Client(object):
    """An abstract client that contains authentication and connection information."""

    def __init__(self, username, password, protocol, host=settings.DEFAULT_HOST, port=settings.DEFAULT_PORT,
                 auth_token=None):
        """Create a new fetchcore abstract client.

        :param username: Username for login.
        :param password: Password for login.
        :param protocol: The protocol to use (as defined in fetchcore.client.Protocol).
        :param host: Host address of the server.
        :param port: Port to connect to on the server.
        """
        # Authentication information (password has not getter)
        self.__username = username
        self.__password = password

        # Connection information
        self.__host = host
        self.__port = port
        self.__protocol = protocol

        # Connection flag
        self._connected = False

        self._auth_token = auth_token

        # Base URLs of the server
        self.__base_url = '%s://%s:%d/' % (protocol, host, port)
        auth_protocol = Protocol.HTTPS if protocol in [Protocol.HTTPS, Protocol.WSS] else Protocol.HTTP
        self.__auth_url = '%s://%s:%d/' % (auth_protocol, host, port) + settings.AUTHENTICATION_ENDPOINT

    @property
    def username(self):
        """Get the username for this client.

        :return: The username for this client.
        """
        return self.__username

    @property
    def host(self):
        """Get the host address for this client.

        :return: The host address for this client.
        """
        return self.__host

    @property
    def port(self):
        """Get the port for this client.

        :return: The port for this client.
        """
        return self.__port

    @property
    def protocol(self):
        """Get the protocol used for this client.

        :return: The protocol used for this client.
        """
        return self.__protocol

    @property
    def url(self):
        """Get the base URL for this client.

        :return: The base URL for this client.
        """
        return self.__base_url

    @property
    def is_connected(self):
        """Checks if the client is still connected.

        :return: If the client is still connected.
        """
        return self._connected

    def get_authentication_token(self, timeout=DEFAULT_TIMEOUT):
        """
        Get the authentication token for HTTP(S) requests.

        :param timeout: The timeout (in seconds) for the request.
        :return: The API token for authentication.
        :raise: fetchcore.exceptions.ConnectionError Thrown if there is a problem creating communicating with fetchcore.
        """
        if not self._auth_token:
            try:
                # TODO: use the timeout
                # Check the response to see if we authenticated
                response = requests.post(self.__auth_url, {'username': self.__username, 'password': self.__password},
                                         timeout=10)
                if response.status_code == 400:
                    raise exceptions.Unauthorized("Could not authorize with given credentials.", self.__auth_url, 400)
                elif response.status_code != 200:
                    raise exceptions.ConnectionError("Unable to connect. Check login credentials.")

                # Parse out the token
                self._auth_token = response.json().get('token')
            except (requests.ConnectionError, requests.ReadTimeout):
                raise exceptions.ConnectionError("Unable to connect. Check that %s is available." % self.__auth_url)
        return self._auth_token

    def connect(self, timeout):
        """
        Connect and authenticate to the server.

        :param timeout: The timeout (in seconds) for the connection.
        :raise: NotImplementedError By default this method is not implemented.
        """
        raise NotImplementedError()

    def disconnect(self, timeout):
        """
        Disconnect and destroy your session to the fetchcore server.

        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        :raise: NotImplementedError By default this method is not implemented.
        """
        raise NotImplementedError()
