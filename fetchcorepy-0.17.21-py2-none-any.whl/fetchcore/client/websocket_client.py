# Copyright 2016 Fetch Robotics, Inc.
# Author(s): Russell Toris

# Futures
from __future__ import unicode_literals

# Standard library
import json
import logging
import threading
import time

# WebSockets
import websocket

# fetchcore
from fetchcore.client.client import Client, Protocol, DEFAULT_TIMEOUT
from fetchcore.settings import DEFAULT_HOST, DEFAULT_PORT, API_VERSION
from fetchcore.definitions.enums import ResourceTypes, ResourceActions
from fetchcore import exceptions


class WebSocketClient(Client):
    """A WebSocket client for communicating with the fetchcore data streams."""

    def __init__(self, username, password, host=DEFAULT_HOST, port=DEFAULT_PORT, stream=None, arguments=None,
                 handle_reconnect=False, on_connect=None, ssl=False, auth_token=None):
        """Create a WebSocket client with the given credentials.

        :param username: Username for login.
        :param password: Password for login.
        :param host: Host address of the server.
        :param port: Port to connect to on the server.
        :param stream: The name of the stream to connect to.
        :param arguments: Additional ordered value arguments to use in the URL.
        :param handle_reconnect: Whether to automatically connect/update connection status when making requests
            using this client.
        :param on_connect: A method to run (without arguments) after a connection is successfully opened.
        """
        super(WebSocketClient, self).__init__(username, password, Protocol.WSS if ssl else Protocol.WS, host, port,
                                              auth_token=auth_token)

        # API URL of the client
        self.__url = super(WebSocketClient, self).url + 'api/' + API_VERSION + '/streams/'
        if stream:
            self.__url += stream + '/'
        for argument in arguments or []:
            self.__url += str(argument) + '/'

        # The actual client that communicates with the server.
        self.__websocket = None

        # The callbacks for this client.
        self._callbacks = set()

        self.handle_reconnect = handle_reconnect
        self.on_connect = on_connect

    def register_callback(self, callback):
        """Add a callback to the stream if it does not exist already.

        The callback function will get the following:
          * resource: The resource object parsed from the stream.
          * action: The action performed on the resource (CREATE, UPDATE, or DELETE).
          * type: The type of resource (e.g., LOG, or TASK).

        :param callback: The function to call when data is received.
        """
        self._callbacks.add(callback)

    def deregister_callback(self, callback):
        """Remove a callback to the stream (if it exists).

        :param callback: The function to remove from the callbacks.
        """
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    @property
    def num_callbacks(self):
        """Get the number of callback functions.

        :return: The number of callback functions registered.
        """
        return len(self._callbacks)

    @property
    def url(self):
        """Get the URL for this client.

        :return: The URL for this client.
        """
        return self.__url

    def wrapped_run_forever(self, **kwargs):
        """Wrapper for run_forever to handle exceptions from run_forever()"""
        try:
            self.__websocket.run_forever(**kwargs)
        except websocket.WebSocketException:
            # In case we connect twice on accident, just squelch the error
            pass
        except AttributeError as err:
            # This error comes up if we try to close an already cleaned-up websocket connection (FETCHCORE-2578)
            if not all(substr in err.message for substr in ['NoneType', 'close']):
                print "Got unexpected AttributeError: %s" % err

    def connect(self, timeout=DEFAULT_TIMEOUT):
        """Make a connection to the fetchcore server.

        :param timeout: The timeout (in seconds) for the connection.
        :raise fetchcore.exceptions.ConnectionError: Thrown if there is a problem creating communicating with fetchcore.
        """
        if self.is_connected:
            # Don't connect twice
            return

        try:
            token = self.get_authentication_token()
        except exceptions.ConnectionError:
            return

        # The actual client that communicates with the server.
        websocket.setdefaulttimeout(timeout)
        self.__websocket = websocket.WebSocketApp(self.__url + '?token=' + token,
                                                  on_message=self.on_message, on_error=self.on_error,
                                                  on_close=self.on_close, on_open=self.on_open)

        # The websocket library only allows static methods to be passed in for callbacks. We mask this by creating
        # an internal pointer to ourselves so we can call our WebSocketClient methods.
        self.__websocket.client = self

        # Wait for response and throw exception
        start = time.time()
        # TODO: handle auth when websockets want them
        thread = threading.Thread(target=self.wrapped_run_forever, kwargs={'ping_timeout': 10})
        thread.start()
        while not self.is_connected and time.time() - start < timeout:
            time.sleep(0)

        # One final check
        # TODO: Replace connected check with something thread-safe, since we constantly hit this when reconnecting
        # if not self.is_connected:
        #     self.disconnect()
        #     raise exceptions.ConnectionError("Unable to connect. Check that %s is available." % self.url)

    def disconnect(self, timeout=DEFAULT_TIMEOUT):
        """Disconnect and destroy your session to the fetchcore server.

        :param timeout: The timeout (in seconds) for the disconnection confirmation.
        """
        if self.__websocket is not None:
            try:
                self.__websocket.close()
            except AttributeError as e:
                print "Websocket encounted error while closing,", e
                # Something went wrong. Mark the client as unconnected.
                self._connected = False
            self.__websocket = None

        # Wait for response and throw exception
        start = time.time()
        while self.is_connected and time.time() - start < timeout:
            time.sleep(0)
        # Force disconnect status if timeout is reached
        self._connected = False

    def send(self, data):
        """Attempt to send data to the server. Throws an appropriate exception on failure.

        :param data: A dictionary or JSON-string to be sent over the wire to the server.
        :raise: fetchcore.exceptions.ConnectionError Thrown if a call is made without being connected to fetchcore.
        """
        # Check if we are connected
        if not self.is_connected:
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")
        # Send data
        if isinstance(data, dict):
            data = json.dumps(data)
        # TODO: find the real fix for this race condition, this is a terrible thing to do
        try:
            return self.__websocket.send(data)
        except AttributeError:
            self.disconnect(timeout=0)
            raise exceptions.ConnectionError("Client disconnected, request cannot be made.")

    @staticmethod
    def on_message(ws, message):
        """Handle the incoming WebSocket message.

        :param ws: The WebSocketApp which contains a reference to the associated Fetch client.
        :param message: The message sent from the server.
        """
        try:
            # Attempt to parse the message as a JSON object
            payload = json.loads(message)['payload']
            model = payload['model'].replace('api.', '')

            # TODO: check created/modified/deleted and handle differently

            # See if we know about this kind of model
            resource = None
            # TODO: add more models
            if model == 'log':
                from fetchcore.resources import Log
                resource = Log(**payload['data'])
            elif model == 'task':
                from fetchcore.resources import Task
                resource = Task(**payload['data'])
            elif model == 'action':
                from fetchcore.resources import Action
                resource = \
                    Action.get_action_class(payload['data']['action_definition'])(**payload['data'])
            elif model == 'robotstate':
                from fetchcore.resources.robots import RobotState
                resource = RobotState(**payload['data'])
            elif model == 'robot':
                from fetchcore.resources.robots import Robot
                resource = Robot(**payload['data'])
            elif model == 'revision':
                from fetchcore.resources.maps import Revision
                resource = Revision(**payload['data'])
            elif model == 'map':
                from fetchcore.resources.maps import Map
                try:
                    # Image must be a dummy string since we don't receive it as part of change
                    resource = Map(image="", **payload['data'])
                except Exception as err:
                    print "Tried to make a map resource with %s, but got %s" % (payload['data'], err)
            elif model == 'chargesettings':
                from fetchcore.resources import ChargeSettings
                resource = ChargeSettings(**payload['data'])
            elif model == 'hmisettings':
                from fetchcore.resources import HMISettings
                resource = HMISettings(**payload['data'])
            elif model == 'robotsettings':
                from fetchcore.resources import RobotSettings
                resource = RobotSettings(**payload['data'])
            elif model == 'stagesettings':
                from fetchcore.resources import StageSettings
                resource = StageSettings(**payload['data'])
            elif model == 'updatesettings':
                from fetchcore.resources import UpdateSettings
                resource = UpdateSettings(**payload['data'])

            if resource is not None:
                for callback in ws.client._callbacks:
                    callback(resource, ResourceActions.__getattribute__(payload['action'].upper()),
                             ResourceTypes.__getattribute__(model.upper()))
            else:
                logging.error("%s responded with unknown model '%s'." % (ws.url, model))
        except (ValueError, KeyError, AttributeError) as e:
            logging.error("%s responded with malformed message '%s'. %s" % (ws.url, message, e))

    @staticmethod
    def on_error(ws, error):
        """Handle the error returned from the WebSocket client.

        :param ws: The WebSocketApp which contains a reference to the associated Fetch client.
        :param error: The error message to log.
        """
        # Keyboard interrupts can be caught by the library, ignore them
        if isinstance(error, basestring):
            logging.error("%s responded with '%s'." % (ws.url, error))

    @staticmethod
    def on_close(ws):
        """Handle a disconnect from the server by setting the connected flag to false.

        :param ws: The WebSocketApp which contains a reference to the associated Fetch client.
        """
        ws.client._connected = False
        logging.info("Disconnected from %s." % ws.url)

    def on_open(self, ws):
        """Handle a connection from the server by setting the connected flag to true.

        :param ws: The WebSocketApp which contains a reference to the associated Fetch client.
        """
        ws.client._connected = True
        logging.info("Connected to %s." % ws.url)
        if self.on_connect:
            self.on_connect()
