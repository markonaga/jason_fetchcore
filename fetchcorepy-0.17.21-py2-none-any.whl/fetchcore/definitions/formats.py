# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard Library
import re

# Standard timestamp format for fetchcore documents.
# Django/Postgres timestamp example: 2016-09-08T21:11:51.228730Z
REGEX_TIMESTAMP = re.compile('[\d]{4}-[\d]{2}-[\d]{2}T[\d]{2}:[\d]{2}:[\d]{2}(\.[\d]{1,6})?Z', re.IGNORECASE)
TIMESTAMP_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
POSE_STRING_FORMAT = '%.2f,%.2f,%.4f'

# Pattern of flow documents
FLOW_ID_PATTERN = '^FLOW-[\\w-]{4,}$'

# Pattern of schedule documents
SCHEDULE_ID_PATTERN = '^SCHEDULE-[\\w-]{4,}$'

# Pattern of task documents
TASK_ID_PATTERN = '^TASK-[\\w-]{4,}$'

# Pattern of version number for action def
VERSION_PATTERN = '^[0-9]{1,}.[0-9]{1,}.[0-9]{1,}$'

# Pattern of launch file name
ROS_LAUNCH_FILE_PATTERN = '^([a-z_]+)/([a-z_]+).launch(.xml)?$'

# Pattern of ROS message type
ROS_MESSAGE_TYPE_PATTERN = '^([a-z_]+)/([A-Z][a-z]*)+$'

# Pattern of task template
TASKTEMPLATE_ID_PATTERN = '^TASKTEMPLATE-[\\w-]{4,}$'

# Pattern of map
MAP_ID_PATTERN = '^MAP-[\\w-]{4,}$'

# Pattern of robot names
ROBOT_NAME_PATTERN = '^freight\d+$'

# The regular expression to match against a string that is all capital letters and underscores.
REGEX_CAPITAL_UNDERSCORE = '^[A-Z_]+$'

# The regular expression to match against a string that is all capital letters, numbers and underscores.
REGEX_CAPITAL_NUMBER_UNDERSCORE = '^[A-Z_\d]+$'

# The regular expression to match against a string that is all lower letters, underscores, or slashes.
REGEX_LOWER_CASE_UNDERSCORE_SLASHES = '^[a-z_/]+$'

# The regular expression to match against a string in MAC address notation (6 pairs of hexadecimal digits with -'s)
REGEX_MAC_ADDRESS = '^(?:[0-9a-f]{2}-){5}[0-9a-f]{2}$'

# The regular expression to match against a string representing a duration in the form [%d ]%H:%M:%S
# Reference: https://github.com/django/django/blob/master/django/utils/dateparse.py#L30-L38
REGEX_DURATION = '^(?:(?P<days>\d+) (days?, )?)?(?P<hours>\d+):(?P<minutes>\d+):(?P<seconds>\d+)?$'

# The regular expression to match against an email
REGEX_EMAIL = re.compile(
    r"(^[-!#$%&'*+/=?^_`{}|~0-9A-Z]+(\.[-!#$%&'*+/=?^_`{}|~0-9A-Z]+)*"
    r'|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-\011\013\014\016-\177])*"'
    r')@(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?$', re.IGNORECASE)

# Standard format of all log entires. (from 0.10)
LOG_FORMAT = "%(asctime)-19s %(levelname)-8s : %(message)s"
