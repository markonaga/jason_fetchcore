# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts, Michael Hwang

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.utils.enum import Enum

# Allowed task statuses in Fetchcore tasks
TaskStatus = Enum(NEW='NEW', QUEUED='QUEUED', WORKING='WORKING',
                  COMPLETE='COMPLETE', FAILED='FAILED', CANCELED='CANCELED',
                  PREEMPTED='PREEMPTED', PAUSED='PAUSED')
# Allowed actions statuses in Fetchcore actions
ActionStatus = Enum(NEW='NEW', QUEUED='QUEUED', WORKING='WORKING',
                    COMPLETE='COMPLETE', FAILED='FAILED', CANCELED='CANCELED',
                    PREEMPTED='PREEMPTED', PAUSED='PAUSED')

# Allowed response statuses in Fetchcore responses
ResponseStatus = Enum(NEW='NEW', WORKING='WORKING', COMPLETE='COMPLETE', FAILED='FAILED', CANCELED='CANCELED',
                      PASSED='PASSED', PREEMPTED='PREEMPTED')

# Preemption levels of Fetchcore actions
ActionPreemption = Enum(NONE='NONE', HARD='HARD', SOFT='SOFT')
# Available current status of an agent
# TODO: Remove AgentStatus declaration once agents are removed
AgentStatus = RobotStatus = Enum(OFFLINE='OFFLINE', IDLE='IDLE', WORKING='WORKING',
                                 RUNSTOP='RUNSTOP', ERROR='ERROR', SERVICE='SERVICE')
# Available authorized state of an agent
AuthState = Enum(PENDING='PENDING', AUTHORIZED='AUTHORIZED', DENIED='DENIED')
# Available roles for an agent
AgentRole = Enum(ROBOT='robot', OPERATOR='operator', MANAGER='manager',
                 ADMIN='admin')
# Available types for the schedule
RepeatTypes = Enum(NONE='NONE', HOURLY='HOURLY', DAILY='DAILY', WEEKLY='WEEKLY')
# Available types for weekdays
Weekdays = Enum(SUNDAY='SUNDAY', MONDAY='MONDAY', TUESDAY='TUESDAY',
                WEDNESDAY='WEDNESDAY', THURSDAY='THURSDAY', FRIDAY='FRIDAY',
                SATURDAY='SATURDAY')
# Available log levels
LogLevel = Enum(DEBUG='DEBUG', INFO='INFO', WARN='WARN', ERROR='ERROR',
                FATAL='FATAL')
# Available area shapes
Shapes = Enum(RECTANGLE='RECTANGLE', POLYGON='POLYGON')
AreaTypes = Enum(KEEPOUT='KEEPOUT', SPEED_LIMIT='SPEED_LIMIT', FREE='FREE', STAGING='STAGING')

# Resource types
ResourceTypes = Enum(LOG='LOG', TASK='TASK', ACTION='ACTION', ROBOTSTATE='ROBOTSTATE', ROBOT='ROBOT',
                     REVISION='REVISION', MAP='MAP', CHARGESETTINGS='CHARGESETTINGS', HMISETTINGS='HMISETTINGS',
                     ROBOTSETTINGS='ROBOTSETTINGS', STAGESETTINGS='STAGESETTINGS', UPDATESETTINGS='UPDATESETTINGS')
# Resource modification actions
ResourceActions = Enum(CREATE='create', UPDATE='update', DELETE='delete')

# Navigation footprint types
FootprintTypes = Enum(POINTS='points', RADIUS='radius')

# Navigation collision model types
CollisionModelTypes = Enum(SIMPLE='simple')

# Navigation cart collision model types
CartCollisionModelTypes = Enum(SIMPLE='simple', PRIMITIVES='primitives')

# Footprint component shapes
ComponentShapes = Enum(CIRCLE='circle', RECTANGLE='rectangle', TRIANGLE='triangle', CAPSULE2D='capsule2d')

SurveyStates = Enum(SUCCEEDED='SUCCEEDED', FAILED='FAILED')
