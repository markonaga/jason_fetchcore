# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Russell Toris

# Futures
from __future__ import absolute_import, print_function, unicode_literals

# Standard library
import os
import subprocess
from xml.etree import ElementTree

try:
    # The current version of Fetchcore SDK (source mode)
    version = ElementTree.parse(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'package.xml')
    ).findtext('version')
except IOError:
    try:
        # If we got here, we might be running from a Debian (e.g., ROS)
        version = ElementTree.parse('/opt/ros/indigo/share/fetchcorepy/package.xml').findtext('version')
    except IOError:
        import pkg_resources
        try:
            # We might be running as a installed Python package (e.g., pip)?
            version = pkg_resources.get_distribution('fetchcore').version
        except pkg_resources.DistributionNotFound:
            # Okay, last try, what does rosversion say?
            version = subprocess.Popen(
                "rosversion fetchcorepy", shell=True, stdout=subprocess.PIPE
            ).stdout.read().strip()
