# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import POSE_STRING_FORMAT
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


# TODO: Move this to a validators package
class Pose(object):
    """
    Class with utility functions for converting and validating poses
    """

    @staticmethod
    def is_pose(value):
        """
        Check if a given list represents a pose [x, y, theta]
        :param value: A list of numbers
        :return: True if the list has 3 finite numbers, False otherwise.
        """
        try:
            return len(value) == 3 and all([Number.is_finite(p) for p in value])
        except TypeError:
            return False

    @staticmethod
    def is_pose_string(value):
        """
        Check if a string is a pose string
        :param value: A string
        :return: True if string can be converted into a list of float of length 3
        """
        try:
            return Pose.is_pose(Pose.str_to_float_list(value))
        except (ValueError, AttributeError, TypeError, ValidationError):
            return False

    @staticmethod
    def is_pose_dict(value):
        try:
            return len(value) == 3 and Pose.is_pose(Pose.dict_to_float_list(value))
        except (ValueError, AttributeError, TypeError, ValidationError):
            return False

    @staticmethod
    def to_pose_string(value):
        """
        Convert a pose to a pose string, or format a pose string
        :param value: A pose or a pose string
        :return: A pose string in POSE_STRING_FORMAT
        """
        if Pose.is_pose(value):
            return POSE_STRING_FORMAT % tuple(value)
        elif isinstance(value, basestring) and Pose.is_pose_string(value):
            return POSE_STRING_FORMAT % tuple(Pose.str_to_float_list(value))
        else:
            raise ValidationError("%s is not a pose (a list of 3 finite numbers)" % value)

    @staticmethod
    def str_to_float_list(value):
        """
        Convert a string to list of floats
        :param value: A string of numbers separated by commas
        :return: A list of floats
        """
        if isinstance(value, basestring):
            try:
                return [float(p) for p in value.split(",")]
            except ValueError:
                raise ValidationError("%s is not a pose (a list of 3 finite numbers)" % value)
        else:
            raise ValidationError("Value must be a string, not %s"
                                  % type(value).__name__)

    @staticmethod
    def dict_to_float_list(value):
        if isinstance(value, dict):
            try:
                return [value[key] for key in ['x', 'y', 'theta']]
            except ValueError:
                raise ValidationError("%s is not a pose dict (a dict containing 3 finite numbers assigned to x, y,"
                                      " and theta)" % value)
        else:
            raise ValidationError("Value must be a dict, not %s" % type(value).__name__)
