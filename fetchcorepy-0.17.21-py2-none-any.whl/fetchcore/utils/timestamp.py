# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import absolute_import, unicode_literals

# Standard library
import datetime
from dateutil.parser import parse
from dateutil.tz import tzlocal


class Timestamp(object):
    """
    A class with utility functions to convert timestamp strings to datetime objects and vice versa.
    """

    @staticmethod
    def to_string(timestamp):
        """
        Convert the given timestamp object into a formatted string.
        :param timestamp: The timestamp as a datetime object.
        :type timestamp: datetime.datetime
        :return: The string representation of the object.
        :rtype: str
        :raise TypeError: Thrown if the timestamp is not a datetime object.
        """
        if isinstance(timestamp, datetime.datetime):
            # Check for timezone information
            if not timestamp.tzinfo:
                return timestamp.replace(tzinfo=tzlocal()).isoformat()
            return timestamp.isoformat()
        else:
            raise TypeError(
                "Timestamp can only be a datetime.datetime object (%s provided)." % type(timestamp)
            )

    @staticmethod
    def to_datetime(timestamp):
        """
        Attempt to parse the given timestamp as a datetime object.
        :param timestamp: The timestamp (as a string or datetime object).
        :type timestamp: str | datetime.datetime
        :return: The parsed timestamp as a datetime object.
        :rtype: datetime.datetime
        :raise TypeError: Thrown if the timestamp is not a string or datetime object.
        :raise ValueError: Thrown if the timestamp cannot be parsed.
        """
        if isinstance(timestamp, datetime.datetime):
            return timestamp
        elif isinstance(timestamp, basestring):
            try:
                return parse(timestamp)
            except ValueError:
                raise ValueError("Timestamp is not in a known parseable format (%s)." % timestamp)
        else:
            raise TypeError(
                "Timestamp can only be a string or a datetime.datetime object (%s provided)." % type(timestamp)
            )
