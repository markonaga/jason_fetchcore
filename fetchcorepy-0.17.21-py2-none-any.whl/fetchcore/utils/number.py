# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua


# Standard library
import numbers
from math import isinf, isnan, pi


# TODO: Move this to a validators package
class Number(object):
    """
    Utility functions for checking and validating numerical values.
    """

    @staticmethod
    def is_real_number(value):
        """
        Checks if the input value is a real number
        :param value: A number
        :return: True if value is a real number. False if value is not a number, a complex number, or a nan.
        """
        return isinstance(value, numbers.Number) and not isinstance(value, complex) and not isnan(value)

    @staticmethod
    def is_integer(value):
        """
        Checks if the input value is an integer.
        :param value: A number
        :return: True if the input value is an integer, False otheriwise
        """
        return isinstance(value, int)

    @staticmethod
    def is_finite(value):
        """
        Checks if the input value is a finite number.
        :param value: A number
        :return: True if the input value is finite, False otheriwise
        """
        return Number.is_real_number(value) and not isinf(value)

    @staticmethod
    def is_finite_non_negative(value):
        """
        Checks if the input value is a non-negative finite number.
        :param value: A number
        :return: True if the input value is finite and non-negative, False otheriwise
        """
        return Number.is_finite(value) and value >= 0

    @staticmethod
    def is_finite_positive(value):
        """
        Checks if the input value is a positive finite number.
        :param value: A number
        :return: True if the input value is finite and positive, False otheriwise
        """
        return Number.is_finite(value) and value > 0

    @staticmethod
    def bind_radians_to_pi(value):
        """
        Reduces theta to a number in between -pi and pi.
        :param value: A number
        :return: An angle in between -pi and pi.
        """
        tolerance = 0.00001
        while value > (pi + tolerance):
            value -= 2 * pi

        while value < -(pi + tolerance):
            value += 2 * pi

        return value
