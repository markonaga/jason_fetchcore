# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Michael Hwang

# Futures
from __future__ import unicode_literals


class Enum(object):
    """
    Enum data type implementation with utility functions.

    An Enum consists of a set of attributes that are set to predefined values. Enum objects are immutable: once they are
    initialized, you cannot add or remove their attributes.

    Reference: http://stackoverflow.com/questions/3603502/prevent-creating-new-attributes-outside-init
    """

    # Whether the class is frozen; when frozen, the class cannot have new attributes added to it
    __is_frozen = False

    def __init__(self, **kwargs):
        """
        Create a new Enum data type.

        :param kwargs: A set of keyword arguments mapping names to values (see example). You cannot add or remove
                       values from the Enum after it is initialized.
        :type kwargs: kwargs

            Example::

                >>> colors = Enum(RED="red", GREEN="green", BLUE="fetch")
                >>> colors.RED
                "red"
                >>> colors.GREEN
                "green"
                >>> colors.BLUE
                "fetch"
        """
        # A frozen (immutable) set of all the predefined values
        self.__values = frozenset(kwargs.values())
        for key, value in kwargs.iteritems():
            setattr(self, key, value)
        self.__is_frozen = True

    def values(self):
        """
        Get the list of possible values in this Enum.
        :return: The frozen (immutable) set of all predefined values.
        :rtype: set
        """
        return self.__values

    def __setattr__(self, attr, value):
        """
        Attempt to set the attribute. This will only work if the object is not initialized.
        :param attr: The attribute name.
        :type attr: basestring
        :param value: The attribute value.
        :type value: basestring
        :raise RuntimeError: Thrown if the class is already initialized (e.g., frozen).
        """
        if self.__is_frozen:
            # Enum is frozen. You cannot add new attributes to it.
            raise RuntimeError("Enum is already a frozen class.")
        else:
            object.__setattr__(self, attr, value)

    def __delattr__(self, _):
        """
        The Enum is frozen. You cannot remove attributes from it.
        :raise RuntimeError: Thrown since the class is already initialized (e.g., frozen).
        """
        raise RuntimeError("Enum is already a frozen class.")

    def to_string(self):
        """
        Create a string representation of the Enum.
        :return: A string containing all the values in the Enum separated by commas.
        :rtype: basestring
        """
        return ', '.join(self.__values)

    def __iter__(self):
        """
        Allows iteration over the Enum's defined values.
        :return: An iterator over the Enum's defined values.
        :rtype: iter
        """
        return iter(self.__values)

    def __contains__(self, value):
        """
        Checks for existence of values in the Enum.
        :param value: The value to check.
        :type value: basestring
        :return: If value is in the set of defined values in this Enum.
        :rtype: bool
        """
        return value in self.__values
