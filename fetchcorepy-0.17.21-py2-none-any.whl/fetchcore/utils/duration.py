# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Rushane Hua, Cappy Pitts, Russell Toris

# Futures
from __future__ import absolute_import, unicode_literals

# Standard library
import datetime
import re
from dateutil.parser import parse

# Fetchcore
from fetchcore.definitions import REGEX_DURATION


class Duration(object):
    """
    A class with utility functions to convert duration strings to timedelta objects and vice versa.
    """

    @staticmethod
    def to_datetime(timestamp):
        """
        Attempt to parse the given timestamp as a datetime object.
        :param timestamp: The timestamp (as a string or datetime object).
        :type timestamp: str | datetime.datetime
        :return: The parsed timestamp as a datetime object.
        :rtype: datetime.datetime
        :raise TypeError: Thrown if the timestamp is not a string or datetime object.
        :raise ValueError: Thrown if the timestamp cannot be parsed.
        """
        if isinstance(timestamp, datetime.datetime):
            return timestamp
        elif isinstance(timestamp, basestring):
            try:
                return parse(timestamp)
            except ValueError:
                raise ValueError("Timestamp is not in a known parseable format (%s)." % timestamp)
        else:
            raise TypeError(
                "Timestamp can only be a string or a datetime.datetime object (%s provided)." % type(timestamp)
            )

    @staticmethod
    def to_string(duration):
        """
        Convert the given timedelta object into a formatted string.
        :param duration: A duration as a timedelta object.
        :type duration: datetime.timedelta
        :return: A string in the format [%d ]%H:%M:%S.
        :rtype: basestring
        :raise TypeError: Thrown if the duration is not a timedelta object.
        """
        if isinstance(duration, datetime.timedelta):
            days = duration.days
            total_seconds = duration.total_seconds() - days * 86400
            duration_string = "%02d:%02d:%02d" % (total_seconds // 3600, (total_seconds // 60) % 60, total_seconds % 60)
            if days:
                duration_string = "%d %s" % (days, duration_string)
            return duration_string
        else:
            raise TypeError(
                "Duration can only be a datetime.timedelta object (%s provided)." % type(duration)
            )

    @staticmethod
    def to_timedelta(duration):
        """
        Attempt to parse the given duration as a timedelta object.
        :param duration: The duration (as a string or timedelta object).
        :type duration: str | datetime.timedelta
        :return: The parsed duration as a timedelta object.
        :rtype: datetime.timedelta
        :raise TypeError: Thrown if the duration is not a string or timedelta object.
        :raise ValueError: Thrown if the duration cannot be parsed.
        """
        if isinstance(duration, datetime.timedelta):
            return duration
        elif isinstance(duration, basestring):
            match = re.compile(REGEX_DURATION).match(duration)
            if not match:
                raise ValueError("Duration is not in a known parseable format (%s)." % duration)
            group = {key: int(value) for key, value in match.groupdict('0').iteritems()}
            return datetime.timedelta(
                days=group['days'], hours=group['hours'], minutes=group['minutes'], seconds=group['seconds'],
            )
        else:
            raise TypeError(
                "Duration can only be a string or a datetime.timedelta object (%s provided)." % type(duration)
            )
