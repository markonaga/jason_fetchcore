# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts


# Standard library
import socket


# TODO: Move this to a validators package
class IP(object):
    """
    A class with utility functions to validate IP addresses
    """

    @staticmethod
    def valid_type(value):
        """
        Checks to see if the the input value is a valid type
        :param value: A string
        :return: True if IP is a string and False otherwise
        """
        return isinstance(value, basestring)

    @staticmethod
    def valid_address(value):
        """
        Checks to see if the the input value can be converted to an IP address
        :param value: A string that looks like an IP address
        :return: True if value can be converted into a legal IP address and False otherwise
        """
        try:
            return socket.inet_aton(value)
        except socket.error:
            return False

    @staticmethod
    def current_local_ip():
        """
        Get the current local IP address.
        :return: The current local IP address.
        """
        return socket.gethostbyname(socket.gethostname())
