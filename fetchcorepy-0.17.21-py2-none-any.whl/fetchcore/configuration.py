# Copyright 2017 Fetch Robotics, Inc.
# Author(s): Russell Toris, Cappy Pitts

# Futures
from __future__ import absolute_import, unicode_literals

# Fetchcore
from fetchcore.client import FetchcoreClient
from fetchcore.settings import DEFAULT_HOST, DEFAULT_PORT

# The globally configured client used throughout the SDK
__GLOBAL_CLIENT__ = None


# TODO: remove SSL flag and just check if the port is 443
def initialize_global_client(username, password, host=DEFAULT_HOST, port=DEFAULT_PORT, ssl=False):
    """
    Configure the global client for the SDK. The global client is used as the default client when making calls like
    save() or load() on resources. In most cases, this function is the first thing that should be called in your
    application.
    :param username: The username to use for the connection.
    :type username: basestring
    :param password: The password for the connection.
    :type password: basestring
    :param host: The hostname to use for the connection.
    :type host: basestring
    :param port: The port to use for the connection.
    :type host: int
    :param ssl: If SSL (i.e., HTTPS and WSS) should be used (defaults to false).
    :type ssl: bool
    :raise fetchcore.exceptions.ConnectionError: Thrown if there is a problem creating communicating with Fetchcore.
    """
    global __GLOBAL_CLIENT__
    __GLOBAL_CLIENT__ = FetchcoreClient(username=username, password=password, host=host, port=port, ssl=ssl)
    __GLOBAL_CLIENT__.connect()


# TODO: might be better to get rid of the initialize flag, where is this used?
def set_global_client(client, initialize=True):
    """
    Set the global client to the given FetchcoreClient instance. The global client is used as the default client when
    making calls like save() or load() on resources.
    :param client: The FetchcoreClient instance to set as the global client.
    :type client: fetchcore.client.FetchcoreClient
    :param initialize: If true, an attempt to make a connection will be made immediately.
    :type initialize: bool
    :raise fetchcore.exceptions.ConnectionError: Thrown if there is a problem creating communicating with Fetchcore.
    """
    global __GLOBAL_CLIENT__
    __GLOBAL_CLIENT__ = client
    if initialize:
        __GLOBAL_CLIENT__.connect()
