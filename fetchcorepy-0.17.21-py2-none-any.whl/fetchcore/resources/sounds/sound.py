# Copyright 2016 Fetch Robotics Inc.
# Author(s): Russell Toris

# Futures
from __future__ import unicode_literals

# Standard library
import os

# Fetchcore
from fetchcore import configuration, exceptions
from fetchcore.resources import TimestampedResource


class Sound(TimestampedResource):
    """
    Sound contains information about sound files.
    """

    # The endpoint in Fetchcore for sounds
    endpoint = 'sounds'

    def __init__(self, id=None, name=None, file=None, created=None, modified=None, **kwargs):
        """
        :param id: The ID of the sound (assigned automatically upon creation).
        :param name: A human-readable name of the sound.
        :param file: The sound file as either the path to it or the file itself.
        :param created: The date and time of this sound's creation (assigned automatically).
        :param modified: The date and time this sound was last modified (updated automatically).
        """
        super(Sound, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name

        if file is not None:
            try:
                if os.path.isfile(file):
                    self.set_file_from_path(file)
                else:
                    self.file = file
            except TypeError:
                self.file = file

    @property
    def name(self):
        """
        Get the human-readable name of the sound.
        :return: The sound name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """
        Set the human-readable name of the sound.
        :param string name: The sound name.
        :raise fetchcore.exceptions.ValidationError:: Thrown if value is not a string or if value is an empty string.
        """
        if isinstance(name, basestring):
            # Server does not allow name to be blank
            if not name:
                raise exceptions.ValidationError("Sound name cannot be empty.")
            self._set('name', name)
        else:
            raise exceptions.ValidationError("Sound name must be a string, not a %s." % type(name).__name__)

    @property
    def file_url(self):
        """
        Get the URL of the sound file on the server.
        :return: The direct URL of this sound's file.
        """
        try:
            self._get('id')
            return "%s/%s/file" % (self.endpoint, str(id))
        except exceptions.UndefinedFieldError:
            return None

    @property
    def file(self):
        """
        Get the binary data of this sound's file in string form.
        :return: The binary data of this sound's file in string form.
        """
        return self._get('file')

    @file.setter
    def file(self, f):
        """
        Set the raw base file.
        :param f: (string|file) The file object or binary data string for the file.
        :raises: fetchcore.exceptions.ValidationError: Thrown if file is neither a string nor a file object.
        """
        if isinstance(f, basestring):
            self._set('file', f)
        elif isinstance(f, file):
            # We were provided a file object, so convert it to string and assign it
            self._set('file', f.read())
        else:
            raise exceptions.ValidationError(
                "File must be either a file object or string, not a %s." % type(f).__name__
            )

    def set_file_from_path(self, path):
        """
        Set the raw base file from a path.
        :param file: The file to upload.
        :raises fetchcore.exceptions.ValidationError: if path is either not a string or an invalid path.
        """
        if isinstance(path, basestring) and os.path.isfile(path):
            with open(path, 'rb') as opened_file:
                self._set('file', opened_file.read())
        else:
            raise exceptions.ValidationError(
                "Given path %s of type %s is not a valid path." % (path, type(path).__name__)
            )

    def _get_request_args_from_dict(self):
        """
        Extract request arguments from our JSON dict.
        :return: A kwarg dictionary dependent on the existence of the sound's file field.
        """
        data = self.to_json_dict()
        file_data = data.pop('file', None)

        if file_data:
            request_kwargs = {'data': data, 'files': {'file': ('sound.wav', file_data)}}
        else:
            request_kwargs = {'json': data}

        return request_kwargs

    def save(self, _=None):
        """
        Overwrites base class save. Sounds are immutable and cannot be deleted on the server.
        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise exceptions.UnsupportedOperation("Sounds are immutable and cannot be saved on the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Sounds are immutable and cannot be updated on the server.
        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise exceptions.UnsupportedOperation("Sounds are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """Overwrites base class delete. Sounds are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise exceptions.UnsupportedOperation("Sounds are immutable and cannot be deleted on the server.")

    def refresh(self, client=None, ignore_file=False):
        """
        Refresh this resource instance with the latest data from the server. This calls the inherited method, and then
        makes an extra request for the sound.

        :param client: The client that should be used (if None, the global Fetchcore client is used).
        :param ignore_file: If the file load should be skipped.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to Fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if not client:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Call main refresh
        super(Sound, self).refresh(client=client)

        # Download the sound file
        try:
            file_data = self.load_url_content(self.file_url, client=client)
            if file_data is not None:
                self._set('file', file_data)
        except exceptions.DoesNotExist:
            # The file doesn't exist, so pop it off to make sure it's None as well
            self._pop('file')

    @classmethod
    def load(cls, identifier, client=None):
        """
        Load the resource from the Fetchcore server with the given identifier. This calls the original code, and then
        makes an extra request for the file.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global Fetchcore client is used).
        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to Fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint, identifier)
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with unique identifier '%s' does not exist on the server." % (cls.__name__, str(identifier))
            )

        try:
            file_url = "sounds/%s/file" % str(response['id'])
            file_data = cls.load_url_content(file_url, client=client)
            if file_data is not None:
                response['file'] = file_data
        except TypeError:
            # NoneType response (disconnected)
            return None
        except (KeyError, exceptions.DoesNotExist):
            # Response didn't come with an ID or file doesn't exist
            pass

        if not response:
            raise exceptions.ConnectionError("Received no response when attempting to load resource.")
        file_object = cls.set_response(response)
        file_object.refresh(client)

        return file_object

    @classmethod
    def list(cls, client=None, page=None, amount=None, offset=None):
        """
        List all of the given resource from the Fetchcore server.
        :param client: The client that should be used (if None, the global Fetchcore client is used).
        :return: The loaded resources from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to Fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint, page=page, amount=amount, offset=offset)
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s does not exist on the server." % cls.__name__
            )

        sound_list = []
        for i in range(response['count']):
            result = response['results'][i]
            if result.get('id'):
                try:
                    file_url = "sounds/%s/file" % str(result['id'])
                    file_data = cls.load_url_content(file_url, client=client)
                    result['file'] = file_data
                except exceptions.DoesNotExist:
                    pass
            sound_object = cls.set_response(result)
            sound_list.append(sound_object)

        return sound_list
