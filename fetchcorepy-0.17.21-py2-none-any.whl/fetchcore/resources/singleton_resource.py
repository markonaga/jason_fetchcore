# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore
from fetchcore.exceptions import UnsupportedOperation
from fetchcore.resources import TimestampedResource


class SingletonResource(TimestampedResource):
    """
    Base class for all singleton Fetchcore resources. A singleton resource has a known ID.
    """

    # Singleton models must not have lookup keys passed in, so set up a None property
    pk = "lookup_key"
    lookup_key = None

    def __init__(self, id=None, created=None, modified=None, **kwargs):
        """Creates a new Resource with the given optional arguments.

        :param int id: The ID of the resource (assigned automatically upon creation).
        :param created: The created timestamp (assigned automatically).
        :param modified: The modification timestamp (updated automatically).
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(SingletonResource, self).__init__(created=created, modified=modified)

        # ID will always be 1 as a singleton resource
        self._set("id", 1)

    @classmethod
    def list(cls, client=None, page=None, offset=None, amount=None):
        """
        Overwrites base class list. Singleton resources do not need list because you only have one resource.

        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Singleton resources cannot be listed.")

    @classmethod
    def load(cls, identifier=None, client=None):
        """Load the resource from the fetchcore server with the given identifier.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :return: The loaded resource from the server.
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        return super(SingletonResource, cls).load(identifier=None, client=client)
