# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Niharika Arora

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.exceptions import ValidationError, UnsupportedOperation
from fetchcore.utils import Number


class PoseGroupDraft(TimestampedResource):
    """
    Class for Fetchcore map pose groups.
    """

    # The endpoint in fetchcore for pose groups
    endpoint = 'maps/annotations/draft/groups/poses'

    read_only_fields = ['poses']

    def __init__(self, id=None, name=None, map=None, modifiers=None, pose_group=None,
                 poses=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose group.
        :param string name: A human-readable name of the pose group.
        :param map: The map associated with this pose group.
        :param modifiers: The users who have modified this annotation.
        :param pose_group: The pose group associated with this pose group draft.
        :param poses: The poses that consist of this pose group.
        :param created: (string|datetime.datetime) The date and time of this pose group's creation.
        :param modified: (string|datetime.datetime) The date and time this pose group was last modified.
        """
        super(PoseGroupDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.modifiers = modifiers
        self.name = name
        self.map = map
        if pose_group:
            self.pose_group_id = pose_group
        if poses is None:
            self._set('poses', [])
        elif not isinstance(poses, list):
            raise ValidationError("Poses must be a list, not a %s." % type(poses).__name__)
        else:
            self._set('poses', poses)

    @property
    def poses(self):
        """Get the poses associated with this pose group.

        :return: The poses
        """
        return self._get("poses")

    @property
    def name(self):
        """Gets the name of this pose group.

        :return: The pose group name
        """
        return self._get("name")

    @name.setter
    def name(self, value):
        """Sets the name of this pose group.

        :param value: The pose group name
        :raises Validation Error if value is not a string or is an empty string
        """
        if isinstance(value, basestring):
            if not value:
                raise ValidationError("Pose group name cannot be an empty string")
            self._set("name", value)
        else:
            raise ValidationError("Pose group name must be a string, not a %s" % type(value).__name__)

    @property
    def map_id(self):
        """Get the associated pose group map ID for this pose group.

        :return: The pose group map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated pose group map ID for this pose group.

        :param integer map_id: The pose group map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Pose group map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Pose group map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated pose group map for this pose group.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated pose group map for this pose group.

        :param map: (integer|Map) An pose group map or pose group map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not an pose group map object or an integer or
            None.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map (%s is %s).' % (map, type(map).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def pose_group_id(self):
        """Get the associated pose group ID for this pose group draft.

        :return: The pose group ID.
        """
        return self._get('pose_group')

    @pose_group_id.setter
    def pose_group_id(self, pose_group_id):
        """Set the associated pose group ID for this pose group draft.

        :param integer pose_group_id: The pose group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose_group_id not a finite positive integer.
        """
        if pose_group_id is None:
            self._set('pose_group', pose_group_id)
        elif Number.is_integer(pose_group_id):
            if not Number.is_finite_positive(pose_group_id):
                raise ValidationError("Pose group ID must be finite positive (item is %s)." % pose_group_id)
            self._set('pose_group', pose_group_id)
        else:
            raise ValidationError("Pose group ID must be an integer (%s is %s)."
                                  % (pose_group_id, type(pose_group_id).__name__))


class PoseGroup(PoseGroupDraft):
    """
    Class for Fetchcore map pose groups.
    """

    # The endpoint in fetchcore for pose groups
    endpoint = 'maps/annotations/groups/poses'

    read_only_fields = ['poses']

    def __init__(self, id=None, name=None, map=None, modifiers=None, poses=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose group
        :param string name: A human-readable name of the pose group
        :param created: (string|datetime.datetime) The date and time of this pose group's creation.
        :param modified: (string|datetime.datetime) The date and time this pose group was last modified.
        """
        super(PoseGroup, self).__init__(id=id, created=created, modified=modified, name=name, map=map, poses=poses,
                                        modifiers=modifiers, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")
