# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Futures
from __future__ import unicode_literals

# Standard library
import copy
import os

# fetchcore
from fetchcore import configuration, exceptions
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number


class AccessPoint(TimestampedResource):
    """Maps contain information about where a robot is allowed to go."""

    # The endpoint in fetchcore for access point maps.
    endpoint = 'maps/wifi/aps'

    def __init__(self, id=None, name=None, resolution=None, wifi_map=None, image=None,
                 created=None, modified=None, **kwargs):
        """
        :param int id: The ID of the map (assigned automatically upon creation).
        :param string name: A human-readable name of the map.
        :param int wifi_map: The map that this access point map was generated with.
        :param float resolution: The resolution of the map in meters/pixel.
        :param image: The raw, unedited base map image in file or string format, or the path to it.
        :type image: :mod:`string` or :class:`~__builtin__.file`
        :param created: The date and time of this map's creation (assigned automatically).
        :type created: :mod:`string` or :class:`~datetime.datetime`
        :param modified: The date and time this map was last modified (updated automatically).
        :type modified: :mod:`string` or :class:`~datetime.datetime`
        """
        super(AccessPoint, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.name = name
        self.resolution = resolution
        try:
            if os.path.isfile(image):
                self.set_image_from_path(image)
            else:
                self.image = image
        except TypeError:
            self.image = image
        self.wifi_map = wifi_map

    @classmethod
    def set_response(cls, response):
        """This will make it possible for inherited classes to edit the data that is received from the server.

        :param response: The data that is received from the server

        :return: The data that will be loaded
        """
        response_dict = copy.deepcopy(response)
        return super(AccessPoint, cls).set_response(response_dict)

    @property
    def name(self):
        """Get the human-readable name of the map.

        :return: The map name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """Set the human-readable name of the map.

        :param string name: The map name.
        :raise fetchcore.exceptions.ValidationError:: Thrown if value is not a string or if value is an empty string.
        """
        if isinstance(name, basestring):
            # Server does not allow name to be blank
            if not name:
                raise exceptions.ValidationError("Map name cannot be empty.")
            self._set('name', name)
        else:
            raise exceptions.ValidationError("Map name must be a string, not a %s." % type(name).__name__)

    @property
    def resolution(self):
        """Get the resolution of the map in meters/pixel.

        :return: The map resolution
        """
        return self._get("resolution")

    @resolution.setter
    def resolution(self, resolution):
        """Set the resolution of the map in meters/pixel.

        :param float resolution: The map resolution.
        :raise fetchcore.exceptions.ValidationError: Thrown if resolution is not a finite non-negative number.
        """
        if Number.is_real_number(resolution):
            if not Number.is_finite_non_negative(resolution):
                raise exceptions.ValidationError(
                    "Resolution must be a finite non-negative number (resolution is %s)" % resolution)
            self._set("resolution", resolution)
        else:
            raise exceptions.ValidationError("Resolution must be a number (resolution is %s)" % resolution)

    @property
    def wifi_map(self):
        """Get the wifi map ID that generated this map.

        :return: The map ID.
        """
        return self._get('wifi_map')

    @wifi_map.setter
    def wifi_map(self, map_id):
        """Set the map ID that generated this map.

        :param integer map: The map ID.
        :raise fetchcore.exceptions.ValidationError:: Thrown if map_id not a finite positive integer.
        """
        if map_id is None:
            self._set('wifi_map', map_id)
        elif Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise exceptions.ValidationError("Wifi map ID must be finite positive (item is %s)." % map_id)
            self._set('wifi_map', map_id)
        else:
            raise exceptions.ValidationError(
                "Wifi map ID must be an integer (%s is %s)." % (map_id, type(map_id).__name__))

    @property
    def image_url(self):
        """Get the URL of the base image for this map.

        The base image will always be the the maps URL plus the PK and "image", e.g. "maps/0/image"

        :return: The direct URL of this map's base image.
        """
        if self.id:
            return self._get_image_url_from_id(self.id)
        else:
            return None

    @classmethod
    def _get_image_url_from_id(cls, id):
        """Get the base image URL from a given ID."""
        return "%s/%s/image" % (cls.endpoint, id)

    @property
    def image(self):
        """Get the binary data of this map's base image in string form."""
        return self._get('image')

    @image.setter
    def image(self, image):
        """Set the raw base map image.

        :param image: (string|file) The file object or binary data string for the base map image
        :raises: fetchcore.exceptions.ValidationError: Thrown if image is neither a string nor a file object.
        """
        if isinstance(image, basestring):
            self._set("image", image)
        elif isinstance(image, file):
            # We were provided a file object, so convert it to string and assign it
            self._set("image", image.read())
        else:
            raise exceptions.ValidationError("Image must be either a file object or string, not a %s."
                                             % type(image).__name__)

    def set_image_from_path(self, path):
        """Set the raw base image from a path.

        :param path: The path of the image to upload.
        :raises fetchcore.exceptions.ValidationError: if path is either not a string or an invalid path.
        """
        if isinstance(path, basestring) and os.path.isfile(path):
            with open(path, 'rb') as opened_image:
                self._set("image", opened_image.read())
        else:
            raise exceptions.ValidationError(
                "Given path %s of type %s is not a valid path." % (path, type(path).__name__))

    def _get_request_args_from_dict(self):
        """Extract request arguments from our JSON dict.

        :return: A kwarg dictionary dependent on the existence of the Map's image field.
        """
        data = self.to_json_dict()
        image_data = data.pop('image', None)

        if image_data:
            request_kwargs = {'data': data, 'files': {'image': ('image.png', image_data)}}
        else:
            request_kwargs = {'json': data}

        return request_kwargs

    def save(self, client=None):
        """
        Save the current resource to the server. If the resource does not yet exist, it will be created. If it already
        exists all fields on the server will be overwritten with the current values.

        This method has extra behaviors for dealing with the Map's image field. It does some pretty nasty method
        calls due to name mangling in parent methods, but it's necessary to function.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.ValidationError: Thrown if there was an issue validating the data on the server.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        request_kwargs = self._get_request_args_from_dict()

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                # TODO if map add 'format' argument
                response = client.post(self.endpoint, **request_kwargs)
            else:
                response = client.put(self.endpoint, getattr(self, self.pk), **request_kwargs)
            # Save back the data we got
            for key, value in response.iteritems():
                self.set_values(key, value)
                self._Resource__set_since_update.discard(key)
            if 'files' in request_kwargs:
                self._Resource__set_since_update.discard('image')
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Saving or updating of the current data is unsupported by fetchcore.")

    def update(self, client=None):
        """
        Update the resource on the server with fields changed for the current resource since the last update call.

        This method includes extra logic for handling Map's image. It also does some pretty nasty method calls due
        to name mangling, but it's necessary for function.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.ValidationError: Thrown if there was an issue validating the data on the server.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist on the server (updates only).
        :raise fetchcore.exceptions.UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        request_kwargs = self._get_request_args_from_dict()

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                raise exceptions.DoesNotExist("You cannot update a resource that is not on the server.")
            else:
                # Generate minimal PATCH update
                patch_data = {}
                data_key = 'data' if len(request_kwargs) == 2 else 'json'
                json_data = request_kwargs.get(data_key)

                if 'image' in self._Resource__set_since_update:
                    # Base image has changed, so just discard it from the set (it should already be in request_kwargs)
                    self._Resource__set_since_update.discard('image')
                else:
                    # Base image hasn't changed, so just remove it safely (if it exists)
                    request_kwargs.pop('files', None)

                for field in list(self._Resource__set_since_update):
                    patch_data[field] = json_data[field]
                    self._Resource__set_since_update.discard(field)

                request_kwargs[data_key] = patch_data

                client.patch(self.endpoint, getattr(self, self.pk), **request_kwargs)

        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Deleting the current data is unsupported by fetchcore.")

    def refresh(self, client=None):
        """
        Refresh this resource instance with the latest data from the server. This calls the inherited method, and then
        makes an extra request for the base image.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if not client:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Call main refresh
        super(AccessPoint, self).refresh(client=client)

        # Download the base image if we have an ID assigned and it exists
        if self.image_url:
            try:
                image_data = self.load_url_content(self.image_url, client=client)
                self._set('image', image_data)
            except exceptions.DoesNotExist:
                # The image doesn't exist, so pop it off to make sure it's None as well
                self._pop('image')

    @classmethod
    def load(cls, identifier, client=None):
        """
        Load the resource from the fetchcore server with the given identifier. This calls the original code, and then
        makes an extra request for the base image.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).

        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint, identifier)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with unique identifier '%s' does not exist on the server." % (cls.__name__, str(identifier))
            )

        if response.get('id'):
            try:
                image_url = cls._get_image_url_from_id(response['id'])
                image_data = cls.load_url_content(image_url, client=client)
                response['image'] = image_data
            except exceptions.DoesNotExist:
                pass

        map_object = cls.set_response(response)
        map_object.refresh(client)

        return map_object

    @classmethod
    def list(cls, client=None):
        """List all of the given resource from the fetchcore server.

        :param client: The client that should be used (if None, the global fetchcore client is used).

        :return: The loaded resources from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s does not exist on the server." % cls.__name__
            )

        map_list = []
        for i in range(response['count']):
            result = response['results'][i]
            if result.get('id'):
                try:
                    image_url = cls._get_image_url_from_id(result['id'])
                    image_data = cls.load_url_content(image_url, client=client)
                    result['image'] = image_data
                except exceptions.DoesNotExist:
                    pass
            map_object = cls.set_response(result)
            map_list.append(map_object)

        return map_list
