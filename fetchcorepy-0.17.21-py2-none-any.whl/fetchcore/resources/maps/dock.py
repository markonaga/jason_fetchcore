# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class DockDraft(TimestampedResource):
    """
    Class for fetchcore map dock drafts.
    """

    # The endpoint in fetchcore for dock
    endpoint = 'maps/annotations/draft/docks'

    def __init__(self, id=None, x=None, y=None, theta=None, group=None, map=None, modifiers=None, dock=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the dock
        :param float x: The X position of the dock (in meters) within the associated map
        :param float y: The Y position of the dock (in meters) within the associated map
        :param float theta: The angle of the dock (in radians) within the associated map
        :param group: (integer|DockGroupDraft) The dock group draft associated with this dock draft.
        :param map: (integer|Map) The map or map ID this dock belongs to
        :param modifiers: The users who have modified this annotation.
        :param dock: The dock that is associated with this dock draft.
        :param created: (string|datetime.datetime) The date and time of this dock's creation.
        :param modified: (string|datetime.datetime) The date and time this dock was last modified.
        """
        super(DockDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.x = x
        self.y = y
        self.theta = theta
        self.map = map
        self.modifiers = modifiers
        if group:
            self.group = group
        if dock:
            self.dock_id = dock

    @property
    def x(self):
        """Gets the X position of the dock within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the dock within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the dock within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the dock within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def theta(self):
        """Gets the angle of the dock (in radians) within the associated map

        :return: The angle
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Set the angle of the dock (in radians) within the associated map.

        :param float theta: The dock angle.
        :raise fetchcore.exceptions.ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))

    @property
    def map_id(self):
        """Get the associated dock map ID for this dock.

        :return: The dock map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated dock map ID for this dock.

        :param integer map_id: The dock map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Dock map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Dock map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated dock map for this dock.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated map for this dock.

        :param map: (integer|Map) An dock map or dock map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not an dock map object or an integer or None.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map (%s is %s).' % (map, type(map).__name__))

    @property
    def group_id(self):
        """Get the associated dock group ID for this dock.

        :return: The dock group ID.
        """
        return self._get('group')

    @group_id.setter
    def group_id(self, group_id):
        """Set the associated dock group ID for this dock.

        :param integer group_id: The dock group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group_id is not a finite positive integer.
        """
        if group_id is None:
            self._set('group', group_id)
        elif Number.is_integer(group_id):
            if not Number.is_finite_positive(group_id):
                raise ValidationError("Dock group ID must be finite positive (item is %s)." % group_id)
            self._set('group', group_id)
        else:
            raise ValidationError("Dock group ID must be an integer (%s is %s)."
                                  % (group_id, type(group_id).__name__))

    @property
    def group(self):
        """Get the associated dock group for this dock.

        :return: The DockGroup object.
        """
        from fetchcore.resources.maps import DockGroupDraft
        return None if self.group_id is None else DockGroupDraft.load(self.group_id)

    @group.setter
    def group(self, group):
        """Set the associated dock group for this dock.

        :param group: (integer|DockGroup) An dock group or dock group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group is not an dock group object or an
        integer or None.
        """
        from fetchcore.resources.maps import DockGroupDraft
        if isinstance(group, DockGroupDraft):
            if not group.is_set("id"):
                group.save()
            self.group_id = group.id
        elif group is None or isinstance(group, int):
            self.group_id = group
        else:
            raise ValidationError('Dock group can only be an integer, DockGroup or None (%s is %s).'
                                  % (group, type(group).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def dock_id(self):
        """Get the associated dock ID for this dock draft.

        :return: The dock ID.
        """
        return self._get('dock')

    @dock_id.setter
    def dock_id(self, dock_id):
        """Set the associated dock ID for this dock draft.

        :param integer dock_id: The dock ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if dock_id not a finite positive integer.
        """
        if dock_id is None:
            self._set('dock', dock_id)
        elif Number.is_integer(dock_id):
            if not Number.is_finite_positive(dock_id):
                raise ValidationError("Dock ID must be finite positive (item is %s)." % dock_id)
            self._set('dock', dock_id)
        else:
            raise ValidationError("Dock ID must be an integer (%s is %s)."
                                  % (dock_id, type(dock_id).__name__))


class Dock(DockDraft):
    """
    Class for Fetchcore map docks.
    """

    # The endpoint in fetchcore for dock
    endpoint = 'maps/annotations/docks'

    def __init__(self, id=None, x=None, y=None, theta=None, group=None, map=None, modifiers=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the dock
        :param float x: The X position of the dock (in meters) within the associated map
        :param float y: The Y position of the dock (in meters) within the associated map
        :param float theta: The angle of the dock (in radians) within the associated map
        :param group: (integer|DockGroup) The dock group associated with this dock.
        :param created: (string|datetime.datetime) The date and time of this dock's creation.
        :param modified: (string|datetime.datetime) The date and time this dock was last modified.
        """
        super(Dock, self).__init__(id=id, map=map, modifiers=modifiers, group=group,
                                   x=x, y=y, theta=theta, created=created, modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def group(self):
        """Get the associated dock group for this dock.

        :return: The DockGroup object.
        """
        from fetchcore.resources.maps import DockGroup
        return None if self.group_id is None else DockGroup.load(self.group_id)

    @group.setter
    def group(self, group):
        """Set the associated dock group for this dock.

        :param group: (integer|DockGroup) An dock group or dock group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group is not an dock group object or an
        integer or None.
        """
        from fetchcore.resources.maps import DockGroup
        if isinstance(group, DockGroup):
            if not group.is_set("id"):
                group.save()
            self.group_id = group.id
        elif group is None or isinstance(group, int):
            self.group_id = group
        else:
            raise ValidationError('Dock group can only be an integer, DockGroup or None (%s is %s).'
                                  % (group, type(group).__name__))
