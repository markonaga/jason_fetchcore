# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class PointDraft(TimestampedResource):
    """
    Class for Fetchcore map points.
    """

    # The endpoint in fetchcore for point
    endpoint = 'maps/annotations/draft/points'

    read_only_fields = ['area']

    def __init__(self, id=None, x=None, y=None, area=None, modifiers=None, point=None, created=None, modified=None,
                 **kwargs):
        """
        :param integer id: The ID of the point.
        :param float x: The X position of the point (in meters) within the associated map.
        :param float y: The Y position of the point (in meters) within the associated map.
        :param area: The area that created this point.
        :param modifiers: The users who have modified this annotation.
        :param point: The point draft that is associated with this point.
        :param created: (string|datetime.datetime) The date and time of this dock's creation.
        :param modified: (string|datetime.datetime) The date and time this dock was last modified.
        """
        super(PointDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.x = x
        self.y = y
        self.modifiers = modifiers
        if point:
            self.point_id = point
        if area is None:
            self._set('area', area)
        elif Number.is_integer(area):
            if not Number.is_finite_positive(area):
                raise ValidationError("Area must be finite positive (item is %s)." % area)
            self._set('area', area)
        else:
            raise ValidationError("Area must be an integer (%s is %s)." % (area, type(area).__name__))

    @property
    def area(self):
        """Get the area that this point belongs to.

        :return: The point's area.
        """
        return self._get('area')

    @property
    def x(self):
        """Gets the X position of the point within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the point within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the point within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the point within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y  must be a number (value is %s)" % value)

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def point_id(self):
        """Get the associated point ID for this point draft.

        :return: The point ID.
        """
        return self._get('point')

    @point_id.setter
    def point_id(self, point_id):
        """Set the associated point ID for this point draft.

        :param integer point_id: The point ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if point_id not a finite positive integer.
        """
        if point_id is None:
            self._set('point', point_id)
        elif Number.is_integer(point_id):
            if not Number.is_finite_positive(point_id):
                raise ValidationError("Point ID must be finite positive (item is %s)." % point_id)
            self._set('point', point_id)
        else:
            raise ValidationError("Point ID must be an integer (%s is %s)."
                                  % (point_id, type(point_id).__name__))


class Point(PointDraft):
    """
    Class for Fetchcore map points.
    """

    # The endpoint in fetchcore for point
    endpoint = 'maps/annotations/points'

    def __init__(self, id=None, x=None, y=None, area=None, modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the dock
        :param float x: The X position of the dock (in meters) within the associated map
        :param float y: The Y position of the dock (in meters) within the associated map
        :param created: (string|datetime.datetime) The date and time of this dock's creation.
        :param modified: (string|datetime.datetime) The date and time this dock was last modified.
        """
        super(Point, self).__init__(id=id, x=x, y=y, area=area, modifiers=modifiers, created=created, modified=modified,
                                    **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")
