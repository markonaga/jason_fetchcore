# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation
from fetchcore.resources.maps import SurveyNode, SurveyNodeDraft


class SurveyPathDraft(TimestampedResource):
    """
    Class for Fetchcore map survey path drafts.
    """

    # The endpoint in fetchcore for survey path drafts
    endpoint = 'maps/annotations/draft/survey/paths'

    read_only_fields = ['survey_nodes']

    def __init__(self, id=None, name=None, survey_nodes=None, map=None, modifiers=None, survey_path=None, created=None,
                 modified=None, **kwargs):
        """
        :param integer id: The ID of the survey path.
        :param string name: A human-readable name of the survey path.
        :param survey_nodes: The list of survey nodes that are associated with this survey path.
        :param map: The map this survey path is associated with.
        :param modifiers: The users who have modified this annotation.
        :param survey_path: The survey path that is associated with this survey path draft.
        :param created: The date and time of this survey path's creation.
        :param modified: The date and time this survey path was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        :type survey_nodes: list of :class:`~fetchcore.resources.maps.survey_node.SurveyNodeDraft` objects.
        """
        super(SurveyPathDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.name = name
        self.map = map
        self.modifiers = modifiers
        self._survey_nodes = []
        if survey_path:
            self.survey_path_id = survey_path
        if survey_nodes is None:
            self._set('survey_nodes', [])
        elif not isinstance(survey_nodes, list):
            raise ValidationError("Survey nodes must be a list, not a %s." % type(survey_nodes).__name__)
        else:
            for survey_node in survey_nodes:
                self.add_survey_node(survey_node)
            self._set('survey_nodes', self._survey_nodes)

    @property
    def name(self):
        """Gets the name of this survey path.

        :return: The survey path name.
        """
        return self._get("name")

    @name.setter
    def name(self, value):
        """Sets the name of this survey path.

        :param value: The survey path name.
        :raises Validation Error if value is not a string or is an empty string.
        """
        if isinstance(value, basestring):
            if not value:
                raise ValidationError("Name cannot be an empty string")
            self._set("name", value)
        else:
            raise ValidationError("Name must be a string, not a %s" % type(value).__name__)

    @property
    def map_id(self):
        """Get the associated map ID for this survey path.

        :return: The map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated map ID for this survey path.

        :param integer map_id: The map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Survey path map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Survey path map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated map for this survey path.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated map for this survey path.

        :param map: (integer|Map) A map object or map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not a map object or an integer.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map object (%s is %s).' % (map, type(map).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def survey_path_id(self):
        """Get the associated survey path ID for this survey path draft.

        :return: The survey path ID.
        """
        return self._get('survey_path')

    @survey_path_id.setter
    def survey_path_id(self, survey_path_id):
        """Set the associated survey path ID for this survey path draft.

        :param integer survey_path_id: The survey path ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_path_id not a finite positive integer.
        """
        if survey_path_id is None:
            self._set('survey_path', survey_path_id)
        elif Number.is_integer(survey_path_id):
            if not Number.is_finite_positive(survey_path_id):
                raise ValidationError("Survey path ID must be finite positive (item is %s)." % survey_path_id)
            self._set('survey_path', survey_path_id)
        else:
            raise ValidationError("Survey path ID must be an integer (%s is %s)."
                                  % (survey_path_id, type(survey_path_id).__name__))

    @property
    def survey_nodes(self):
        """Gets a list of SurveyNode objects.

        :return: The list of SurveyNode objects.
        """
        return self._get("survey_nodes")

    def add_survey_node(self, survey_node):
        """
        Adds a Survey Node to the Survey Path

        :param survey_node: A SurveyNodeDraft object
        :raises ValidationError: if survey_node is not a list or an SurveyNode object
        """
        if isinstance(survey_node, SurveyNodeDraft):
            # If survey_node is a SurveyNodeDraft object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._survey_nodes.append(survey_node)
        elif isinstance(survey_node, int):
            self._survey_nodes.append(SurveyNodeDraft.load(survey_node))
        else:
            raise ValidationError("SurveyNodeDraft should either be an SurveyNodeDraft object or a "
                                  "int, not a %s" % type(survey_node).__name__)


class SurveyPath(SurveyPathDraft):
    """
    Class for Fetchcore map survey paths.
    """

    # The endpoint in fetchcore for survey paths
    endpoint = 'maps/annotations/survey/paths'

    def __init__(self, id=None, name=None, survey_nodes=None, map=None, modifiers=None, created=None, modified=None,
                 **kwargs):
        """
        :param integer id: The ID of the survey path.
        :param string name: A human-readable name of the survey path.
        :param survey_nodes: The list of survey nodes that are associated with this survey path.
        :param map: The map this survey path is associated with.
        :param created: The date and time of this survey path's creation.
        :param modified: The date and time this survey path was last modified.
        :type survey_nodes: list of :class:`~fetchcore.resources.maps.survey_node.SurveyNode` objects
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(SurveyPath, self).__init__(id=id, name=name, map=map, modifiers=modifiers, survey_nodes=survey_nodes,
                                         created=created, modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    def add_survey_node(self, survey_node):
        """
        Adds a Survey Node to the Survey Path

        :param survey_node: A SurveyNode object
        :raises ValidationError: if survey_node is not a int or SurveyNode
        """
        if isinstance(survey_node, SurveyNode):
            # If survey_node is a SurveyNode object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._survey_nodes.append(survey_node)
        elif isinstance(survey_node, int):
            self._survey_nodes.append(SurveyNode.load(survey_node))
        else:
            raise ValidationError("SurveyNode should either be an SurveyNode object or a "
                                  "int, not a %s" % type(survey_node).__name__)
