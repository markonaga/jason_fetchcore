# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Russell Toris, Michael Hwang

# Futures
from __future__ import unicode_literals

# Standard library
import copy
import os

# fetchcore
from fetchcore import configuration, exceptions
from fetchcore.resources import TimestampedResource, Action
from fetchcore.utils import Number


class Map(TimestampedResource):
    """Maps contain information about where a robot is allowed to go."""

    # The endpoint in fetchcore for maps.
    endpoint = 'maps'
    annotations_endpoint = 'maps/%s/annotations'

    def __init__(self, id=None, name=None, in_progress=True, resolution=None, x=0.0, y=0.0, theta=0.0, action=None,
                 image=None, created=None, modified=None, **kwargs):
        """
        :param int id: The ID of the map (assigned automatically upon creation).
        :param string name: A human-readable name of the map.
        :param bool in_progress: If true, the map is currently building and not final.
        :param float resolution: The resolution of the map in meters/pixel.
        :param float x: The X position of the lower-left corner of the map (in meters).
        :param float y: The Y position of the lower-left corner of the map (in meters).
        :param float theta: The theta angle of the lower-left corner of the map (in radians).
        :param action: The action that generated this map.
        :type action: :class:`int` or :class:`~fetchcore.resources.tasks.actions.action.Action`
        :param image: The raw, unedited base map image in file or string format, or the path to it.
        :type image: :mod:`string` or :class:`~__builtin__.file`
        :param created: The date and time of this map's creation (assigned automatically).
        :type created: :mod:`string` or :class:`~datetime.datetime`
        :param modified: The date and time this map was last modified (updated automatically).
        :type modified: :mod:`string` or :class:`~datetime.datetime`
        """
        super(Map, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.name = name
        self.in_progress = in_progress
        self.resolution = resolution
        self.x = x
        self.y = y
        self.theta = theta

        if image is not None:
            try:
                if os.path.isfile(image):
                    self.set_image_from_path(image)
                else:
                    self.image = image
            except TypeError:
                self.image = image

        if action:
            self.action = action

        # Inner cached annotations
        self._areas = None
        self._docks = None
        self._dock_groups = None
        self._edges = None
        self._nodes = None
        self._poses = None
        self._pose_groups = None
        self._queues = None
        self._survey_paths = None
        self._survey_nodes = None
        self._survey_poses = None

    @classmethod
    def set_response(cls, response):
        """This will make it possible for inherited classes to edit the data that is received from the server.

        :param response: The data that is received from the server

        :return: The data that will be loaded
        """
        response_dict = copy.deepcopy(response)
        return super(Map, cls).set_response(response_dict)

    # TODO: add has_draft

    def create_new_draft(self, version=None, client=None):
        """Create a new draft assocaited with this map. Note that a call to this function will clear any old draft data
        associated with this map. A call to :func:`has_draft()` should be made to check if a working draft exists to be
        safe.

        :param version: The version number to copy into the draft. If negative, the HEAD revision is used.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Create the endpoint to POST the draft to
        rev = 'HEAD' if not version else str(version)
        endpoint = self.endpoint + '/' + str(self.id) + '/revisions/' + rev + '/draft/create/'
        # TODO: catch not found and others
        client.post(endpoint, None)

    def publish_draft(self, client=None):
        """Publish the current draft to the live map.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Create the endpoint to POST the draft to
        endpoint = self.endpoint + '/' + str(self.id) + '/revisions/draft/publish/'
        # TODO: catch not found and others
        client.post(endpoint, None)

    @property
    def name(self):
        """Get the human-readable name of the map.

        :return: The map name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """Set the human-readable name of the map.

        :param string name: The map name.
        :raise fetchcore.exceptions.ValidationError:: Thrown if value is not a string or if value is an empty string.
        """
        if isinstance(name, basestring):
            # Server does not allow name to be blank
            if not name:
                raise exceptions.ValidationError("Map name cannot be empty.")
            self._set('name', name)
        else:
            raise exceptions.ValidationError("Map name must be a string, not a %s." % type(name).__name__)

    @property
    def in_progress(self):
        """Get if the map is currently building and not final.

        :return: Says whether this map is being built.
        """
        return self._get('in_progress')

    @in_progress.setter
    def in_progress(self, in_progress):
        """Set if the map is currently building and not final.

        :param boolean in_progress: Says whether this map is being built.
        :raise fetchcore.exceptions.ValidationError: Thrown if in_progress is not a boolean.
        """
        if not isinstance(in_progress, bool):
            raise exceptions.ValidationError("In progress must be a bool, not a %s." % type(in_progress).__name__)
        else:
            self._set('in_progress', in_progress)

    @property
    def resolution(self):
        """Get the resolution of the map in meters/pixel.

        :return: The map resolution
        """
        return self._get("resolution")

    @resolution.setter
    def resolution(self, resolution):
        """Set the resolution of the map in meters/pixel.

        :param float resolution: The map resolution.
        :raise fetchcore.exceptions.ValidationError: Thrown if resolution is not a finite non-negative number.
        """
        if Number.is_real_number(resolution):
            if not Number.is_finite_non_negative(resolution):
                raise exceptions.ValidationError(
                    "Resolution must be a finite non-negative number (resolution is %s)" % resolution)
            self._set("resolution", resolution)
        else:
            raise exceptions.ValidationError("Resolution must be a number (resolution is %s)" % resolution)

    @property
    def x(self):
        """Gets the X position of the lower-left corner of the map (in meters).

        :return: The X position.
        """
        return self._get("x")

    @x.setter
    def x(self, x):
        """Sets the X position of the lower-left corner of the map (in meters).

        :param float x: The x position.
        :raise fetchcore.exceptions.ValidationError: Thrown if x is not a finite number.
        """
        if Number.is_real_number(x):
            if not Number.is_finite(x):
                raise exceptions.ValidationError("X position must be a finite non-negative number (x is %s)" % x)
            self._set("x", x)
        else:
            raise exceptions.ValidationError("X position must be a number (x is %s)" % x)

    @property
    def y(self):
        """Gets the Y position of the lower-left corner of the map (in meters).

        :return: The Y position.
        """
        return self._get("y")

    @y.setter
    def y(self, y):
        """Sets the Y position of the lower-left corner of the map (in meters).

        :param float y: The y position.
        :raise fetchcore.exceptions.ValidationError: Thrown if y is not a finite number.
        """
        if Number.is_real_number(y):
            if not Number.is_finite(y):
                raise exceptions.ValidationError("Y position must be a finite non-negative number (y is %s)" % y)
            self._set("y", y)
        else:
            raise exceptions.ValidationError("Y position must be a number (y is %s)" % y)

    @property
    def theta(self):
        """Get the angle of the lower-left corner of the map (in radians).

        :return: The map angle
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Set the angle of the lower-left corner of the map (in radians).

        :param float theta: The map angle.
        :raise fetchcore.exceptions.ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise exceptions.ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))

    @property
    def action_id(self):
        """Get the action ID that generated this map.

        :return: The action ID.
        """
        return self._get('action')

    @action_id.setter
    def action_id(self, action_id):
        """Set the action ID that generated this map.

        :param integer action_id: The action ID.
        :raise fetchcore.exceptions.ValidationError:: Thrown if action_id not a finite positive integer.
        """
        if action_id is None:
            self._set('action', action_id)
        elif Number.is_integer(action_id):
            if not Number.is_finite_positive(action_id):
                raise exceptions.ValidationError("Action ID must be finite positive (item is %s)." % action_id)
            self._set('action', action_id)
        else:
            raise exceptions.ValidationError(
                "Action ID must be an integer (%s is %s)." % (action_id, type(action_id).__name__))

    @property
    def action(self):
        """Get the action object that generated this map.

        :return: The Action object.
        """
        return None if self.action_id is None else Action.load(self.action_id)

    @action.setter
    def action(self, action):
        """Set the action object that generated this map.

        :param action: (integer|Action) An Action or action ID.
        :raise fetchcore.exceptions.ValidationError:: Thrown if action is not an action object, integer, or None.
        """
        if isinstance(action, Action):
            if not action.is_set("id"):
                action.save()
            self.action_id = action.id
        elif action is None or isinstance(action, int):
            self.action_id = action
        else:
            raise exceptions.ValidationError('Action can only be an integer, Action object or None (%s is %s).'
                                             % (action, type(action).__name__))

    @property
    def image_url(self):
        """Get the URL of the base image for this map.

        The base image will always be the the maps URL plus the PK and "image", e.g. "maps/0/image"

        :return: The direct URL of this map's base image.
        """
        if self.id:
            return self._get_image_url_from_id(self.id)
        else:
            return None

    @classmethod
    def _get_image_url_from_id(cls, id):
        """Get the base image URL from a given ID."""
        return "%s/%s/image" % (cls.endpoint, id)

    @property
    def image(self):
        """Get the binary data of this map's base image in string form."""
        return self._get('image')

    @image.setter
    def image(self, image):
        """Set the raw base map image.

        :param image: (string|file) The file object or binary data string for the base map image
        :raises: fetchcore.exceptions.ValidationError: Thrown if image is neither a string nor a file object.
        """
        if isinstance(image, basestring):
            self._set("image", image)
        elif isinstance(image, file):
            # We were provided a file object, so convert it to string and assign it
            self._set("image", image.read())
        else:
            raise exceptions.ValidationError("Base image must be either a file object or string, not a %s."
                                             % type(image).__name__)

    def set_image_from_path(self, path):
        """Set the raw base image from a path.

        :param path: The path of the image to upload.
        :raises fetchcore.exceptions.ValidationError: if path is either not a string or an invalid path.
        """
        if isinstance(path, basestring) and os.path.isfile(path):
            with open(path, 'rb') as opened_image:
                self._set("image", opened_image.read())
        else:
            raise exceptions.ValidationError(
                "Given path %s of type %s is not a valid path." % (path, type(path).__name__))

    def _get_request_args_from_dict(self):
        """Extract request arguments from our JSON dict.

        :return: A kwarg dictionary dependent on the existence of the Map's image field.
        """
        data = self.to_json_dict()
        image_data = data.pop('image', None)

        if image_data:
            request_kwargs = {'data': data, 'files': {'image': ('image.png', image_data)}}
        else:
            request_kwargs = {'json': data}

        return request_kwargs

    def save(self, client=None):
        """
        Save the current resource to the server. If the resource does not yet exist, it will be created. If it already
        exists all fields on the server will be overwritten with the current values.

        This method has extra behaviors for dealing with the Map's image field. It does some pretty nasty method
        calls due to name mangling in parent methods, but it's necessary to function.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.ValidationError: Thrown if there was an issue validating the data on the server.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        request_kwargs = self._get_request_args_from_dict()

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                # TODO if map add 'format' argument
                response = client.post(self.endpoint, **request_kwargs)
            else:
                response = client.put(self.endpoint, getattr(self, self.pk), **request_kwargs)
            # Save back the data we got
            for key, value in response.iteritems():
                self.set_values(key, value)
                self._Resource__set_since_update.discard(key)
            if 'files' in request_kwargs:
                self._Resource__set_since_update.discard('image')
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Saving or updating of the current data is unsupported by fetchcore.")

    def update(self, client=None):
        """
        Update the resource on the server with fields changed for the current resource since the last update call.

        This method includes extra logic for handling Map's image. It also does some pretty nasty method calls due
        to name mangling, but it's necessary for function.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.ValidationError: Thrown if there was an issue validating the data on the server.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist on the server (updates only).
        :raise fetchcore.exceptions.UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        request_kwargs = self._get_request_args_from_dict()

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                raise exceptions.DoesNotExist("You cannot update a resource that is not on the server.")
            else:
                # Generate minimal PATCH update
                patch_data = {}
                data_key = 'data' if len(request_kwargs) == 2 else 'json'
                json_data = request_kwargs.get(data_key)

                if 'image' in self._Resource__set_since_update:
                    # Base image has changed, so just discard it from the set (it should already be in request_kwargs)
                    self._Resource__set_since_update.discard('image')
                else:
                    # Base image hasn't changed, so just remove it safely (if it exists)
                    request_kwargs.pop('files', None)

                for field in list(self._Resource__set_since_update):
                    patch_data[field] = json_data[field]
                    self._Resource__set_since_update.discard(field)

                request_kwargs[data_key] = patch_data

                client.patch(self.endpoint, getattr(self, self.pk), **request_kwargs)

        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Deleting the current data is unsupported by fetchcore.")

    def refresh(self, client=None, ignore_image=False):
        """
        Refresh this resource instance with the latest data from the server. This calls the inherited method, and then
        makes an extra request for the base image.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :param ignore_image: If the image load should be skipped.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if not client:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Download annotations first
        annotations_response = client.get(self.annotations_endpoint % self.id)
        if not annotations_response:
            print "Failed to retrieve annotations. Aborting map refresh (ID: %s)." % self.id
            return
        else:
            # Cache the areas
            from fetchcore.resources.maps import Area
            self._areas = [Area.set_response(response) for response in annotations_response[0]['areas']]

            # Cache the docks
            from fetchcore.resources.maps import Dock
            self._docks = [Dock.set_response(response) for response in annotations_response[1]['docks']]

            # Cache the dock groups
            from fetchcore.resources.maps import DockGroup
            self._dock_groups = [DockGroup.set_response(response) for response in
                                 annotations_response[2]['dock_groups']]

            # Cache the edges
            from fetchcore.resources.maps import Edge
            self._edges = [Edge.set_response(response) for response in annotations_response[3]['edges']]

            # Cache the nodes
            from fetchcore.resources.maps import Node
            self._nodes = [Node.set_response(response) for response in annotations_response[4]['nodes']]

            # Cache the poses
            from fetchcore.resources.maps import Pose
            self._poses = [Pose.set_response(response) for response in annotations_response[5]['poses']]

            # Cache the pose groups
            from fetchcore.resources.maps import PoseGroup
            self._pose_groups = [PoseGroup.set_response(response) for response in
                                 annotations_response[6]['pose_groups']]

            # Cache the queues
            from fetchcore.resources.maps import Queue
            self._queues = [Queue.set_response(response) for response in annotations_response[7]['queues']]

            # Cache the survey_paths
            from fetchcore.resources.maps import SurveyPath
            self._survey_paths = [SurveyPath.set_response(response) for response in
                                  annotations_response[8]['survey_paths']]

            # Cache the survey_nodes
            from fetchcore.resources.maps import SurveyNode
            self._survey_nodes = [SurveyNode.set_response(response) for response in
                                  annotations_response[9]['survey_nodes']]

            # Cache the survey_poses
            from fetchcore.resources.maps import SurveyPose
            self._survey_poses = [SurveyPose.set_response(response) for response in
                                  annotations_response[10]['survey_poses']]

        # Call main refresh
        super(Map, self).refresh(client=client)

        # Download the base image if we have an ID assigned and it exists
        if not ignore_image and self.image_url:
            try:
                image_data = self.load_url_content(self.image_url, client=client)
                if image_data is not None:
                    self._set('image', image_data)
            except exceptions.DoesNotExist:
                # The image doesn't exist, so pop it off to make sure it's None as well
                self._pop('image')

    @classmethod
    def load(cls, identifier, client=None, ignore_image=False):
        """
        Load the resource from the fetchcore server with the given identifier. This calls the original code, and then
        makes an extra request for the base image.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :param ignore_image: If the image load should be skipped.

        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint, identifier)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with unique identifier '%s' does not exist on the server." % (cls.__name__, str(identifier))
            )

        if not ignore_image:
            try:
                image_url = cls._get_image_url_from_id(response['id'])
                image_data = cls.load_url_content(image_url, client=client)
                if image_data is not None:
                    response['image'] = image_data
            except TypeError:
                # NoneType response (disconnected)
                return None
            except (KeyError, exceptions.DoesNotExist):
                # Response didn't come with an ID or image doesn't exist
                pass

        if not response:
            raise exceptions.ConnectionError("Received no response when attempting to load resource.")
        map_object = cls.set_response(response)
        map_object.refresh(client, ignore_image=ignore_image)

        return map_object

    @classmethod
    def list(cls, client=None, page=None, amount=None, offset=None):
        """List all of the given resource from the fetchcore server.

        :param client: The client that should be used (if None, the global fetchcore client is used).

        :return: The loaded resources from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint, page=page, amount=amount, offset=offset)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s does not exist on the server." % cls.__name__
            )

        map_list = []
        for i in range(response['count']):
            result = response['results'][i]
            if result.get('id'):
                try:
                    image_url = cls._get_image_url_from_id(result['id'])
                    image_data = cls.load_url_content(image_url, client=client)
                    result['image'] = image_data
                except exceptions.DoesNotExist:
                    pass
            map_object = cls.set_response(result)
            map_list.append(map_object)

        return map_list

    @property
    def areas(self):
        """Return a list of cached Area resources this Map contains.

        :return: A list of Area resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._areas is not None:
            return self._areas
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def docks(self):
        """Return a list of cached Dock resources this Map contains.

        :return: A list of Dock resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._docks is not None:
            return self._docks
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def dock_groups(self):
        """Return a list of cached DockGroup resources this Map contains.

        :return: A list of DockGroup resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._dock_groups is not None:
            return self._dock_groups
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def edges(self):
        """Return a list of cached Edge resources this Map contains.

        :return: A list of Edge resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._edges is not None:
            return self._edges
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def poses(self):
        """Return a list of cached Pose resources this Map contains.

        :return: A list of Pose resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._poses is not None:
            return self._poses
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def pose_groups(self):
        """Return a list of cached PoseGroup resources this Map contains.

        :return: A list of PoseGroup resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._pose_groups is not None:
            return self._pose_groups
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def queues(self):
        """Return a list of cached Queue resources this Map contains.

        :return: A list of Queue resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._queues is not None:
            return self._queues
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def survey_paths(self):
        """Return a list of cached SurveyPath resources this Map contains.

        :return: A list of SurveyPath resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._survey_paths is not None:
            return self._survey_paths
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def survey_nodes(self):
        """Return a list of cached SurveyNode resources this Map contains.

        :return: A list of SurveyNode resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._survey_nodes is not None:
            return self._survey_nodes
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def survey_poses(self):
        """Return a list of cached SurveyPose resources this Map contains.

        :return: A list of SurveyPose resources.
        :rtype: :class:`~__builtin__.list`

        :raise UndefinedFieldError: if this resource's internal cache has not been initialized.
        """
        if self._survey_poses is not None:
            return self._survey_poses
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")

    @property
    def nodes(self):
        """
        Return a list of cached Node resources this Map contains.
        :return: A list of Node resources.
        :rtype: list

        :raise: UndefinedFieldError if this resource's internal cache has not been initialized.
        """
        if self._edges is not None:
            return self._nodes
        else:
            raise exceptions.UndefinedFieldError("You must call refresh() before this can be updated.")
