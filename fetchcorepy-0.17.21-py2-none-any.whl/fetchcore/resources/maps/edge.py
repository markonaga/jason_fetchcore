# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Future
from __future__ import unicode_literals

# Standard Library
import collections
from copy import deepcopy

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.resources.maps import Node, NodeDraft
from fetchcore.resources.robots import CartFootprint, RobotFootprint
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class EdgeDraft(TimestampedResource):
    """
    Class for Fetchcore map edges.
    """

    # The endpoint in fetchcore for edges
    endpoint = 'maps/annotations/draft/edges'

    def __init__(self, id=None, start=None, end=None, modifiers=None, edge=None, robot_footprint_blacklist=None,
                 cart_footprint_blacklist=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the edge.
        :param start: (integer|Node) The location of the start of the edge.
        :param end: (integer|Node) The location of the end of the edge.
        :param modifiers: The users who have modified this annotation.
        :param edge: The edge that is associated with this edge draft.
        :param created: (string|datetime.datetime) The date and time of this edge's creation.
        :param modified: (string|datetime.datetime) The date and time this edge was last modified.
        """
        super(EdgeDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.start = start
        self.end = end
        self.modifiers = modifiers
        if edge:
            self.edge_id = edge
        if robot_footprint_blacklist:
            self.robot_footprint_blacklist = robot_footprint_blacklist
        if cart_footprint_blacklist:
            self.cart_footprint_blacklist = cart_footprint_blacklist

    @property
    def start_id(self):
        """Get the associated start ID for this edge.

        :return: The start ID.
        """
        return self._get('start')

    @start_id.setter
    def start_id(self, start_id):
        """Set the associated start ID for this edge.

        :param integer start_id: The start ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start_id is not a finite positive integer.
        """
        if Number.is_integer(start_id):
            if not Number.is_finite_positive(start_id):
                raise ValidationError("Start ID must be finite positive (item is %s)." % start_id)
            self._set('start', start_id)
        else:
            raise ValidationError("Start ID must be an integer (%s is %s)." % (start_id, type(start_id).__name__))

    @property
    def start(self):
        """Get the associated start Node for this edge.

        :return: The Node object.
        """
        return NodeDraft.load(self.start_id)

    @start.setter
    def start(self, start):
        """Set the associated start NodeDraft for this edge.

        :param start: (integer|NodeDraft) A start node or start ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start is not a NodeDraft object or an integer.
        """
        if isinstance(start, NodeDraft):
            if not start.is_set("id"):
                start.save()
            self.start_id = start.id
        elif isinstance(start, int):
            self.start_id = start
        else:
            raise ValidationError(
                'Start can only be an integer or a NodeDraft(%s is %s).' % (start, type(start).__name__))

    @property
    def end_id(self):
        """Get the associated end ID for this edge.

        :return: The end ID.
        """
        return self._get('end')

    @end_id.setter
    def end_id(self, end_id):
        """Set the associated end ID for this edge.

        :param integer end_id: The end ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if end_id is not a finite positive integer.
        """
        if Number.is_integer(end_id):
            if not Number.is_finite_positive(end_id):
                raise ValidationError("End ID must be finite positive (item is %s)." % end_id)
            self._set('end', end_id)
        else:
            raise ValidationError("End ID must be an integer (%s is %s)." % (end_id, type(end_id).__name__))

    @property
    def end(self):
        """Get the associated end NodeDraft for this edge.

        :return: The NodeDraft object.
        """
        return NodeDraft.load(self.end_id)

    @end.setter
    def end(self, end):
        """Set the associated end NodeDraft for this edge.

        :param end: (integer|NodeDraft) An end node or end ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if end is not a NodeDraft object or an integer.
        """
        if isinstance(end, NodeDraft):
            if not end.is_set("id"):
                end.save()
            self.end_id = end.id
        elif isinstance(end, int):
            self.end_id = end
        else:
            raise ValidationError('End can only be an integer or a NodeDraft(%s is %s).' % (end, type(end).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def edge_id(self):
        """Get the associated edge ID for this edge draft.

        :return: The edge ID.
        """
        return self._get('edge')

    @edge_id.setter
    def edge_id(self, edge_id):
        """Set the associated edge ID for this edge draft.

        :param integer edge_id: The edge ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if edge_id not a finite positive integer.
        """
        if edge_id is None:
            self._set('edge', edge_id)
        elif Number.is_integer(edge_id):
            if not Number.is_finite_positive(edge_id):
                raise ValidationError("Edge ID must be finite positive (item is %s)." % edge_id)
            self._set('edge', edge_id)
        else:
            raise ValidationError("Edge ID must be an integer (%s is %s)."
                                  % (edge_id, type(edge_id).__name__))

    def __set_footprint_blacklist(self, new_blacklist, blacklist_type, footprint_class):
        """Set the value of robot/cart footprint blacklist.

        :param new_blacklist: (iterable) New value to set to the blacklist.
        :param blacklist_type: (string) Type of the blacklist as a string. Should be either robot_footprint or
            cart_footprint.
        :param footprint_class: Resource class of this blacklist type.
        """
        if blacklist_type not in ('robot_footprint', 'cart_footprint'):
            raise ValidationError('EdgeDraft.__set_footprint_blacklist received an unrecognized blacklist type.')
        json_field = blacklist_type + '_blacklist'
        readable_blacklist_type = ' '.join(blacklist_type.split('_')).title()
        if new_blacklist is None:
            self._set(json_field, [])
        elif isinstance(new_blacklist, collections.Iterable) and not isinstance(new_blacklist, basestring):
            old_blacklist = deepcopy(self._get(json_field)) if self.is_set(json_field) else []
            self._set(json_field, [])
            for footprint in new_blacklist:
                try:
                    self.__add_footprint_to_blacklist(footprint, blacklist_type, footprint_class)
                except ValidationError as e:
                    self._set(json_field, old_blacklist)
                    raise e
        else:
            raise ValidationError('%s blacklist must be an iterable or None, not a %s.'
                                  % (readable_blacklist_type, type(new_blacklist).__name__))

    def __add_footprint_to_blacklist(self, footprint, blacklist_type, footprint_class):
        """Add a footprint to a blacklist.

        :param footprint: New footprint to add to a blacklist.
        :param blacklist_type: (string) Type of the blacklist as a string. Should be either robot_footprint or
            cart_footprint.
        :param footprint_class: Resource class of this blacklist type.
        """
        if blacklist_type not in ('robot_footprint', 'cart_footprint'):
            raise ValidationError('EdgeDraft.__add_footprint_to_blacklist received an unrecognized blacklist type.')
        if type(footprint) != footprint_class and not isinstance(footprint, basestring):
            readable_blacklist_type = ' '.join(blacklist_type.split('_')).title()
            raise ValidationError('%s must be a string or a %s object (%s is a %s).'
                                  % (readable_blacklist_type, footprint_class.__name__,
                                     str(footprint), type(footprint).__name__))
        json_field = blacklist_type + '_blacklist'
        if not self.is_set(json_field):
            self._set(json_field, [])
        blacklist = self._get(json_field)
        new_footprint = footprint if isinstance(footprint, basestring) else footprint.name
        if new_footprint not in blacklist:
            blacklist.append(new_footprint)
        self._set(json_field, blacklist)

    def __remove_footprint_from_blacklist(self, footprint, blacklist_type, footprint_class):
        """Remove a footprint from a blacklist.

        :param footprint: Footprint to remove from a blacklist.
        :param blacklist_type: (string) Type of the blacklist as a string. Should be either robot_footprint or
            cart_footprint.
        :param footprint_class: Resource class of this blacklist type.
        """
        if blacklist_type not in ('robot_footprint', 'cart_footprint'):
            raise ValidationError(
                'EdgeDraft.__remove_footprint_from_blacklist received an unrecognized blacklist type.')
        if type(footprint) != footprint_class and not isinstance(footprint, basestring):
            readable_blacklist_type = ' '.join(blacklist_type.split('_')).title()
            raise ValidationError('%s must be a string or a %s object (%s is a %s).'
                                  % (readable_blacklist_type, footprint_class.__name__,
                                     str(footprint), type(footprint).__name__))
        json_field = blacklist_type + '_blacklist'
        if self.is_set(json_field):
            try:
                self._get(json_field).remove(footprint if isinstance(footprint, basestring) else footprint.name)
            except ValueError:
                # Footprint is not in list
                pass

    @property
    def robot_footprint_blacklist_names(self):
        """

        :return: The list of robot footprint names blacklisted on this edge.
        """
        return tuple(self._get('robot_footprint_blacklist'))

    @property
    def robot_footprint_blacklist(self):
        """

        :return: The list of robot footprints blacklisted on this edge.
        """
        return [RobotFootprint.load(robot_footprint) for robot_footprint in self.robot_footprint_blacklist_names]

    @robot_footprint_blacklist.setter
    def robot_footprint_blacklist(self, robot_footprint_blacklist):
        """

        :param robot_footprint_blacklist: An iterable of robot footprints blacklisted on this edge, or None.
        :raise fetchcore.exception.ValidationError: if robot_footprint_blacklist is not an iterable or None, or if
            any item robot_footprint_blacklist is not a basestring or RobotFootprint.
        """
        self.__set_footprint_blacklist(robot_footprint_blacklist, 'robot_footprint', RobotFootprint)

    def add_robot_footprint_to_blacklist(self, robot_footprint):
        """Add a robot footprint to blacklist.

        :param robot_footprint: (string|RobotFootprint) New robot footprint to blacklist on this edge.
        """
        self.__add_footprint_to_blacklist(robot_footprint, 'robot_footprint', RobotFootprint)

    def remove_robot_footprint_to_blacklist(self, robot_footprint):
        """Add a robot footprint to blacklist.

        :param robot_footprint: (string|RobotFootprint) New robot footprint to blacklist on this edge.
        """
        self.__remove_footprint_from_blacklist(robot_footprint, 'robot_footprint', RobotFootprint)

    @property
    def cart_footprint_blacklist_names(self):
        """

        :return: The list of cart footprint names blacklisted on this edge.
        """
        return tuple(self._get('cart_footprint_blacklist'))

    @property
    def cart_footprint_blacklist(self):
        """

        :return: The list of cart footprints blacklisted on this edge.
        """
        return [CartFootprint.load(cart_footprint) for cart_footprint in self.cart_footprint_blacklist_names]

    @cart_footprint_blacklist.setter
    def cart_footprint_blacklist(self, cart_footprint_blacklist):
        """

        :param cart_footprint_blacklist: An iterable of cart footprints blacklisted on this edge, or None.
        :raise fetchcore.exception.ValidationError: if cart_footprint_blacklist is not an iterable or None, or if
            any item cart_footprint_blacklist is not a basestring or CartFootprint.
        """
        self.__set_footprint_blacklist(cart_footprint_blacklist, 'cart_footprint', CartFootprint)

    def add_cart_footprint_to_blacklist(self, cart_footprint):
        """Add a cart footprint to blacklist.

        :param cart_footprint: (string|CartFootprint) New cart footprint to blacklist on this edge.
        """
        self.__add_footprint_to_blacklist(cart_footprint, 'cart_footprint', CartFootprint)

    def remove_cart_footprint_to_blacklist(self, cart_footprint):
        """Add a cart footprint to blacklist.

        :param cart_footprint: (string|CartFootprint) New cart footprint to blacklist on this edge.
        """
        self.__remove_footprint_from_blacklist(cart_footprint, 'cart_footprint', CartFootprint)


class Edge(EdgeDraft):
    """Class for Fetchcore map edges."""

    # The endpoint in fetchcore for edges
    endpoint = 'maps/annotations/edges'

    def __init__(self, id=None, start=None, end=None, modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the edge
        :param start: (integer|Node) The location of the start of the edge
        :param end: (integer|Node) The location of the end of the edge
        :param created: (string|datetime.datetime) The date and time of this edge's creation.
        :param modified: (string|datetime.datetime) The date and time this edge was last modified.
        """
        super(Edge, self).__init__(id=id, start=start, end=end, modifiers=modifiers, created=created, modified=modified,
                                   **kwargs)

    def save(self, _=None):
        """Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def start(self):
        """Get the associated start Node for this edge.

        :return: The Node object.
        """
        return Node.load(self.start_id)

    @start.setter
    def start(self, start):
        """Set the associated start Node for this edge.

        :param start: (integer|Node) A start node or start ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start is not a Node object or an integer.
        """
        if isinstance(start, Node):
            if not start.is_set("id"):
                raise ValidationError(
                    'This node does not have an ID and, as a result, cannot be used for the start of this edge.')
            self.start_id = start.id
        elif isinstance(start, int):
            self.start_id = start
        else:
            raise ValidationError('Start can only be an integer or a Node(%s is %s).' % (start, type(start).__name__))

    @property
    def end(self):
        """Get the associated end Node for this edge.

        :return: The Node object.
        """
        return Node.load(self.end_id)

    @end.setter
    def end(self, end):
        """Set the associated end Node for this edge.

        :param end: (integer|Node) An end node or end ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if end is not a Node object or an integer.
        """
        if isinstance(end, Node):
            if not end.is_set("id"):
                raise ValidationError(
                    'This node does not have an ID and, as a result, cannot be used for the end of this edge.')
            self.end_id = end.id
        elif isinstance(end, int):
            self.end_id = end
        else:
            raise ValidationError('End can only be an integer or a Node(%s is %s).' % (end, type(end).__name__))
