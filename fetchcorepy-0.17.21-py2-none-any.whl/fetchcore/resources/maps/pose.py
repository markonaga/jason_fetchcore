# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation, UndefinedFieldError


class PoseDraft(TimestampedResource):
    """
    Class for fetchcore map pose drafts.
    """

    # The endpoint in fetchcore for pose
    endpoint = 'maps/annotations/draft/poses'

    def __init__(self, id=None, name=None, x=None, y=None, theta=None, map=None, group=None, queue=None,
                 modifiers=None, pose=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose.
        :param string name: The human-readable name of the pose.
        :param float x: The X position of the pose (in meters) within the associated map.
        :param float y: The Y position of the pose (in meters) within the associated map.
        :param float theta: The angle of the pose (in radians) within the associated map.
        :param map: (integer|Map) The map or map ID this pose belongs to.
        :param group: (integer|PoseGroup) The pose group associated with this pose.
        :param queue: (integer|Queue) The queue associated with this pose.
        :param modifiers: The users who modified this annotation.
        :param pose: The pose that is associated with this pose draft.
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(PoseDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        if name:
            self.name = name
        if queue:
            self.queue = queue
        self.modifiers = modifiers
        self.x = x
        self.y = y
        self.theta = theta
        self.map = map
        self.group = group
        if pose:
            self.pose_id = pose

    @property
    def name(self):
        """Gets the human-readable name of the pose

        :return: the pose name
        """
        return self._get("name")

    @name.setter
    def name(self, value):
        """A human-readable name of the pose

        :param value: The pose name
        :raises ValidationError if value is not a string
        :raises ValidationError if value is an empty string
        """
        if value is None:
            self._set("name", value)
        elif isinstance(value, basestring):
            if not value:
                raise ValidationError("Name cannot be an empty string")
            self._set("name", value)
        else:
            raise ValidationError("Name must be a string, not a %s"
                                  % type(value).__name__)

    @property
    def x(self):
        """Gets the X position of the pose within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the pose within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the pose within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the pose within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def theta(self):
        """Gets the angle of the pose (in radians) within the associated map

        :return: The angle
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Set the angle of the pose (in radians) within the associated map.

        :param float theta: The pose angle.
        :raise fetchcore.eyceptions.ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))

    @property
    def map_id(self):
        """Get the associated pose map ID for this pose.

        :return: The pose map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated pose map ID for this pose.

        :param integer map_id: The pose map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Area map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Area map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated pose map for this pose.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated pose map for this pose.

        :param map: (integer|Map) An pose map or pose map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not an pose map object or an integer or None.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map (%s is %s).' % (map, type(map).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def group_id(self):
        """Get the associated pose group ID for this pose.

        :return: The pose group ID.
        """
        return self._get('group')

    @group_id.setter
    def group_id(self, group_id):
        """Set the associated pose group ID for this pose.

        :param integer group_id: The pose group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group_id is not a finite positive integer.
        """
        if group_id is None:
            self._set('group', group_id)
        elif Number.is_integer(group_id):
            if not Number.is_finite_positive(group_id):
                raise ValidationError("Pose group ID must be finite positive (item is %s)." % group_id)
            self._set('group', group_id)
        else:
            raise ValidationError("Pose group ID must be an integer (%s is %s)."
                                  % (group_id, type(group_id).__name__))

    @property
    def group(self):
        """Get the associated pose group for this pose.

        :return: The PoseGroup object.
        """
        from fetchcore.resources.maps import PoseGroupDraft
        return None if self.group_id is None else PoseGroupDraft.load(self.group_id)

    @group.setter
    def group(self, group):
        """Set the associated pose group for this pose.

        :param group: (integer|PoseGroup) An pose group or pose group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group is not an pose group object or an
        integer or None.
        """
        from fetchcore.resources.maps import PoseGroupDraft
        if isinstance(group, PoseGroupDraft):
            if not group.is_set("id"):
                group.save()
            self.group_id = group.id
        elif group is None or isinstance(group, int):
            self.group_id = group
        else:
            raise ValidationError('Pose group can only be an integer, PoseGroup or None (%s is %s).'
                                  % (group, type(group).__name__))

    def has_queue(self):
        """
        :returns: True if this pose has a queue associated with it
        :returns: False otherwise
        """
        try:
            queue_id = self.queue_id
            return queue_id is not None
        except UndefinedFieldError:
            return False

    @property
    def queue_id(self):
        """
        :returns: The ID of the associated queue
        """
        return self._get('queue')

    @queue_id.setter
    def queue_id(self, queue_id):
        """Set the associated queue ID for this pose.

        :param integer queue_id: The queue ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if queue_id is not a finite positive integer.
        """
        if queue_id is None:
            self._set('queue', queue_id)
        elif Number.is_integer(queue_id):
            if not Number.is_finite_positive(queue_id):
                raise ValidationError("Queue ID must be finite positive (item is %s)." % queue_id)
            self._set('queue', queue_id)
        else:
            raise ValidationError("Queue ID must be an integer (%s is %s)."
                                  % (queue_id, type(queue_id).__name__))

    @property
    def queue(self):
        """Get the associated queue for this pose.

        :return: The QueueDraft object.
        """
        from fetchcore.resources.maps import QueueDraft
        return None if self.queue_id is None else QueueDraft.load(self.queue_id)

    @queue.setter
    def queue(self, queue):
        """Set the associated queue for this pose.

        :param queue: (integer|QueueDraft) A queue or queue ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if queue is not an QueueDraft object or an
        integer or None.
        """
        from fetchcore.resources.maps import QueueDraft
        if isinstance(queue, QueueDraft):
            if not queue.is_set("id"):
                queue.save()
            self.queue_id = queue.id
        elif queue is None or isinstance(queue, int):
            self.queue_id = queue
        else:
            raise ValidationError('Queue can only be an integer, QueueDraft object, or None (%s is %s).'
                                  % (queue, type(queue).__name__))

    @property
    def pose_id(self):
        """Get the associated pose ID for this pose draft.

        :return: The pose ID.
        """
        return self._get('pose')

    @pose_id.setter
    def pose_id(self, pose_id):
        """Set the associated pose ID for this pose draft.

        :param integer pose_id: The pose ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose_id not a finite positive integer.
        """
        if pose_id is None:
            self._set('pose', pose_id)
        elif Number.is_integer(pose_id):
            if not Number.is_finite_positive(pose_id):
                raise ValidationError("Pose ID must be finite positive (item is %s)." % pose_id)
            self._set('pose', pose_id)
        else:
            raise ValidationError("Pose ID must be an integer (%s is %s)."
                                  % (pose_id, type(pose_id).__name__))


class Pose(PoseDraft):
    """
    Class for Fetchcore map poses.
    """

    # The endpoint in fetchcore for pose
    endpoint = 'maps/annotations/poses'

    def __init__(self, id=None, name=None, x=None, y=None, theta=None, group=None, map=None, modifiers=None, queue=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose
        :param string name: The human-readable name of the pose
        :param float x: The X position of the pose (in meters) within the associated map
        :param float y: The Y position of the pose (in meters) within the associated map
        :param float theta: The angle of the pose (in radians) within the associated map
        :param group: (integer|PoseGroup) The pose group associated with this pose.
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(Pose, self).__init__(id=id, name=name, map=map, modifiers=modifiers, group=group, queue=queue,
                                   x=x, y=y, theta=theta, created=created, modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def group(self):
        """Get the associated pose group for this pose.

        :return: The PoseGroup object.
        """
        from fetchcore.resources.maps import PoseGroup
        return None if self.group_id is None else PoseGroup.load(self.group_id)

    @group.setter
    def group(self, group):
        """Set the associated pose group for this pose.

        :param group: (integer|PoseGroup) An pose group or pose group ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if group is not an pose group object or an
        integer or None.
        """
        from fetchcore.resources.maps import PoseGroup
        if isinstance(group, PoseGroup):
            if not group.is_set("id"):
                raise ValidationError('Pose group must already have an ID.')
            self.group_id = group.id
        elif group is None or isinstance(group, int):
            self.group_id = group
        else:
            raise ValidationError('Pose group can only be an integer, PoseGroup or None (%s is %s).'
                                  % (group, type(group).__name__))

    @property
    def queue(self):
        """Get the associated queue for this pose.

        :return: The Queue object.
        """
        from fetchcore.resources.maps import Queue
        return None if self.queue_id is None else Queue.load(self.queue_id)

    @queue.setter
    def queue(self, queue):
        """Set the associated queue for this pose.

        :param queue: (integer|Queue) A queue or queue ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if queue is not an Queue object or an
        integer or None.
        """
        from fetchcore.resources.maps import Queue
        if isinstance(queue, Queue):
            if not queue.is_set("id"):
                raise ValidationError('Queue must already have an ID.')
            self.queue_id = queue.id
        elif queue is None or isinstance(queue, int):
            self.queue_id = queue
        else:
            raise ValidationError('Queue can only be an integer, Queue object, or None (%s is %s).'
                                  % (queue, type(queue).__name__))
