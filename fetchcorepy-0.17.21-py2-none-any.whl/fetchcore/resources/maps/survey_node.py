# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class SurveyNodeDraft(TimestampedResource):
    """
    Class for Fetchcore map survey node drafts.
    """

    # The endpoint in fetchcore for survey node drafts
    endpoint = 'maps/annotations/draft/survey/nodes'

    def __init__(self, id=None, x=None, y=None, theta=None, prev_node=None, next_node=None, survey_path=None,
                 modifiers=None, survey_node=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the survey node.
        :param float x: The X position of the survey node (in meters) within the associated map.
        :param float y: The Y position of the survey node (in meters) within the associated map.
        :param float theta: The angle of the survey node (in radians) within the associated map.
        :param SurveyNode prev_node: The previous node in the sequence
        :param SurveyNode next_node: The next node in the sequence
        :param survey_path: The survey path that created this survey node.
        :param modifiers: The users who have modified this annotation.
        :param survey_node: The survey node that is associated with this survey node draft.
        :param created: (string|datetime.datetime) The date and time of this survey node's creation.
        :param modified: (string|datetime.datetime) The date and time this survey node was last modified.
        """
        super(SurveyNodeDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.x = x
        self.y = y
        self.theta = theta
        self.prev_node = prev_node
        self.next_node = next_node
        self.modifiers = modifiers
        if survey_node:
            self.survey_node_id = survey_node
        self.survey_path = survey_path

    @property
    def survey_path_id(self):
        """Get the ID of the survey path.

        :return: The start ID.
        """
        return self._get('survey_path')

    @survey_path_id.setter
    def survey_path_id(self, survey_path_id):
        """Set the ID for this survey path.

        :param integer survey_path: The survey path ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_path_id is not a finite positive integer.
        """
        if Number.is_integer(survey_path_id):
            if not Number.is_finite_positive(survey_path_id):
                raise ValidationError("Survey Path ID must be finite positive (item is %s)." % survey_path_id)
            self._set('survey_path', survey_path_id)
        else:
            raise ValidationError("Survey Path ID must be an integer (%s is %s)."
                                  % (survey_path_id, type(survey_path_id).__name__))

    @property
    def survey_path(self):
        """Get the survey path that this survey node belongs to.

        :return: The survey node's survey path.
        """
        from fetchcore.resources.maps import SurveyPathDraft
        return SurveyPathDraft.load(self.survey_path_id)

    @survey_path.setter
    def survey_path(self, survey_path):
        """Get the survey path that this survey node belongs to.

        :return: The survey node's survey path.
        """
        from fetchcore.resources.maps import SurveyPathDraft
        if isinstance(survey_path, SurveyPathDraft):
            if not survey_path.is_set("id"):
                survey_path.save()
            self._set('survey_path', survey_path.id)
        elif survey_path is None or isinstance(survey_path, int):
            self._set('survey_path', survey_path)
        else:
            raise ValidationError('Survey Path must be an integer or SurveyPathDraft (%s is %s).'
                                  % (survey_path, type(survey_path).__name__))

    @property
    def next_node_id(self):
        """Gets the next node in the path

        :return: SurveyNode ID corresponding to next node
        """
        return self._get("next_node")

    @next_node_id.setter
    def next_node_id(self, next_node_id):
        """Sets the next node in the path

        :param next_node_id: An ID to the next survey node.
        :type next_node_id: int
        :raises fetchcore.exceptions.ValidationError: Thrown if next_node_id not a finite positive integer.
        """
        if next_node_id is None:
            self._set('next_node', next_node_id)
        elif Number.is_integer(next_node_id):
            if not Number.is_finite_positive(next_node_id):
                raise ValidationError("Next node ID must be finite positive (item is %s)." % next_node_id)
            self._set('next_node', next_node_id)
        else:
            raise ValidationError("Next node ID must be an integer (%s is %s)."
                                  % (next_node_id, type(next_node_id).__name__))

    @property
    def next_node(self):
        """Get the associated next node for this node,.

        :return: The Next Node SurveyNode object.
        """
        return SurveyNodeDraft.load(self.next_node_id) if self.next_node_id is not None else None

    @next_node.setter
    def next_node(self, next_node):
        """Set the associated next node for this node.

        :param next_node: (integer|SurveyNodeDraft) An survey node for this node
        :type next_node: int, SurveyNodeDraft
        :raise fetchcore.exceptions.ValidationError: Thrown if next node is not an survey node object or an integer or
            None.
        """
        if isinstance(next_node, SurveyNodeDraft):
            if not next_node.is_set("id"):
                next_node.save()
            self.next_node_id = next_node.id
        elif next_node is None or isinstance(next_node, int):
            self.next_node_id = next_node
        else:
            raise ValidationError('Next can only be an integer or SurveyNodeDraft (%s is %s).'
                                  % (next_node, type(next_node).__name__))

    @property
    def prev_node_id(self):
        """Gets the previous node in the path.

        :return: SurveyNode ID corresponding to previous node
        """
        return self._get("prev_node")

    @prev_node_id.setter
    def prev_node_id(self, prev_node_id):
        """Sets the previous node in the path.

        :param prev_node_id: An ID to the previous survey node.
        :type prev_node_id: int
        :raises fetchcore.exceptions.ValidationError: Thrown if prev_node_id not a finite positive integer.
        """
        if prev_node_id is None:
            self._set('prev_node', prev_node_id)
        elif Number.is_integer(prev_node_id):
            if not Number.is_finite_positive(prev_node_id):
                raise ValidationError("Previous node ID must be finite positive (item is %s)." % prev_node_id)
            self._set('prev_node', prev_node_id)
        else:
            raise ValidationError("Previous node ID must be an integer (%s is %s)."
                                  % (prev_node_id, type(prev_node_id).__name__))

    @property
    def prev_node(self):
        """Get the associated previous node for this node.

        :return: The Previous Node SurveyNode object.
        """
        return SurveyNodeDraft.load(self.prev_node_id) if self.prev_node_id is not None else None

    @prev_node.setter
    def prev_node(self, prev_node):
        """Set the associated previous node for this node.

        :param prev_node: (integer|SurveyNodeDraft) An survey node for this node
        :type prev_node: int, SurveyNodeDraft
        :raise fetchcore.exceptions.ValidationError: Thrown if next node is not an survey node object or an integer or
            None.
        """
        if isinstance(prev_node, SurveyNodeDraft):
            if not prev_node.is_set("id"):
                prev_node.save()
            self.prev_node_id = prev_node.id
        elif prev_node is None or isinstance(prev_node, int):
            self.prev_node_id = prev_node
        else:
            raise ValidationError('Previous can only be an integer or SurveyNodeDraft (%s is %s).'
                                  % (prev_node, type(prev_node).__name__))

    @property
    def x(self):
        """Gets the X position of the survey node within the associated map.

        :return: The X position.
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the survey node within the associated map.

        :param value: A float.
        :raises ValidationError if value is not a number.
        :raises ValidationError if value is not a finite number.
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the survey node within the associated map.

        :return: The Y position.
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the survey node within the associated map.

        :param value: A float.
        :raises ValidationError if value is not a number.
        :raises ValidationError if value is not a finite number.
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def theta(self):
        """Gets the angle of the survey node (in radians) within the associated map.

        :return: The angle.
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Set the angle of the survey node (in radians) within the associated map.

        :param float theta: The survey node angle.
        :raise fetchcore.exceptions.ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int.
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def survey_node_id(self):
        """Get the associated survey node ID for this survey node draft.

        :return: The survey node ID.
        """
        return self._get('survey_node')

    @survey_node_id.setter
    def survey_node_id(self, survey_node_id):
        """Set the associated survey node ID for this survey node draft.

        :param integer survey_node_id: The survey node ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_node_id not a finite positive integer.
        """
        if survey_node_id is None:
            self._set('survey_node', survey_node_id)
        elif Number.is_integer(survey_node_id):
            if not Number.is_finite_positive(survey_node_id):
                raise ValidationError("Survey node ID must be finite positive (item is %s)." % survey_node_id)
            self._set('survey_node', survey_node_id)
        else:
            raise ValidationError("Survey node ID must be an integer (%s is %s)."
                                  % (survey_node_id, type(survey_node_id).__name__))


class SurveyNode(SurveyNodeDraft):
    """
    Class for Fetchcore map survey nodes.
    """

    # The endpoint in fetchcore for survey nodes
    endpoint = 'maps/annotations/survey/nodes'

    def __init__(self, id=None, x=None, y=None, theta=None, prev_node=None, next_node=None, survey_path=None,
                 modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the survey node.
        :param float x: The X position of the survey node (in meters) within the associated map.
        :param float y: The Y position of the survey node (in meters) within the associated map.
        :param float theta: The angle of the survey node (in radians) within the associated map.
        :param SurveyNode prev_node: The previous node in the sequence
        :param SurveyNode next_node: The next node in the sequence
        :param survey_path: The survey path that created this survey node.
        :param created: (string|datetime.datetime) The date and time of this survey node's creation.
        :param modified: (string|datetime.datetime) The date and time this survey node was last modified.
        """
        super(SurveyNode, self).__init__(id=id, x=x, y=y, theta=theta, prev_node=prev_node, next_node=next_node,
                                         survey_path=survey_path, modifiers=modifiers, created=created,
                                         modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class save. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def next_node(self):
        """Get the associated next node for this node,.

        :return: The Next Node SurveyNode object.
        """
        return SurveyNode.load(self.next_node_id) if self.next_node_id is not None else None

    @next_node.setter
    def next_node(self, next_node):
        """Set the associated next node for this node.

        :param next_node: (integer|SurveyNode) An survey node for this node
        :type next_node: int, SurveyNode
        :raise fetchcore.exceptions.ValidationError: Thrown if next node is not an survey node object or an integer or
            None.
        """
        if isinstance(next_node, SurveyNode):
            if not next_node.is_set("id"):
                raise ValidationError('Next Node must already have an ID.')
            self.next_node_id = next_node.id
        elif next_node is None:
            self.next_node_id = None
        elif isinstance(next_node, int):
            self.next_node_id = next_node
        else:
            raise ValidationError('Next can only be an integer or SurveyNode (%s is %s).'
                                  % (next_node, type(next_node).__name__))

    @property
    def prev_node(self):
        """Get the associated previous node for this node.

        :return: The previous Node SurveyNode object.
        """
        return SurveyNode.load(self.prev_node_id) if self.prev_node_id is not None else None

    @prev_node.setter
    def prev_node(self, prev_node):
        """Set the associated previous node for this node.

        :param prev_node: (integer|SurveyNode) An survey node for this node
        :type prev_node: int, SurveyNode
        :raise fetchcore.exceptions.ValidationError: Thrown if Previous node is not an survey node object or an integer
                                                    or None.
        """
        if isinstance(prev_node, SurveyNode):
            if not prev_node.is_set("id"):
                raise ValidationError('Previous Node must already have an ID.')
            self.prev_node_id = prev_node.id
        elif prev_node is None or isinstance(prev_node, int):
            self.prev_node_id = prev_node
        else:
            raise ValidationError('Previous can only be an integer or SurveyNode (%s is %s).'
                                  % (prev_node, type(prev_node).__name__))

    @property
    def survey_path(self):
        """Get the survey path that this survey node belongs to.

        :return: The survey node's survey path.
        """
        from fetchcore.resources.maps import SurveyPath
        return SurveyPath.load(self.survey_path_id)

    @survey_path.setter
    def survey_path(self, survey_path):
        """Get the survey path that this survey node belongs to.

        :return: The survey node's survey path.
        """
        from fetchcore.resources.maps import SurveyPath
        if isinstance(survey_path, SurveyPath):
            if not survey_path.is_set("id"):
                raise ValidationError('Survey Path must already have an ID.')
            self.survey_path_id = survey_path.id
        elif survey_path is None or isinstance(survey_path, int):
            self.survey_path_id = survey_path
        else:
            raise ValidationError('Survey Path can only be an integer or SurveyPath (%s is %s).'
                                  % (survey_path, type(survey_path).__name__))
