# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class NodeDraft(TimestampedResource):
    """
    Class for Fetchcore map nodes.
    """

    # The endpoint in fetchcore for nodes
    endpoint = 'maps/annotations/draft/nodes'

    def __init__(self, id=None, x=None, y=None, map=None, modifiers=None, node=None, created=None, modified=None,
                 **kwargs):
        """
        :param integer id: The ID of the node.
        :param float x: The X position of the node (in meters) within the associated map.
        :param float y: The Y position of the node (in meters) within the associated map.
        :param map: The map that is associated with this node.
        :param modifiers: The user who modified this annotation.
        :param node: The node that is associated with this node draft.
        :param created: (string|datetime.datetime) The date and time of this node's creation.
        :param modified: (string|datetime.datetime) The date and time this node was last modified.
        """
        super(NodeDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.x = x
        self.y = y
        self.map = map
        self.modifiers = modifiers
        if node:
            self.node_id = node

    @property
    def x(self):
        """Gets the X position of the node within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the node within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the node within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the node within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def map_id(self):
        """Get the associated node map ID for this node.

        :return: The node map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated node map ID for this node.

        :param integer map_id: The node map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Node map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Node map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated node map for this node.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated node map for this node.

        :param map: (integer|Map) An node map or node map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not an node map object or an integer or None.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map (%s is %s).' % (map, type(map).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def node_id(self):
        """Get the associated node ID for this node draft.

        :return: The node ID.
        """
        return self._get('node')

    @node_id.setter
    def node_id(self, node_id):
        """Set the associated node ID for this node draft.

        :param integer node_id: The node ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if node_id not a finite positive integer.
        """
        if node_id is None:
            self._set('node', node_id)
        elif Number.is_integer(node_id):
            if not Number.is_finite_positive(node_id):
                raise ValidationError("Node ID must be finite positive (item is %s)." % node_id)
            self._set('node', node_id)
        else:
            raise ValidationError("Node ID must be an integer (%s is %s)."
                                  % (node_id, type(node_id).__name__))


class Node(NodeDraft):
    """
    Class for Fetchcore map nodes.
    """

    # The endpoint in fetchcore for nodes
    endpoint = 'maps/annotations/nodes'

    def __init__(self, id=None, x=None, y=None, map=None, modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the node
        :param float x: The X position of the node (in meters) within the associated map
        :param float y: The Y position of the node (in meters) within the associated map
        :param created: (string|datetime.datetime) The date and time of this node's creation.
        :param modified: (string|datetime.datetime) The date and time this node was last modified.
        """
        super(Node, self).__init__(id=id, x=x, y=y, map=map, modifiers=modifiers, created=created, modified=modified,
                                   **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")
