# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class SurveyPoseDraft(TimestampedResource):
    """
    Class for Fetchcore map survey pose drafts.
    """

    # The endpoint in fetchcore for survey pose drafts
    endpoint = 'maps/annotations/draft/survey/poses'

    def __init__(self, id=None, theta=None, distance_ratio=None, start=None, modifiers=None, survey_pose=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the survey pose.
        :param float theta: The angle of the survey pose (in radians) within the associated map.
        :param float distance_ratio: The distance along the edge where this pose sits (bound between 0 and 1).
        :param start: The starting node for this pose.
        :param modifiers: The users who have modified this annotation.
        :param survey_pose: The survey pose that is associated with this survey pose draft.
        :param created: (string|datetime.datetime) The date and time of this survey pose's creation.
        :param modified: (string|datetime.datetime) The date and time this survey pose was last modified.
        """
        super(SurveyPoseDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.theta = theta
        self.distance_ratio = distance_ratio
        self.start = start
        self.modifiers = modifiers
        if survey_pose:
            self.survey_pose_id = survey_pose

    @property
    def theta(self):
        """Gets the angle of the survey pose (in radians) within the associated map.

        :return: The angle.
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Sets the angle of the survey pose (in radians) within the associated map.

        :param float theta: The survey pose angle.
        :raise fetchcore.exceptions.ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))

    @property
    def distance_ratio(self):
        """Gets the distance along the edge where this pose sits (bound between 0 and 1).

        :return: The distance ratio.
        """
        return self._get("distance_ratio")

    @distance_ratio.setter
    def distance_ratio(self, distance_ratio):
        """Sets the distance along the edge where this pose sits (bound between 0 and 1).

        :param float distance_ratio: The distance ratio.
        :raise fetchcore.exceptions.ValidationError: Thrown if distance_ratio is not a finite number in between 0 and 1.
        """
        if not Number.is_real_number(distance_ratio):
            raise ValidationError("Distance ratio must be a number (distance_ratio is %s)" % distance_ratio)
        elif distance_ratio < 0 or distance_ratio > 1:
            raise ValidationError("Distance ratio must be between 0 and 1 (distance_ratio is %s)" % distance_ratio)
        else:
            self._set("distance_ratio", distance_ratio)

    @property
    def start_id(self):
        """Get the starting node ID for this pose.

        :return: The start ID.
        """
        return self._get('start')

    @start_id.setter
    def start_id(self, start_id):
        """Set the starting node ID for this pose.

        :param integer start_id: The survey node ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start_id is not a finite positive integer.
        """
        if Number.is_integer(start_id):
            if not Number.is_finite_positive(start_id):
                raise ValidationError("Start ID must be finite positive (item is %s)." % start_id)
            self._set('start', start_id)
        else:
            raise ValidationError("Start ID must be an integer (%s is %s)."
                                  % (start_id, type(start_id).__name__))

    @property
    def start(self):
        """Get the starting node for this pose.

        :return: The SurveyNodeDraft object.
        """
        from fetchcore.resources.maps import SurveyNodeDraft
        return SurveyNodeDraft.load(self.start_id)

    @start.setter
    def start(self, start):
        """Set the starting node for this pose.

        :param start: (integer|SurveyNodeDraft) A survey node or survey node ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start is not a SurveyNodeDraft object or an integer.
        """
        from fetchcore.resources.maps import SurveyNodeDraft
        if isinstance(start, SurveyNodeDraft):
            if not start.is_set("id"):
                raise ValidationError('Start must already have an ID.')
            self.start_id = start.id
        elif isinstance(start, int):
            self.start_id = start
        else:
            raise ValidationError('Start can only be an integer or SurveyNodeDraft (%s is %s).'
                                  % (start, type(start).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int.
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def survey_pose_id(self):
        """Get the associated survey pose ID for this survey pose draft.

        :return: The survey pose ID.
        """
        return self._get('survey_pose')

    @survey_pose_id.setter
    def survey_pose_id(self, survey_pose_id):
        """Set the associated survey pose ID for this survey pose draft.

        :param integer survey_pose_id: The survey pose ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_pose_id not a finite positive integer.
        """
        if survey_pose_id is None:
            self._set('survey_pose', survey_pose_id)
        elif Number.is_integer(survey_pose_id):
            if not Number.is_finite_positive(survey_pose_id):
                raise ValidationError("Survey pose ID must be finite positive (item is %s)." % survey_pose_id)
            self._set('survey_pose', survey_pose_id)
        else:
            raise ValidationError("Survey pose ID must be an integer (%s is %s)."
                                  % (survey_pose_id, type(survey_pose_id).__name__))


class SurveyPose(SurveyPoseDraft):
    """
    Class for Fetchcore map survey poses.
    """

    # The endpoint in fetchcore for survey poses
    endpoint = 'maps/annotations/survey/poses'

    @staticmethod
    def endpoint_by_survey_path_id(id):
        return 'maps/annotations/survey/paths/%s/poses' % id

    def __init__(self, id=None, theta=None, distance_ratio=None, start=None, modifiers=None, created=None,
                 modified=None, **kwargs):
        """
        :param integer id: The ID of the survey pose.
        :param float theta: The angle of the survey pose (in radians) within the associated map.
        :param float distance_ratio: The distance along the edge where this pose sits (bound between 0 and 1).
        :param start: The starting node for this pose.
        :param created: (string|datetime.datetime) The date and time of this survey pose's creation.
        :param modified: (string|datetime.datetime) The date and time this survey pose was last modified.
        """
        super(SurveyPose, self).__init__(id=id, theta=theta, distance_ratio=distance_ratio, start=start,
                                         modifiers=modifiers, created=created, modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def start(self):
        """Get the starting node for this pose.

        :return: The SurveyNode object.
        """
        from fetchcore.resources.maps import SurveyNode
        return SurveyNode.load(self.start_id)

    @start.setter
    def start(self, start):
        """Set the starting node for this pose.

        :param start: (integer|SurveyNode) A survey node or survey node ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if start is not a SurveyNode object or an integer.
        """
        from fetchcore.resources.maps import SurveyNode
        if isinstance(start, SurveyNode):
            if not start.is_set("id"):
                raise ValidationError('Start must already have an ID.')
            self.start_id = start.id
        elif isinstance(start, int):
            self.start_id = start
        else:
            raise ValidationError('Start can only be an integer or SurveyNode (%s is %s).'
                                  % (start, type(start).__name__))
