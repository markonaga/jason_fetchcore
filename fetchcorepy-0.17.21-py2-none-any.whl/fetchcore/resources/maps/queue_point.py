# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard library

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation, UndefinedFieldError


class QueuePointDraft(TimestampedResource):
    """
    Class for fetchcore map pose drafts.
    """

    # The endpoint in fetchcore for queue point drafts
    endpoint = 'maps/annotations/draft/queue_points'

    def __init__(self, id=None, x=None, y=None, queue=None, modifiers=None, queue_point=None, created=None,
                 modified=None, **kwargs):
        """
        :param integer id: The ID of the point.
        :param float x: The X position of the point (in meters) within the associated map.
        :param float y: The Y position of the point (in meters) within the associated map.
        :param integer queue: The ID name of the associated queue.
        :param modifiers: The users who have modified this annotation.
        :param queue_point: The queue point that is associated with this queue point draft.
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(QueuePointDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.x = x
        self.y = y
        self.modifiers = modifiers
        if queue:
            self.queue = queue
        if queue_point:
            self.queue_point_id = queue_point

    @property
    def queue(self):
        """Get the queue for this queue as a Queue object.

        :return: A Queue object.
        """
        from .queue import QueueDraft
        return QueueDraft.load(self.queue_id)

    @queue.setter
    def queue(self, value):
        """Sets the queue that this queue point is associated with

        :param value: The associated queue
        """
        from .queue import Queue, QueueDraft
        if isinstance(value, Queue):
            raise ValidationError("Queue must be a QueueDraft, not a Queue")
        elif isinstance(value, QueueDraft):
            try:
                self._set('queue', value.id)
            except UndefinedFieldError:
                raise ValidationError("QueueDraft must have an ID to be associated with this queue.")
        elif Number.is_integer(value) and Number.is_finite_positive(value):
            self._set('queue', value)
        else:
            raise ValidationError("Queue must be a QueueDraft with an assigned ID, or a positive integer")

    @property
    def queue_id(self):
        """
        :return: The ID of the associated queue
        """
        return self._get("queue")

    @property
    def x(self):
        """Gets the X position of the point within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the point within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the point within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the point within the associated map

        :param value: A float
        :raises ValidationError if value is not a number
        :raises ValidationError if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def queue_point_id(self):
        """Get the associated queue point ID for this queue point draft.

        :return: The queue point ID.
        """
        return self._get('queue_point')

    @queue_point_id.setter
    def queue_point_id(self, queue_point_id):
        """Set the associated queue point ID for this queue point draft.

        :param integer queue_point_id: The queue point ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if queue_point_id not a finite positive integer.
        """
        if queue_point_id is None:
            self._set('queue_point', queue_point_id)
        elif Number.is_integer(queue_point_id):
            if not Number.is_finite_positive(queue_point_id):
                raise ValidationError("Queue point ID must be finite positive (item is %s)." % queue_point_id)
            self._set('queue_point', queue_point_id)
        else:
            raise ValidationError("Queue point ID must be an integer (%s is %s)."
                                  % (queue_point_id, type(queue_point_id).__name__))


class QueuePoint(QueuePointDraft):
    """
    Class for Fetchcore map poses.
    """

    # The endpoint in fetchcore for queue points
    endpoint = 'maps/annotations/queue_points'

    def __init__(self, id=None, x=None, y=None, queue=None, modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose
        :param float x: The X position of the point (in meters) within the associated map
        :param float y: The Y position of the point (in meters) within the associated map
        :param integer queue: The ID name of the associated queue
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(QueuePoint, self).__init__(id=id, modifiers=modifiers, x=x, y=y, queue=queue, created=created,
                                         modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def queue(self):
        """Get the queue for this queue as a Queue object.

        :return: A Queue object.
        """
        from .queue import Queue
        return Queue.load(self.queue_id)

    @queue.setter
    def queue(self, value):
        """Sets the queue that this queue point is associated with

        :param value: The associated queue
        """
        from .queue import Queue, QueueDraft
        if isinstance(value, QueueDraft) and not isinstance(value, Queue):
            raise ValidationError("Queue must be a Queue, not a QueueDraft")
        elif isinstance(value, Queue):
            try:
                self._set('queue', value.id)
            except UndefinedFieldError:
                raise ValidationError("QueueDraft must have an ID to be associated with this queue.")
        elif Number.is_integer(value) and Number.is_finite_positive(value):
            self._set('queue', value)
        else:
            raise ValidationError("Queue must be a Queue with an assigned ID, or a positive integer")
