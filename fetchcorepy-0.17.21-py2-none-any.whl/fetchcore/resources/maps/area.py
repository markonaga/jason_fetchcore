# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Michael Hwang

# Standard library
from copy import deepcopy
import inspect

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.resources.maps.point import Point, PointDraft
from fetchcore.definitions import Shapes, AreaTypes
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, KeyWordArgumentError, UnsupportedOperation


class AreaDraft(TimestampedResource):
    """
    Class for Fetchcore map areas.
    """

    # The endpoint in fetchcore for areas
    endpoint = 'maps/annotations/draft/areas'

    def __init__(self, id=None, type=None, name=None, value=None, shape=None, points=None, map=None, modifiers=None,
                 area=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the area.
        :param AreaType type: The type of annotation area this is.
        :param string name: A human-readable name of the area.
        :param float value: A scaled value in the range [0, 1] associated with the area.
        :param Shape shape: The shape the annotation points are defined as.
        :param points: The list of points that are associated with this area.
        :param map: The map this area is associated with.
        :param modifiers: The users who have modified this annotation.
        :param area: The area that is associated with this area draft.
        :param created: The date and time of this area's creation.
        :param modified: The date and time this area was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        :type points: list of :class:`~fetchcore.resources.maps.point.Point` objects
        """
        super(AreaDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.type = type
        if name:
            self.name = name
        if value is not None:
            self.value = value
        self.shape = shape
        self.map = map
        self.modifiers = modifiers
        self._points = []
        if area:
            self.area_id = area
        for point in points or []:
            self.add_point(point)

    @property
    def type(self):
        """Gets the type of annotation area this is

        :return: The area type
        """
        return self._get("type")

    @type.setter
    def type(self, value):
        """Sets the type of annotation area this is

        :param value: A type in the enum AreaTypes
        :raises ValidationError if type is not in AreaTypes
        """
        if value in AreaTypes.values():
            self._set("type", value)
        else:
            raise ValidationError("%s is not an allowed area type (%s)"
                                  % (value, ", ".join(AreaTypes.values())))

    @property
    def name(self):
        """Gets the name of this area

        :return: The area name
        """
        return self._get("name")

    @name.setter
    def name(self, value):
        """Sets the name of this area.

        :param value: The area name
        :raises Validation Error if value is not a string or None
        :raises Validation Error if value is an empty string
        """
        if value is None or isinstance(value, basestring):
            if value is not None and not value:
                raise ValidationError("area name cannot be an empty string")
            self._set("name", value)
        else:
            raise ValidationError("area name must be a string, not a %s" % type(value).__name__)

    @property
    def value(self):
        """Gets the scaled value in the range [0, 1] associated with the area

        :return: The area's value
        """
        return self._get("value")

    @value.setter
    def value(self, value):
        """Sets the scaled value in the range [0, 1] associated with the area

        :param value: A number in between 0 and 1
        :raises ValidationError if value is not a number or none
        :raises ValidationError if value is not greater than or equal to zero and less than or equal to one
        """
        if Number.is_real_number(value) or value is None:
            if not Number.is_finite_non_negative(value) and value is not None:
                raise ValidationError("Value must be in between 0 and 1 (value is %s)" % value)
            if value > 1.0 and value is not None:
                raise ValidationError("Value must be in between 0 and 1 (value is %s)" % value)
            self._set("value", value)
        else:
            raise ValidationError("Value must be a number (value is %s" % value)

    @property
    def shape(self):
        """Gets the shape the annotation points are defined as

        :return: The area shape
        """
        return self._get("shape")

    @shape.setter
    def shape(self, value):
        """Sets the shape the annotation points are defined as

        :param value: A shape in the enum Shapes
        :raises ValidationError if value is not in Shapes
        """
        if value in Shapes.values():
            self._set("shape", value)
        else:
            raise ValidationError("%s is not an allowed area shape (%s)"
                                  % (value, ", ".join(Shapes.values())))

    @property
    def map_id(self):
        """Get the associated area map ID for this area.

        :return: The area map ID.
        """
        return self._get('map')

    @map_id.setter
    def map_id(self, map_id):
        """Set the associated area map ID for this area.

        :param integer map_id: The area map ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_id not a finite positive integer.
        """
        if Number.is_integer(map_id):
            if not Number.is_finite_positive(map_id):
                raise ValidationError("Area map ID must be finite positive (item is %s)." % map_id)
            self._set('map', map_id)
        else:
            raise ValidationError("Area map ID must be an integer (%s is %s)."
                                  % (map_id, type(map_id).__name__))

    @property
    def map(self):
        """Get the associated area map for this area.

        :return: The Map object.
        """
        from fetchcore.resources.maps import Map
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the associated area map for this area.

        :param map: (integer|Map) An area map or area map ID.
        :type map: int, Map
        :raise fetchcore.exceptions.ValidationError: Thrown if map is not an area map object or an integer or None.
        """
        from fetchcore.resources.maps import Map
        if isinstance(map, Map):
            if not map.is_set("id"):
                map.save()
            self.map_id = map.id
        elif isinstance(map, int):
            self.map_id = map
        else:
            raise ValidationError('Map can only be an integer or Map (%s is %s).' % (map, type(map).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def area_id(self):
        """Get the associated area ID for this area draft.

        :return: The area ID.
        """
        return self._get('area')

    @area_id.setter
    def area_id(self, area_id):
        """Set the associated area ID for this area draft.

        :param integer area_id: The area ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if area_id not a finite positive integer.
        """
        if area_id is None:
            self._set('area', area_id)
        elif Number.is_integer(area_id):
            if not Number.is_finite_positive(area_id):
                raise ValidationError("Area ID must be finite positive (item is %s)." % area_id)
            self._set('area', area_id)
        else:
            raise ValidationError("Area ID must be an integer (%s is %s)."
                                  % (area_id, type(area_id).__name__))

    @property
    def points(self):
        """Gets a list of Point objects

        :return: The list of Point objects
        """
        return self._points

    @points.setter
    def points(self, value):
        """Sets a list of Point objects

        :param value: A list of dict of Point objects
        :raises ValidationError if value is not a list, or any element in the list is not a dict or a Point object
        """
        if not isinstance(value, list):
            raise ValidationError("Points must be a list")
        elif not value:
            self._points = value
        else:
            original_points = self._points[:]
            self.points = []
            try:
                for point in value:
                    self.add_point(point)
            except (ValidationError, KeyWordArgumentError) as e:
                self._points = original_points
                raise e

    def add_point(self, point, pos=None):
        """
        Adds a point to the area

        :param point: A point object or a dict
        :param pos: Position of the point to add to
        :raises AttributeError: if a point is not implemented
        :raises ValidationError: if point is not a dict or an Action object or derived form Action or has extra fields
        """
        if pos is None:
            pos = len(self._points)

        if isinstance(point, PointDraft):
            # If point is a Point object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._points.insert(pos, point)
        elif isinstance(point, dict):
            # Create a deepcopy of the point so as not to mess up the input
            point_dict = deepcopy(point)
            try:
                # Try to create an object
                self._points.insert(pos, PointDraft(**point_dict))
            except TypeError:
                # This happens when there are unexpected keyword argument
                # passed into __init__
                argspec = inspect.getargspec(PointDraft.__init__)
                # List of allowed keyword arguments
                keywords = argspec.args[-len(argspec.defaults):]
                # All the keys in point
                point_fields = point.keys()
                extra_fields = set(point_fields) - set(keywords)
                raise KeyWordArgumentError(
                    "PointDraft has extra field %s " % ", ".join(extra_fields) +
                    "(allowed field are %s)" % ", ".join(keywords))
        else:
            raise ValidationError("PointDraft should either be an PointDraft object or a "
                                  "dict, not a %s" % type(point).__name__)

    def pop_point(self, pos=None):
        """
        Removes a point at a position or the last point if position is not given

        :param pos: An integer

        :return: The point that was removed
        :raises IndexError: if you attempt to pop a point from an index that doesn't exist
        """
        if pos is None:
            pos = len(self._points) - 1
        try:
            return self._points.pop(pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop point %d but there are only %d points"
                % (pos, len(self._points)))

    def to_json_dict(self):
        """Gets the resource with point document as a json dictionary

        :return: The JSON dictionary
        """
        # Get json dict from each point
        point_json = [point.to_json_dict() for point in self._points]
        self._set("points", point_json)
        return super(AreaDraft, self).to_json_dict()


class Area(AreaDraft):
    """
    Class for Fetchcore map areas.
    """

    # The endpoint in fetchcore for areas
    endpoint = 'maps/annotations/areas'

    def __init__(self, id=None, type=None, name=None, value=None, shape=None, points=None, map=None, modifiers=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the area.
        :param AreaType type: The type of annotation area this is.
        :param string name: A human-readable name of the area.
        :param float value: A scaled value in the range [0, 1] associated with the area.
        :param Shape shape: The shape the annotation points are defined as.
        :param points: The list of points that are associated with this area.
        :param map: The map this area is associated with.
        :param created: The date and time of this area's creation.
        :param modified: The date and time this area was last modified.
        :type points: list of :class:`~fetchcore.resources.maps.point.Point` objects
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Area, self).__init__(id=id, type=type, name=name, value=value, shape=shape, map=map, modifiers=modifiers,
                                   points=points, created=created, modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    def add_point(self, point, pos=None):
        """
        Adds a point to the area

        :param point: A point object or a dict
        :param pos: Position of the point to add to
        :raises AttributeError: if a point is not implemented
        :raises ValidationError: if point is not a dict or an Action object or derived form Action or has extra fields
        """
        if pos is None:
            pos = len(self._points)

        if isinstance(point, Point):
            # If point is a Point object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._points.insert(pos, point)
        elif isinstance(point, dict):
            # Create a deepcopy of the point so as not to mess up the input
            point_dict = deepcopy(point)
            try:
                # Try to create an object
                self._points.insert(pos, Point(**point_dict))
            except TypeError:
                # This happens when there are unexpected keyword argument
                # passed into __init__
                argspec = inspect.getargspec(Point.__init__)
                # List of allowed keyword arguments
                keywords = argspec.args[-len(argspec.defaults):]
                # All the keys in point
                point_fields = point.keys()
                extra_fields = set(point_fields) - set(keywords)
                raise KeyWordArgumentError(
                    "Point has extra field %s " % ", ".join(extra_fields) +
                    "(allowed field are %s)" % ", ".join(keywords))
        else:
            raise ValidationError("Point should either be an Point object or a "
                                  "dict, not a %s" % type(point).__name__)
