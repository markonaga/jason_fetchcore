# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard library

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from .queue_point import QueuePoint, QueuePointDraft
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class QueueDraft(TimestampedResource):
    """
    Class for fetchcore map queue drafts.
    """

    # The endpoint in fetchcore for pose
    endpoint = 'maps/annotations/draft/queues'

    # Whether to exclude drafts
    draft = True

    def __init__(self, id=None, pose=None, queue_points=None, modifiers=None, queue=None,
                 created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the queue
        :param integer pose: The ID of the associated pose
        :param list queue_points: A list of QueuePoints
        :param modifiers: The users who have modified this annotation.
        :param queue: The queue draft that is associated with this queue draft.
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(QueueDraft, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.pose = pose
        self.modifiers = modifiers
        self._queue_points = []
        if queue:
            self.queue_id = queue
        for queue_point in queue_points or []:
            self.add_queue_point(queue_point)

    @property
    def queue_points(self):
        """
        :return: The queue points associated with this queue.
        """
        return self._queue_points

    @queue_points.setter
    def queue_points(self, value):
        """Setter for queue_points."""
        if not isinstance(value, list):
            raise ValidationError("Queue points must be a list")
        elif not value:
            self._queue_points = value
        else:
            original_queue_points = self._queue_points[:]
            self.queue_points = []
            try:
                for queue_point in value:
                    self.add_queue_point(queue_point)
            except (AttributeError, ValidationError) as e:
                self._queue_points = original_queue_points
                raise e

    def add_queue_point(self, queue_point, pos=None):
        """Add a queue point to this queue at given position.

        If position is not provided, it will be added to the end of the list of queue points."""
        if pos is None:
            pos = len(self._queue_points)

        if isinstance(queue_point, QueuePointDraft):
            if isinstance(queue_point, QueuePoint) == self.draft:
                raise ValidationError("Added queue point must be should be a %s, not a %s" %
                                      ("QueuePointDraft" if self.draft else "QueuePoint", type(queue_point).__name__))
            else:
                self._queue_points.insert(pos, queue_point)
        elif isinstance(queue_point, dict):
            klass = QueuePointDraft if self.draft else QueuePoint
            self._queue_points.insert(pos, klass.set_response(queue_point))
        else:
            raise ValidationError("Queue point should either be a %s or dict, not a %s." %
                                  ("QueuePointDraft" if self.draft else "QueuePoint", type(queue_point).__name__))

    def to_json_dict(self):
        """Gets the resource with queue_point documents as a json dictionary.

        :return: (dict) The JSON dictionary
        """
        # Get json dict from each action
        qp_json = [qp.to_json_dict() for qp in self._queue_points]
        self._set("queue_points", qp_json)
        return super(QueueDraft, self).to_json_dict()

    @property
    def pose_id(self):
        """Get the associated pose ID for this queue.

        :return: The pose ID.
        """
        return self._get('pose')

    @pose_id.setter
    def pose_id(self, pose_id):
        """Set the associated pose ID for this queue.

        :param integer pose_id: The pose ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose_id is not a finite positive integer.
        """
        if Number.is_integer(pose_id):
            if not Number.is_finite_positive(pose_id):
                raise ValidationError("Pose ID must be finite positive (item is %s)." % pose_id)
            self._set('pose', pose_id)
        else:
            raise ValidationError("Pose ID must be an integer (%s is %s)."
                                  % (pose_id, type(pose_id).__name__))

    @property
    def pose(self):
        """Get the associated pose for this queue.

        :return: The PoseDraft object.
        """
        from fetchcore.resources.maps import PoseDraft
        return PoseDraft.load(self.pose_id)

    @pose.setter
    def pose(self, pose):
        """Set the associated pose for this queue.

        :param pose: (integer|PoseDraft) A pose or pose ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose is not a PoseDraft object, an integer, or None.
        """
        from fetchcore.resources.maps import PoseDraft
        if isinstance(pose, PoseDraft):
            if not pose.is_set("id"):
                pose.save()
            self.pose_id = pose.id
        elif isinstance(pose, int):
            self.pose_id = pose
        else:
            raise ValidationError('Pose can only be an integer or PoseDraft (%s is %s).'
                                  % (pose, type(pose).__name__))

    @property
    def modifier_ids(self):
        """Get the users who modified this annotation.

        :return: The list of user IDs.
        """
        return self._get('modifiers')

    @property
    def modifiers(self):
        """Get the user objects for the users who modified this annotation.

        :return: The list of modifiers as User objects.
        """
        from fetchcore.resources import User
        return [User.load(modifier_id) for modifier_id in self.modifier_ids]

    @modifiers.setter
    def modifiers(self, modifier_ids):
        """Set the the users who modified this annotation.

        :param modifier_ids: A list of user IDs.
        :type modifier_ids: list of int
        :raise: ValidationError: Thrown if modifier_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if modifier_ids is None:
            self._set('modifiers', [])
        elif not isinstance(modifier_ids, list):
            raise ValidationError("Modifier ids must be a list, not a %s." % type(modifier_ids).__name__)
        else:
            modifier_ids = list(set(modifier_ids))
            for modifier_id in modifier_ids:
                if not Number.is_integer(modifier_id):
                    raise ValidationError("Each item in modifier IDs must be an int (%s is %s)."
                                          % (modifier_id, type(modifier_id).__name__))
                elif not Number.is_finite_positive(modifier_id):
                    raise ValidationError(
                        "Each item in modifier IDs must be finite positive (item is %s)." % modifier_id)
            self._set('modifiers', modifier_ids)

    @property
    def queue_id(self):
        """Get the associated queue ID for this queue draft.

        :return: The queue ID.
        """
        return self._get('queue')

    @queue_id.setter
    def queue_id(self, queue_id):
        """Set the associated queue ID for this queue draft.

        :param integer queue_id: The queue ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if queue_id not a finite positive integer.
        """
        if queue_id is None:
            self._set('queue', queue_id)
        elif Number.is_integer(queue_id):
            if not Number.is_finite_positive(queue_id):
                raise ValidationError("Queue ID must be finite positive (item is %s)." % queue_id)
            self._set('queue', queue_id)
        else:
            raise ValidationError("Queue ID must be an integer (%s is %s)."
                                  % (queue_id, type(queue_id).__name__))


class Queue(QueueDraft):
    """
    Class for Fetchcore map poses.
    """

    # The endpoint in fetchcore for queues
    endpoint = 'maps/annotations/queues'
    draft = False

    def __init__(self, id=None, pose=None, queue_points=None, modifiers=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the queue
        :param integer pose: The ID of the associated pose
        :param created: (string|datetime.datetime) The date and time of this pose's creation.
        :param modified: (string|datetime.datetime) The date and time this pose was last modified.
        """
        super(Queue, self).__init__(id=id, pose=pose, queue_points=queue_points, modifiers=modifiers, created=created,
                                    modified=modified, **kwargs)

    def save(self, _=None):
        """
        Overwrites base class dave. Live annotations are immutable and cannot be created on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be saved directly to the server.")

    def update(self, _=None):
        """
        Overwrites base class update. Live annotations are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """
        Overwrites base class delete. Live annotations are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation("Annotations are immutable and cannot be deleted on the server.")

    @property
    def pose(self):
        """Get the associated pose for this queue.

        :return: The Pose object.
        """
        from fetchcore.resources.maps import Pose
        return Pose.load(self.pose_id)

    @pose.setter
    def pose(self, pose):
        """Set the associated pose for this queue.

        :param pose: (integer|Pose) A pose or pose ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose is not a Pose object, an integer, or None.
        """
        from fetchcore.resources.maps import Pose
        if isinstance(pose, Pose):
            if not pose.is_set("id"):
                raise ValidationError('Pose must already have an ID.')
            self.pose_id = pose.id
        elif isinstance(pose, int):
            self.pose_id = pose
        else:
            raise ValidationError('Pose can only be an integer or Pose (%s is %s).'
                                  % (pose, type(pose).__name__))
