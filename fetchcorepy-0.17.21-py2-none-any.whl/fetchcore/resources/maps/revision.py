# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard Library
import copy

# fetchcore
from fetchcore import configuration, exceptions
from fetchcore.resources import TimestampedResource
from fetchcore.resources.maps import Map
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class Revision(TimestampedResource):
    """Revisions contain information about the changes that have been made to a map."""

    # Uncomment for the functionality to lookup revisions through map version number
    endpoint = 'maps/%(map_id)s/revisions'

    pk = 'version'

    def __init__(self, id=None, version=None, parent=None, map=None, areas=None, name=None, created=None,
                 modified=None, **kwargs):
        """
        :param integer id: The ID of the revision (assigned automatically upon creation).
        :param integer version: The version of this revision. If NULL, it is considered to be a draft,
            unpublished version.
        :param parent: The parent revision that this revision was based off of.
        :param integer map: The map this revision is associated with.
        :param string name: The display name for this revision.
        :param created: The date and time of this revision's creation (assigned automatically).
        :param modified: The date and time this revision was last modified (updated automatically).
        :type parent: int, Revision
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Revision, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.version = version
        self.parent = parent
        self.map = map
        self.name = name

        if Number.is_integer(map):
            if not Number.is_finite_positive(map):
                raise ValidationError("Map ID must be finite positive (item is %s)." % map)
            self.endpoint = 'maps/%(map_id)s/revisions' % {'map_id': str(map)}
        else:
            raise ValidationError("Map ID must be an integer (%s is %s)." % (map, type(map).__name__))

        if areas:
            self.__areas = areas

    @classmethod
    def set_response(cls, response):
        """This will make it possible for inherited classes to edit the data that is received from the server

        :param response: The data that is received from the server

        :return: The data that will be loaded
        """
        response_dict = copy.deepcopy(response)

        # TODO: Make this work for everything?

        # cls.__areas = response['areas']
        # response_dict.pop('areas')
        cls.__docks = response['docks']
        response_dict.pop('docks')
        cls.__edges = response['edges']
        response_dict.pop('edges')
        cls.__poses = response['poses']
        response_dict.pop('poses')
        return super(Revision, cls).set_response(**response_dict)

    def set_values(self, key, value):
        """Saves the data that is received from the server.

        :param key: The key to save the data for.
        :param value: The value to save.
        """
        if key == 'areas':
            self.__areas = value
        elif key == 'docks':
            self.__docks = value
        elif key == 'edges':
            self.__edges = value
        elif key == 'poses':
            self.__poses = value
        else:
            super(Revision, self).set_values(key, value)

    @classmethod
    def load(cls, identifier, client=None):
        """
        Load the resource from the fetchcore server with the given identifier.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).

        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get('maps/annotations/revisions', identifier)
            return cls.set_response(response)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with unique identifier '%s' does not exist on the server." % (cls.__name__, str(identifier))
            )

    @classmethod
    def load_version_from_map(cls, version, map_id, client=None):
        """
        Load the revision from the fetchcore server with the given version number from the given map.

        :param version: The version number of the revision to retrieve. Also accepted: 'latest' and 'draft' for the
            latest and draft versions, respectively.
        :param map_id: The resource ID of the map whose revision we are retrieving.
        :param client: The client that should be used (if None, the global fetchcore client is used).

        :type version: int, str
        :type map_id: int
        :type client: object

        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint % {'map_id': map_id}, version)
            return cls.set_response(response)
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with version number '%s' for map with ID '%s' does not exist on the server." %
                (cls.__name__, str(version), map_id)
            )

    @property
    def version(self):
        """Get the version of this revision.

        :return: The version number.
        """
        return self._get('version')

    @version.setter
    def version(self, version):
        """Set the version of this revision.

        :param integer version: The version number.
        :raise fetchcore.exceptions.ValidationError:: Thrown if version not a finite positive integer.
        """
        if version is None:
            self._set('version', version)
        elif Number.is_integer(version):
            if not Number.is_finite_positive(version):
                raise ValidationError("Version number must be finite positive (item is %s)." % version)
            self._set('version', version)
        else:
            raise ValidationError("Version number must be an integer (%s is %s)."
                                  % (version, type(version).__name__))

    @property
    def parent_id(self):
        """Get the parent revision ID that this revision was based off of.

        :return: The ID of the parent revision.
        """
        return self._get('parent')

    @parent_id.setter
    def parent_id(self, parent_id):
        """Set the parent revision id that this revision was based off of.

        :param integer parent_id: The ID of the parent revision.
        :raise fetchcore.exceptions.ValidationError:: Thrown if parent_id not a finite positive integer.
        """
        if parent_id is None:
            self._set('parent', parent_id)
        elif Number.is_integer(parent_id):
            if not Number.is_finite_positive(parent_id):
                raise ValidationError("Parent ID must be finite positive (item is %s)." % parent_id)
            self._set('parent', parent_id)
        else:
            raise ValidationError("Parent ID must be an integer (%s is %s)." % (parent_id, type(parent_id).__name__))

    @property
    def parent(self):
        """Get the parent revision that this revision was based off of.

        :return: The Revision object or None.
        """
        return None if self.parent_id is None else Revision.load(self.parent_id)

    @parent.setter
    def parent(self, parent):
        """Set the parent revision that this revision was based off of.

        :param parent: (integer|Revision) A Revision or parent ID.
        :type parent: int, Revision
        :raise fetchcore.exceptions.ValidationError:: Thrown if parent is not an revision object, integer, or None.
        """
        if isinstance(parent, Revision):
            if not parent.is_set("id"):
                parent.save()
            self.parent_id = parent.id
        elif parent is None or isinstance(parent, int):
            self.parent_id = parent
        else:
            raise ValidationError('Parent can only be an integer, Revision object or None (%s is %s).'
                                  % (parent, type(parent).__name__))

    @property
    def map_id(self):
        """Get the map ID that this revision belongs to.

        :return: The map ID.
        """
        return self._get('map')

    @property
    def map(self):
        """Get the map object that this revision belongs to.

        :return: The Map object.
        """
        return Map.load(self.map_id)

    @map.setter
    def map(self, map):
        """Set the map that this revision belongs to.

        :param integer map: The map.
        :raise fetchcore.exceptions.ValidationError:: Thrown if map not a finite positive integer.
        """
        if Number.is_integer(map):
            if not Number.is_finite_positive(map):
                raise ValidationError("Map ID must be finite positive (item is %s)." % map)
            self._set('map', map)
        else:
            raise ValidationError("Map ID must be an integer (%s is %s)." % (map, type(map).__name__))

    @property
    def name(self):
        """Get the display name for this revision.

        :return: The display name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """Set the display name for this revision.

        :param string name: The display name.
        :raise fetchcore.exceptions.ValidationError:: Thrown if name is not a string or is an empty string.
        """
        if name is None:
            self._set('name', name)
        elif isinstance(name, basestring):
            if not name:
                raise ValidationError("Map name cannot be empty.")
            self._set('name', name)
        else:
            raise ValidationError("Map name must be a string, not a %s." % type(name).__name__)

    @property
    def area_ids(self):
        """Get the associated area IDs for this revision.

        :return: The list of area IDs.
        """
        return self._get('areas')

    @area_ids.setter
    def __area_ids(self, area_ids):
        """Set the associated area IDs for this revision.

        :param list of integers area_ids: A list of area IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if area_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if area_ids is None:
            self._set('areas', [])
        elif not isinstance(area_ids, list):
            raise ValidationError("Area ids must be a list, not a %s." % type(area_ids).__name__)
        else:
            area_ids = list(set(area_ids))
            for area_id in area_ids:
                if not Number.is_integer(area_id):
                    raise ValidationError("Each item in area IDs must be an integer (%s is %s)."
                                          % (area_id, type(area_id).__name__))
                elif not Number.is_finite_positive(area_id):
                    raise ValidationError(
                        "Each item in area IDs must be finite positive (item is %s)." % area_id)
            self._set('areas', area_ids)

    @property
    def areas(self):
        """Get the areas associated with this revision.

        :return: The areas
        """
        from fetchcore.resources.maps import Area
        return [Area.load(area_id) for area_id in self.area_ids]

    @areas.setter
    def __areas(self, areas):
        """Set the associated areas for this revision.

        :param areas: (list of integers|list of Areas) A list of areas or area IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if areas is not a list, if each item in values
                is not an integer, or if each item in the list is not a finite positive integer.
        """
        from fetchcore.resources.maps import Area
        if areas is None:
            self.__area_ids = areas
        elif not isinstance(areas, (list, tuple)):
            raise ValidationError('Areas must be either None, a list or a tuple.')
        # elif not all(isinstance(area, (int, Area)) for area in areas):
        #     raise ValidationError('Areas must be a list of Area objects or integers.')
        else:
            area_ids = []
            for area in areas:
                if isinstance(area, Area):
                    if not hasattr(area, 'id'):
                        area.save()
                    area_ids.append(area.id)
                elif isinstance(area, dict) and 'id' in area:
                    area_ids.append(area['id'])
            self._set('areas', area_ids)

    @property
    def dock_ids(self):
        """Get the associated dock IDs for this revision.

        :return: The list of dock IDs.
        """
        return self._get('docks')

    @dock_ids.setter
    def __dock_ids(self, dock_ids):
        """Set the associated dock IDs for this revision.

        :param list of integers dock_ids: A list of dock IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if dock_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if dock_ids is None:
            self._set('docks', [])
        elif not isinstance(dock_ids, list):
            raise ValidationError("Dock ids must be a list, not a %s." % type(dock_ids).__name__)
        else:
            dock_ids = list(set(dock_ids))
            for dock_id in dock_ids:
                if not Number.is_integer(dock_id):
                    raise ValidationError("Each item in dock IDs must be an integer (%s is %s)."
                                          % (dock_id, type(dock_id).__name__))
                elif not Number.is_finite_positive(dock_id):
                    raise ValidationError(
                        "Each item in dock IDs must be finite positive (item is %s)." % dock_id)
            self._set('docks', dock_ids)

    @property
    def docks(self):
        """Get the docks associated with this revision.

        :return: The docks
        """
        from fetchcore.resources.maps import Dock
        return [Dock.load(dock_id) for dock_id in self.dock_ids]

    @docks.setter
    def __docks(self, docks):
        """Set the associated docks for this revision.

        :param docks: (list of integers|list of Docks) A list of docks or dock IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if docks is not a list, if each item in values
                is not an integer, or if each item in the list is not a finite positive integer.
        """
        from fetchcore.resources.maps import Dock
        if docks is None:
            self.__dock_ids = docks
        elif not isinstance(docks, (list, tuple)):
            raise ValidationError('Docks must be either None, a list or a tuple.')
        elif not all(isinstance(dock, (int, Dock)) for dock in docks):
            raise ValidationError('Docks must be a list of Dock objects or integers.')
        else:
            for dock in docks:
                if isinstance(dock, Dock) and not hasattr(dock, 'id'):
                    dock.save()
            self.__dock_ids = [dock.id if isinstance(dock, Dock) else dock for dock in docks]

    @property
    def edge_ids(self):
        """Get the associated edge IDs for this revision.

        :return: The list of edge IDs.
        """
        return self._get('edges')

    @edge_ids.setter
    def edge_ids(self, edge_ids):
        """Set the associated edge IDs for this revision.

        :param list of integers edge_ids: A list of edge IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if edge_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if edge_ids is None:
            self._set('edges', [])
        elif not isinstance(edge_ids, list):
            raise ValidationError("Edge ids must be a list, not a %s." % type(edge_ids).__name__)
        else:
            edge_ids = list(set(edge_ids))
            for edge_id in edge_ids:
                if not Number.is_integer(edge_id):
                    raise ValidationError("Each item in edge IDs must be an integer (%s is %s)."
                                          % (edge_id, type(edge_id).__name__))
                elif not Number.is_finite_positive(edge_id):
                    raise ValidationError(
                        "Each item in edge IDs must be finite positive (item is %s)." % edge_id)
            self._set('edges', edge_ids)

    @property
    def edges(self):
        """Get the edges associated with this revision.

        :return: The edges
        """
        from fetchcore.resources.maps import Edge
        return [Edge.load(edge_id) for edge_id in self.edge_ids]

    @edges.setter
    def __edges(self, edges):
        """Set the associated edges for this revision.

        :param edges: (list of integers|list of Edges) A list of edges or edge IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if edges is not a list, if each item in values
                is not an integer, or if each item in the list is not a finite positive integer.
        """
        from fetchcore.resources.maps import Edge
        if edges is None:
            self.__edge_ids = edges
        elif not isinstance(edges, (list, tuple)):
            raise ValidationError('Edges must be either None, a list or a tuple.')
        elif not all(isinstance(edge, (int, Edge)) for edge in edges):
            raise ValidationError('Edges must be a list of Edge objects or integers.')
        else:
            for edge in edges:
                if isinstance(edge, Edge) and not hasattr(edge, 'id'):
                    edge.save()
            self.__edge_ids = [edge.id if isinstance(edge, Edge) else edge for edge in edges]

    @property
    def pose_ids(self):
        """Get the associated pose IDs for this revision.

        :return: The list of pose IDs.
        """
        return self._get('poses')

    @pose_ids.setter
    def pose_ids(self, pose_ids):
        """Set the associated pose IDs for this revision.

        :param list of integers pose_ids: A list of pose IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if pose_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if pose_ids is None:
            self._set('poses', [])
        elif not isinstance(pose_ids, list):
            raise ValidationError("Pose ids must be a list, not a %s." % type(pose_ids).__name__)
        else:
            pose_ids = list(set(pose_ids))
            for pose_id in pose_ids:
                if not Number.is_integer(pose_id):
                    raise ValidationError("Each item in pose IDs must be an integer (%s is %s)."
                                          % (pose_id, type(pose_id).__name__))
                elif not Number.is_finite_positive(pose_id):
                    raise ValidationError(
                        "Each item in pose IDs must be finite positive (item is %s)." % pose_id)
            self._set('poses', pose_ids)

    @property
    def poses(self):
        """Get the poses associated with this revision.

        :return: The poses
        """
        from fetchcore.resources.maps import Pose
        return [Pose.load(pose_id) for pose_id in self.pose_ids]

    @poses.setter
    def __poses(self, poses):
        """Set the associated poses for this revision.

        :param poses: (list of integers|list of Poses) A list of poses or pose IDs.
        :raise fetchcore.exceptions.ValidationError: Thrown if poses is not a list, if each item in values
                is not an integer, or if each item in the list is not a finite positive integer.
        """
        from fetchcore.resources.maps import Pose
        if poses is None:
            self.__pose_ids = poses
        elif not isinstance(poses, (list, tuple)):
            raise ValidationError('Poses must be either None, a list or a tuple.')
        elif not all(isinstance(pose, (int, Pose)) for pose in poses):
            raise ValidationError('Poses must be a list of Pose objects or integers.')
        else:
            for pose in poses:
                if isinstance(pose, Pose) and not hasattr(pose, 'id'):
                    pose.save()
            self.__pose_ids = [pose.id if isinstance(pose, Pose) else pose for pose in poses]
