# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts, Russell Toris

# Futures
from __future__ import unicode_literals

# Standard library
import datetime
import json
from collections import Iterable

# fetchcore
from fetchcore import configuration
from fetchcore import exceptions
from fetchcore.utils import Timestamp, Duration
from fetchcore.exceptions import ValidationError, UndefinedFieldError


class Resource(object):
    """
    Base class for all fetchcore resources.
    """

    # The endpoint to hit in fetchcore -- should be overwritten in client classes
    endpoint = None

    # The primary key that the resource should use as lookup when accessing the API.
    pk = "id"

    # Read only fields so that we don't try to setattr them
    read_only_fields = ()

    def __init__(self, id=None):
        """Creates a new Resource with the given optional arguments.

        :param int id: The ID of the resource (assigned automatically upon creation).
        """

        # The JSON document that will be sent to the server
        self.__json = {}

        # A set of keys that have been set since the last update() call
        self.__set_since_update = set()

        # TODO: add validation to this
        if id:
            self._set('id', id)

    @classmethod
    def set_response(cls, response):
        """This will make it possible for inherited classes to edit the data that is received from the server

        :param dict response: The data that is received from the server
        :returns: The data that will be loaded
        :returns: None if the data is a non-dict
        """
        try:
            return cls(**response)
        except TypeError:
            return None

    @classmethod
    def load(cls, identifier, client=None):
        """Load the resource from the fetchcore server with the given identifier.

        :param identifier: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :return: The loaded resource from the server.
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls.__validate_client(client)

        try:
            response = client.get(cls.endpoint, identifier)
            if not response:
                raise exceptions.ConnectionError("Received no response when attempting to load resource.")
            return cls.set_response(response)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s with unique identifier '%s' does not exist on the server." % (cls.__name__, str(identifier))
            )

    @classmethod
    def load_url_content(cls, endpoint, client=None):
        """Load the content from an endpoint.

        :param endpoint: The target endpoint URL to retrieve.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :return: The content of the response from the URL.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls.__validate_client(client)
        try:
            response = client.get(endpoint, raw=True)
            return response
        except exceptions.NotFound:
            raise exceptions.DoesNotExist("Could not retrieve content specified at endpoint %s." % endpoint)

    @classmethod
    def list(cls, client=None, endpoint=None, page=None, offset=None, amount=None):
        """List the specified amount of the given resource from the fetchcore server.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :param page: The optional page to load.
        :param offset: The first n elements to skip when loading.
        :param amount: The number of elements to load (set to any negative integer to try to load all of them).
        :return: The loaded resources from the server.
        :raise ~fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ~fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise ~fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """

        if not client:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            endpoint_to_use = endpoint if endpoint else cls.endpoint
            response = client.get(endpoint_to_use, page=page, offset=offset, amount=amount)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            raise exceptions.DoesNotExist(
                "%s does not exist on the server." % cls.__name__
            )

        if not response:
            return []

        return [cls.set_response(result) for result in response.get('results', [])]

    @property
    def id(self):
        """The unique ID of this resource.

        :return: The unique ID of this resource.
        """
        return self._get('id')

    # TODO: remove this and have get return none
    def is_set(self, field):
        """Check if the given field is set.

        :param field: The field name to check.
        :return: True if the given field is set.
        """
        return field in self.__json

    # TODO: change to to_json to match c++ sdk
    def to_json_dict(self):
        """Returns a copy of this Resource as a JSON dictionary.

        :return: A copy of this Resource as a JSON dictionary.
        """
        # Convert standard types to strings
        final = {}
        for key, value in self.__json.iteritems():
            try:
                if isinstance(value, datetime.datetime):
                    final[key] = Timestamp.to_string(value)
                elif isinstance(value, datetime.timedelta):
                    final[key] = Duration.to_string(value)
                else:
                    final[key] = value
            except TypeError as e:
                raise ValidationError(e)
        return final

    def set_values(self, key, value):
        """Saves the data that is received from the server.

        :param key: The key to save the data for.
        :param value: The value to save.
        """
        if key == 'id':
            self._set(key, value)
        elif key in self.read_only_fields:
            self._set(key, value)
        else:
            self.__setattr__(key, value)

    def save(self, client=None):
        """Save the current resource to the server. If the resource does not yet exist, it will be created. If it
        already exists all fields on the server will be overwritten with the current values.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self.__validate_client(client)

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                # TODO if map add 'format' argument
                response = client.post(self.endpoint, self.to_json_dict()) or {}
            else:
                response = client.put(self.endpoint, getattr(self, self.pk), self.to_json_dict()) or {}
            # Save back the data we got
            for key, value in response.iteritems():
                self.set_values(key, value)
                self.__set_since_update.discard(key)
            return response
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Saving or updating of the current data is unsupported by fetchcore.")

    def update(self, client=None):
        """Update the resource on the server with fields changed for the current resource since the last update call.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource does not exist on the server (updates only).
        :raise UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self.__validate_client(client)

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                raise exceptions.DoesNotExist("You cannot update a resource that is not on the server.")
            elif self.__set_since_update:
                # Generate minimal PATCH update iff we've changed fields since the last update
                patch_data = {}
                actual_set = self.__set_since_update.copy()
                json_data = self.to_json_dict()
                for field in list(actual_set):
                    patch_data[field] = json_data[field]
                    actual_set.discard(field)
                self.__set_since_update = actual_set
                # Check if we have anything to send
                if patch_data:
                    return client.patch(self.endpoint, getattr(self, self.pk), patch_data)
                else:
                    # We should just update in that case
                    self.refresh(client=client)
                    return self.to_json_dict()

        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Deleting the current data is unsupported by fetchcore.")

    def delete(self, client=None):
        """Delete this resource from the server. The resource's ID must be set for this operation to work.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise UnsupportedOperation: Thrown if DELETE is not allowed or the resource doesn't exist.
        :raise InternalServerError: Thrown if the server responds with an error.
        """

        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self.__validate_client(client)

        try:
            # First, check if we are creating a new instance
            if not self.is_set('id'):
                raise exceptions.DoesNotExist("You cannot delete a resource that is not on the server.")

            client.delete(self.endpoint, getattr(self, self.pk))
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.BadRequest as e:
            raise exceptions.ValidationError(e.message)
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Deleting the current data is unsupported by fetchcore.")

            # TODO: Add actual destructor? I don't think it's necessary or done in most modules anyway
        # Safe removal of ID
        self._pop('id')

    def refresh(self, client=None):
        """Refresh this resource instance with the latest data from the server.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        self.__validate_client(client)

        try:
            # TODO: check if ID is set

            response = client.get(self.endpoint, getattr(self, self.pk)) or {}
            # Save back the data we got
            for key, value in response.iteritems():
                self.set_values(key, value)
                self.__set_since_update.discard(key)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except exceptions.NotFound:
            # Cleanup internally
            self._set('id', None)
            raise exceptions.DoesNotExist("Resource no longer exists on the server.")
        except exceptions.MethodNotAllowed:
            raise exceptions.UnsupportedOperation("Loading of the current data is unsupported by fetchcore.")

    def _pop(self, field):
        self.__json.pop(field, None)

    def _set(self, field, value):
        """Set the given field to the corresponding value.

        :param field: The field name to set.
        :param value: The value of the field.
        :raise ValidationError: Thrown if field is not a string or an iterable.
        """
        # TODO: reconsider how the iterable field is dealt with
        if isinstance(field, basestring):
            # Set the value
            self.__json[field] = value
            self.__set_since_update.add(field)
        elif isinstance(field, Iterable):
            # If field is an iterable (list, generator...), it cannot be empty
            if not field:
                raise ValidationError("Field cannot be an empty list")
            # Convert field into a list to get the length
            fields = list(field)
            # Set nested fields iteratively
            # Reference: http://stackoverflow.com/questions/13687924/setting-a-value-in-a-nested-python-dictionary
            # -given-a-list-of-indices-and-value
            dic = self.__json
            for key in fields[:-1]:
                # setdefault returns the key's value if it is in the dictionary
                # If not, insert key with a value of default and return default
                # (which, in this case, is {})
                dic = dic.setdefault(key, {})
            dic[fields[-1]] = value
            self.__set_since_update.add(fields[0])

    # TODO: should this return None if it does not exist or should there be a check function?
    def _get(self, field):
        """Get the given field.

        :param field: The field name to get.
        :return: The value of the field.
        :raise ValidationError: Thrown if field is not a string or an iterable.
        """

        # TODO: reconsider how the iterable field is dealt with
        if isinstance(field, basestring):
            try:
                # If field is a string, try getting the value by the field
                return self.__json[field]
            except KeyError:
                raise UndefinedFieldError("%s is not set." % field)
        elif isinstance(field, Iterable):
            if not field:
                raise ValidationError(
                    "Input attribute 'field' cannot be a empty list")
            # Get the value from the nested dictionary
            value = self.__json
            for i, f in enumerate(field):
                try:
                    value = value[f]
                except KeyError:
                    raise UndefinedFieldError("%s is not set" % ".".join(field[:i + 1]))
            return value
        else:
            raise ValidationError("Field must be a string or an iterable")

    def has_patch_set(self):
        return len(self.__set_since_update) > 0

    def _reset_patch_set(self):
        self.__set_since_update.clear()

    def _discard_from_patch_set(self, key):
        self.__set_since_update.discard(key)

    def _add_to_patch_set(self, key):
        self.__set_since_update.add(key)

    @staticmethod
    def __validate_client(client):
        """Validate the given fetchcore client and throw an exception if there are connection issues.

        :param client: The client to validate.
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        """
        if client is None:
            raise exceptions.ConnectionError("Client is not configured correctly. Check global client settings.")
        client.connect()

    def __eq__(self, other):
        """Check if the given resource is equal to this resource.

        :param other: The other resource to compare against.
        :return: If the given resource equals this resource.
        """
        return vars(self) == vars(other)

    def __str__(self):
        """Returns a JSON string representation of this resource.

        :return: A JSON string representation of this resource.
        """
        # Use separators to avoid trailing spaces in the string
        return json.dumps(self.to_json_dict(), indent=4, sort_keys=True, separators=(',', ': '))
