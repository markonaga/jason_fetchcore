# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard library
from copy import deepcopy
import re

# Fetchcore SDK Python
from .templates.task_template import TaskTemplate
from fetchcore.definitions import REGEX_CAPITAL_NUMBER_UNDERSCORE, ROBOT_NAME_PATTERN, TaskStatus
from fetchcore.resources import TimestampedResource, Action, Schedule
from fetchcore.resources.robots import Robot
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, KeyWordArgumentError, UnsupportedOperation
from fetchcore import configuration, exceptions


class Task(TimestampedResource):
    """
    Tasks contain information about a series of actions that a robot can execute.
    """
    endpoint = 'tasks'
    read_only_fields = ('children', 'root',)

    def __init__(
            self, id=None, name=None, status=TaskStatus.NEW, type=None, schedule=None, task_template=None, robot=None,
            requester=None, actions=None, parent=None, children=None, root=None, created=None, modified=None, **kwargs):
        """
        :param id: (integer) The ID of the task.
        :param name: (string) The human-readable name of the task.
        :param status: (string) The current status of the task.
        :param type: (string) The type association of the task.
        :param schedule: (integer|Schedule) The schedule that generated this task.
        :param task_template: (integer|TaskTemplate) The template for this task.
        :param actions: (list) The actions associated with this task.
        :param robot: (string) Name of the robot assigned to this task.
        :param requester: (string) (OPTIONAL) The username of the user that created this task.
        :param parent: (int|Task) (OPTIONAL) The id of the task that spawned this task.
        :param children: (list) (OPTIONAL) List of ids of the task that this task spawned.
        :param root: (int|Task) (OPTIONAL) The root of the task tree for this task.
        :param created: (string|datetime.datetime) The date and time of this task's creation.
        :param modified: (string|datetime.datetime) The date and time this task was last modified.
        """
        super(Task, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.type = type
        if name:
            self.name = name
        self.status = status
        if schedule:
            self.schedule = schedule
        if task_template:
            self.task_template = task_template
        if requester:
            self.requester = requester
        self._actions = []
        for action in actions or []:
            self.add_action(action)
        self.robot = robot
        if parent:
            self.parent = parent
        if root:
            if not isinstance(root, int):
                raise ValidationError("Root must be an int, not a %s." % type(root).__name__)
            self._set("root", root)
        if children:
            if not isinstance(children, list):
                raise ValidationError("Children must be a list, not a %s." % type(children).__name__)
            children_in = list(set(children))
            for child in children_in:
                if not Number.is_integer(child):
                    raise ValidationError("Each item in children must be an integer (%s is %s)."
                                          % (child, type(child).__name__))
                elif not Number.is_finite_positive(child):
                    raise ValidationError(
                        "Each item in poses must be finite positive (item is %s)." % child)
            self._set("children", children)
        self._reset_patch_set()

    def delete(self, _=None):
        """
        Overwrites base class delete. Tasks cannot be deleted on the server.
        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation("Tasks cannot be deleted on the server.")

    @property
    def name(self):
        """Gets the name of this task

        :return: (string) The task name
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Sets the name of this task

        :param name: (string) The task name
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a string or None, or is an empty string
        """
        if name is None or isinstance(name, basestring):
            if name is not None and not name:
                raise ValidationError("Task name cannot be an empty string")
            self._set("name", name)
        else:
            raise ValidationError("Task name must be a string, not a %s" % type(name).__name__)

    @property
    def status(self):
        """Gets the status of this task

        :return: (string) The task status
        """
        return self._get("status")

    @status.setter
    def status(self, status):
        """Sets the status of this task

        :param status: (string) A task status
        :raises fetchcore.exceptions.ValidationError: Thrown if the task status is not one of the allowed statuses
        """
        if status in TaskStatus.values():
            self._set("status", status)
        else:
            raise ValidationError("%s is not an allowed task status (%s)" % (status, ", ".join(TaskStatus.values())))

    @property
    def type(self):
        """Gets the type of this task

        :return: (string) The task type
        """
        return self._get("type")

    @type.setter
    def type(self, type):
        """Sets the type of this task

        :param type: (string) A task type
        :raises: fetchcore.exceptions.ValidationError: Thrown if type is not a string or does not contain only
        capital letters and underscores
        """
        try:
            if re.match(re.compile(REGEX_CAPITAL_NUMBER_UNDERSCORE), type):
                self._set("type", type)
            else:
                raise ValidationError("%s does not match the pattern %s." % (type, REGEX_CAPITAL_NUMBER_UNDERSCORE))
        except TypeError:
            raise ValidationError("Task type must be a string.")

    @property
    def schedule_id(self):
        """Gets resource ID of the schedule that this task is associated with.

        :return: (integer) The resource ID of the schedule.
        """
        return self._get('schedule')

    @schedule_id.setter
    def schedule_id(self, id):
        """Sets resource ID of the schedule that this task is associated with.

        :param id: (integer) The resource id of the schedule.
        :raise fetchcore.exceptions.ValidationError: Thrown if id is not None or a positive integer.
        """
        if id is None:
            self._set("schedule", id)
        elif Number.is_integer(id):
            if not Number.is_finite_positive(id):
                raise ValidationError("Schedule ID must be a finite positive number or None (value is %s)" % id)
            self._set("schedule", id)
        else:
            raise ValidationError("Schedule ID must be a number or None (value is %s)" % id)

    @property
    def schedule(self):
        """Gets the schedule that is associated with this task

        :return: (Schedule) The task's schedule as a Schedule object.
        """
        return None if self.schedule_id is None else Schedule.load(self.schedule_id)

    @schedule.setter
    def schedule(self, schedule):
        """Sets the schedule that this task is associated with

        :param schedule: (integer|Schedule|None) The associated schedule.
        :raise fetchcore.exception.ValidationError: Thrown if value is not an integer, a Schedule object or None.
        """
        if isinstance(schedule, Schedule):
            if not schedule.is_set("id"):
                schedule.save()
            self.schedule_id = schedule.id
        elif schedule is None or isinstance(schedule, int):
            self.schedule_id = schedule
        else:
            raise ValidationError('Schedule can only be an integer, Schedule or None (%s is %s).'
                                  % (schedule, type(schedule).__name__))

    @property
    def task_template_id(self):
        """Gets resource ID of the task template that is associated with this task

        :return: The task's task template
        """
        return self._get("task_template")

    @task_template_id.setter
    def task_template_id(self, id):
        """Sets resource ID the task template that this task is associated with

        :param id: (integer|None) The associated task template
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a finite positive integer or None.
        """
        if id is None or Number.is_integer(id):
            if id is not None and not Number.is_finite_positive(id):
                raise ValidationError("Task template ID must be a finite positive number or None (value is %s)" % id)
            self._set("task_template", id)
        else:
            raise ValidationError("Task template ID must be a number or None (value is %s)" % id)

    @property
    def task_template(self):
        """Gets the task template that this task is associated with.

        :return: (TaskTemplate) The task template as a TaskTemplate object.
        """
        return None if self.task_template_id is None else TaskTemplate.load(self.task_template_id)

    @task_template.setter
    def task_template(self, task_template):
        """Sets the task template that this task is associated with.

        :param task_template: (integer|TaskTemplate|None) The task template as an object or by its ID, or None.
        :raises fetchcore.exceptions.ValidationError: Thrown if template is not None, an integer or a TaskTemplate
        object.
        """
        if isinstance(task_template, TaskTemplate):
            if not task_template.is_set('id'):
                task_template.save()
            self.task_template_id = task_template.id
        elif task_template is None or isinstance(task_template, int):
            self.task_template_id = task_template
        else:
            raise ValidationError('Task template can only be an integer, TaskTemplate or None (%s is %s).'
                                  % (task_template, type(task_template).__name__))

    @property
    def actions(self):
        """Gets a list of Action objects.

        :return: (list) The list of Action objects.
        """
        return self._actions

    @actions.setter
    def actions(self, value):
        """Sets a list of Action objects.

        :param value: (list) A list of dict or Action objects
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a list, or any element in the list is
        not a dict or an Action object.
        """
        if not isinstance(value, list):
            raise ValidationError("Actions must be a list")
        elif not value:
            self._actions = value
            self._add_to_patch_set('actions')
        else:
            original_actions = self._actions[:]
            self.actions = []
            try:
                for action in value:
                    self.add_action(action)
                self._add_to_patch_set('actions')
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._actions = original_actions
                raise e

    def add_action(self, action, pos=None):
        """
        Adds an action to the Task.

        :param action: (dict|Action) The new action.
        :param pos: (integer|None) Position of the action to add to.
        :raises AttributeError: if action is not implemented.
        :raises ValidationError: Thrown if action is not a dict, an Action object or derived from Action
        """
        if pos is None:
            pos = len(self._actions)

        if isinstance(action, Action):
            # If action is an Action object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._actions.insert(pos, action)
        elif isinstance(action, dict):
            # Create a deepcopy of the action so as not to mess up the input
            action_dict = deepcopy(action)
            try:
                # Get action name
                action_name = action_dict.pop("action_definition")
            except KeyError:
                raise ValidationError("Action does not have an action name")
            # Get the class for the action
            action_class = Action.get_action_class(action_name)

            # Custom action support
            if action_class == Action:
                action_dict['action_definition'] = action_name

            # Try to create an object
            self._actions.insert(pos, action_class(**action_dict))
        else:
            raise ValidationError("Action should either be an Action object or a "
                                  "dict, not a %s" % type(action).__name__)

    def pop_action(self, pos=None):
        """
        Removes an action at a position or the last action if position is not given.

        :param pos: (integer|None) The position of the action to pop out.
        :return: (Action) The action that was removed.
        :raises IndexError: Thrown if you attempt to pop an action that from an index that doesn't exist.
        """
        if pos is None:
            pos = len(self._actions) - 1
        try:
            return self._actions.pop(pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop action %d but there are only %d actions"
                % (pos, len(self._actions)))

    @property
    def robot_name(self):
        """Gets the name of the robot assigned to this task.

        :return: (string) Name of the assigned robot.
        """
        return self._get('robot')

    @robot_name.setter
    def robot_name(self, robot_name):
        """Sets the name of the robot assigned to this task.

        :param robot_name: (string|None) Name of the assigned robot.
        :raise fetchcore.exception.ValidationError: Thrown if robot_name is not None or not a Freight's name.
        """
        try:
            if robot_name is None or re.compile(ROBOT_NAME_PATTERN).match(robot_name):
                self._set('robot', robot_name)
            else:
                raise ValidationError(
                    'Only Freights can be assigned to tasks. %s does not seem to be a Freight.' % robot_name)
        except TypeError:
            raise ValidationError('Robot name can only be the name of a Freight or None.')

    @property
    def robot(self):
        """Gets the resource of the robot assigned to this task.

        :return: (Robot) The assigned robot as a Robot object.
        """
        return None if self.robot_name is None else Robot.load(self.robot_name)

    @robot.setter
    def robot(self, robot):
        """Sets the robot assigned to this task.

        :param robot: (string|Robot|None) The resource or name of the assigned robot.
        :raise fetchcore.exceptions.ValidationError: Thrown if robot is not None, a string, or a Robot object.
        """
        if isinstance(robot, Robot):
            self.robot_name = robot.name
        elif robot is None or isinstance(robot, basestring):
            self.robot_name = robot
        else:
            raise ValidationError(
                'Robot can only be a string, Robot or None (%s is %s).' % (robot, type(robot).__name__))

    @property
    def requester(self):
        """Get the username of the user that generated this task.

        :return: The username of the associated user.
        """
        return self._get('requester')

    @requester.setter
    def requester(self, requester):
        """Set the username for the user that generated this task.

        :param username: (string|None) The username of the user that generated this task.
        :raise: fetchcore.exceptions.ValidationError Thrown if the requester is not a string or None.
        """
        # Username is optional, we can unset it
        if requester is None or isinstance(requester, basestring):
            self._set('requester', requester)
        else:
            raise ValidationError("The requester must be a string, not a %s." % type(requester).__name__)

    @property
    def parent(self):
        """Gets the ID of the parent task that spawned this task.

        :return: The task's parent task.
        """
        return self._get("parent")

    @parent.setter
    def parent(self, id):
        """Sets the ID of the parent task that spawned this task.

        :param id: (integer|None) The associated parent task.
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a finite positive integer or None.
        """
        if id is None or Number.is_integer(id):
            if id is not None and not Number.is_finite_positive(id):
                raise ValidationError("Parent task ID must be a finite positive number or None (value is %s)" % id)
            self._set("parent", id)
        else:
            raise ValidationError("Parent task ID must be a number or None (value is %s)" % id)

    @property
    def children(self):
        """Gets the IDs of the child tasks that this task spawned.

        :return: (list) List of task IDs.
        """
        return self._get('children') if self.is_set('children') else []

    @property
    def root(self, client=None):
        """Gets the root task for this task.

        :return: (int) Root task.
        """
        # Check if we are using the global client
        return self._get('root')

    @classmethod
    def count(cls, client=None):
        """Gets the number of tasks in the system.

        :param client: The client to make this request with. If not provided, it will default to the global client.
        :return: The number of tasks
        :rtype: Integer
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(cls.endpoint)
            return response['count']
        except exceptions.NotFound:
            raise exceptions.DoesNotExist("%s does not exist on the server." % cls.__name__)

    def to_json_dict(self):
        """Gets the resource with action document as a json dictionary.

        :return: (dict) The JSON dictionary
        """
        # Get json dict from each action
        action_json = [action.to_json_dict() for action in self._actions]
        task_json = super(Task, self).to_json_dict()
        task_json['actions'] = action_json
        return task_json

    @staticmethod
    def make_from_template(task_template):
        """
        Converts templates to tasks.

        :param task_template (TaskTemplate): The template to convert into a task.
        :throws ValidationError: if task template has not been saved
        """
        if task_template.id is None:
            raise ValidationError("Task.make_from_template: can't create task from unsaved template.")

        actions = []
        for action_template in task_template.action_templates:
            actions.append(Action.make_from_template(action_template))

        return Task(type=('TASKTEMPLATE_%s' % task_template.id), task_template=task_template, status=TaskStatus.NEW,
                    actions=actions)
