# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class TargetPose(TimestampedResource):
    """
    Class for Fetchcore map poses.
    """

    # The endpoint in fetchcore for pose
    endpoint = 'tasks/paths/poses'

    def __init__(self, id=None, path=None, x=None, y=None, theta=None, created=None, modified=None, **kwargs):
        """
        :param integer id: The ID of the pose
        :param path: The path this target pose belongs to.
        :param float x: The X position of the pose (in meters) within the associated map
        :param float y: The Y position of the pose (in meters) within the associated map
        :param float theta: The angle of the pose (in radians) within the associated map
        :param created: The date and time of this pose's creation.
        :param modified: The date and time this pose was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(TargetPose, self).__init__(id=id, created=created, modified=modified, **kwargs)

        if path:
            self._set('path', path)
        self.x = x
        self.y = y
        self.theta = theta

    @property
    def path(self):
        from fetchcore.resources.tasks.paths import Path
        return Path.load(self.path_id)

    @property
    def path_id(self):
        return self._get('path')

    @property
    def x(self):
        """Gets the X position of the pose within the associated map

        :return: The X position
        """
        return self._get("x")

    @x.setter
    def x(self, value):
        """Sets the X position of the pose within the associated map

        :param value: A float
        :raises ValidationError: if value is not a number
        :raises ValidationError: if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("X position must be a finite number (value is %s)" % value)
            self._set("x", value)
        else:
            raise ValidationError("X position must be a number (value is %s)" % value)

    @property
    def y(self):
        """Gets the Y position of the pose within the associated map

        :return: The Y position
        """
        return self._get("y")

    @y.setter
    def y(self, value):
        """Sets the Y position of the pose within the associated map

        :param value: A float
        :raises ValidationError: if value is not a number
        :raises ValidationError: if value is not a finite number
        """
        if Number.is_real_number(value):
            if not Number.is_finite(value):
                raise ValidationError("Y must be a finite number (value is %s)" % value)
            self._set("y", value)
        else:
            raise ValidationError("Y must be a number (value is %s)" % value)

    @property
    def theta(self):
        """Gets the angle of the pose (in radians) within the associated map
        :return: The angle
        """
        return self._get("theta")

    @theta.setter
    def theta(self, theta):
        """Set the angle of the pose (in radians) within the associated map.
        :param float theta: The pose angle.
        :raise ValidationError: Thrown if theta is not a finite number in between 0 and pi.
        """
        if not Number.is_finite(theta):
            raise ValidationError("Theta must be a finite number (theta is %s)" % theta)
        else:
            self._set("theta", Number.bind_radians_to_pi(theta))
