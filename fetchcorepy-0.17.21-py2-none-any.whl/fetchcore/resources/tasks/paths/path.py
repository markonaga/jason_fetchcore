# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Futures
from __future__ import unicode_literals

# Standard library
from copy import deepcopy
import inspect

# Fetchcore SDK Python
from fetchcore import configuration
from fetchcore.resources import TimestampedResource
from fetchcore.resources.tasks.actions.action import Action
from fetchcore.resources.tasks.paths import TargetPose
from fetchcore.exceptions import DoesNotExist, NotFound, ValidationError, KeyWordArgumentError


class Path(TimestampedResource):
    """
    Tasks contain information about a series of target_poses that a robot can execute.
    """
    endpoint = 'tasks/paths'

    def __init__(self, id=None, action=None, target_poses=None, pose=None,
                 created=None, modified=None, **kwargs):
        """
        :param id: The ID of the path.
        :param action: The action this path is associated with.
        :param target_poses: List of target poses on this path.
        :param pose: The ID of the pose that the path ends at.
        :param created: The date and time of this task's creation.
        :param modified: The date and time this task was last modified.

        :type id: int
        :type action: int, :class:`~fetchcore.resources.tasks.actions.action.Action`
        :type target_poses: list
        :type pose: int
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Path, self).__init__(id=id, created=created, modified=modified, **kwargs)

        if action:
            self._set('action', action)
        self._target_poses = []
        for target_pose in target_poses or []:
            self.add_target_pose(target_pose)
        self.pose = pose

    @property
    def action(self):
        """Gets the associated action of the path.

        :return: The associated action.
        :rtype: :class:`~fetchcore.resources.tasks.actions.action.Action`
        """
        from fetchcore.resources import Action
        return Action.load(self.action_id)

    @action.setter
    def action(self, value):
        """Sets the associated action of the path.

        :param value: The associated action.
        :rtype: :class:`~fetchcore.resources.tasks.actions.action.Action`
        """
        from fetchcore.resources import Action
        self._set('action', value.id if isinstance(value, Action) else value)

    @property
    def action_id(self):
        """Gets the ID of the associated action of the path.

        :return: ID of the associated task.
        :rtype: int
        """
        return self._get('action')

    @property
    def target_poses(self):
        """Gets a list of TargetPose objects.

        :return: The list of TargetPose objects.
        :rtype: :class:`~__builtin__.list`
        """
        return self._target_poses

    @target_poses.setter
    def target_poses(self, value):
        """Sets a list of TargetPose objects.

        :param list value: A list of dict or TargetPose objects
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a list, or any element in the list is
        not a dict or an TargetPose object.
        """
        if not isinstance(value, list):
            raise ValidationError("Target poses must be a list")
        elif not value:
            self._target_poses = []
        else:
            original_target_poses = self._target_poses[:]
            self.target_poses = []
            try:
                for target_pose in value:
                    self.add_target_pose(target_pose)
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._target_poses = original_target_poses
                raise e

    def add_target_pose(self, target_pose, pos=None):
        """Adds a target pose to the Path.

        :param target_pose: (dict|TargetPose) The new target pose.
        :param pos: (integer|None) Position of the target pose to add to.
        :raises AttributeError: if target_pose is not implemented.
        :raises fetchcore.exceptions.ValidationError: Thrown if target_pose is not a dict, a TargetPose object, or has
            extra fields.
        """
        if pos is None:
            pos = len(self._target_poses)

        if isinstance(target_pose, TargetPose):
            # If target_pose is an Action object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._target_poses.insert(pos, target_pose)
        elif isinstance(target_pose, dict):
            # Create a deepcopy of the target_pose so as not to mess up the input
            target_pose_dict = deepcopy(target_pose)
            # Get the class for the target_pose
            try:
                # Try to create an object
                self._target_poses.insert(pos, TargetPose(**target_pose_dict))
            except TypeError:
                # TODO: This might be too complicated for this class
                # This happens when there are unexpected keyword argument
                # passed into __init__
                argspec = inspect.getargspec(TargetPose.__init__)
                # List of allowed keyword arguments
                keywords = argspec.args[-len(argspec.defaults):]
                # All the keys in target_pose
                target_pose_fields = target_pose.keys()
                extra_fields = set(target_pose_fields) - set(keywords)
                raise KeyWordArgumentError(
                    "Action has extra field %s " % ", ".join(extra_fields) +
                    "(allowed field are %s)" % ", ".join(keywords))
        else:
            raise ValidationError("Target pose should either be an TargetPose object or a "
                                  "dict, not a %s" % type(target_pose).__name__)

    # TODO: Fix this?
    def pop_target_pose(self, pos=None):
        """Removes an target_pose at a position or the last target_pose if position is not given.

        :param pos: The position of the target_pose to pop out.
        :type pos: int, None
        :return: The target_pose that was removed.
        :rtype: :class:`~fetchcore.resources.tasks.actions.action.Action`
        :raises IndexError: Thrown if you attempt to pop an target_pose that from an index that doesn't exist.
        """
        if pos is None:
            pos = len(self._target_poses) - 1
        try:
            return self._target_poses.pop(pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop target_pose %d but there are only %d target_poses"
                % (pos, len(self._target_poses)))

    @property
    def pose(self):
        return self._get('pose')

    @pose.setter
    def pose(self, pose):
        if pose is not None and not isinstance(pose, int):
            raise ValidationError("Pose id of a path must be a positive integer.")
        self._set('pose', pose)

    def to_json_dict(self):
        """Gets the resource with target_pose document as a json dictionary.

        :return: The JSON dictionary
        :rtype: dict
        """
        # Get json dict from each target_pose
        target_pose_json = [target_pose.to_json_dict() for target_pose in self._target_poses]
        self._set("target_poses", target_pose_json)
        return super(Path, self).to_json_dict()

    @classmethod
    def load_from_action(cls, action_id, client=None):
        """Load a path from the fetchcore server linked to the given action ID.

        :param action_id: The unique identifier of the resource.
        :param client: The client that should be used (if None, the global fetchcore client is used).
        :return: The loaded resource from the server.
        :raise fetchcore.exceptions.ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise fetchcore.exceptions.DoesNotExist: Thrown if the resource does not exist with that identifier.
        :raise fetchcore.exceptions.InternalServerError: Thrown if the server responds with an error.
        """
        # Check if we are using the global client
        if client is None:
            client = configuration.__GLOBAL_CLIENT__
        cls._Resource__validate_client(client)

        try:
            response = client.get(Action.endpoint, "%s/path" % action_id)
            return cls.set_response(response)
        # TODO: add exceptions and such for unauthed states when we add in more permissions
        except NotFound:
            raise DoesNotExist("Path for action '%s' does not exist on the server." % str(action_id))
