# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.utils import Timestamp
from fetchcore.exceptions import ValidationError, UnsupportedOperation
from fetchcore.resources.tasks.actions.responses.definitions import RESPONSE_CLASSES
from fetchcore.resources.tasks.actions.responses.response import Response


class Action(BaseAction):
    """
    Class for fetchcore actions.
    """
    # Read only fields for action
    read_only_fields = ('task',)

    # Required fields for input values
    required_fields = []
    # Optional fields for input values
    optional_fields = []

    endpoint = 'tasks/actions'

    # Set fields for response mixin
    response_class = Response
    response_classes = RESPONSE_CLASSES

    def __init__(
            self, id=None, action_definition=None, preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, outputs=None, inputs=None, states=None, on_complete=None,
            on_pause=None, on_resume=None, created=None, modified=None, **kwargs):
        """
        :param id: The ID of the action.
        :param str action_definition: The action definition associated with this action.
        :param str preemptable: The preemption level of this action.
        :param int task: ID of the associated task.
        :param str status: The current status of the action.
        :param start: The timestamp indicating when the action started execution (optional).
        :param end: The timestamp stating when the action entered a terminal state (optional).
        :param dict outputs: The output values for the action.
        :param dict states: The survey values for the action.
        :param created: The date and time of this actions's creation.
        :param modified: The date and time this action was last modified.
        :type start: str, ~datetime.datetime
        :type end: str, ~datetime.datetime
        :param on_complete: (list) The on complete responses associated with this action.
        :param on_pause: (list) The on pause responses associated with this action.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Action, self).__init__(id=id, action_definition=action_definition, inputs=inputs, preemptable=preemptable,
                                     created=created, modified=modified, on_complete=on_complete, on_pause=on_pause,
                                     on_resume=on_resume, **kwargs)

        if task:
            self._set('task', task)
        self.status = status
        if start:
            self.start = start
        if end:
            self.end = end
        self.outputs = outputs if outputs is not None else {}
        self.states = states if states is not None else {}

    def delete(self, _=None):
        """
        Overwrites base class delete. Actions cannot be deleted on the server.
        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation("Actions cannot be deleted on the server.")

    @staticmethod
    def get_action_class(action_definition):
        """Gets the class of action of an action definition.

        :param str action_definition: Name of an action definition.
        :return: Class for the action in action definition (defaults to Action if it is not a known action).
        :rtype: class
        """
        try:
            from fetchcore.resources.tasks.actions.definitions import ACTION_CLASSES
            return ACTION_CLASSES[action_definition]
        except KeyError:
            return Action

    @staticmethod
    def make_from_template(action_template):
        """
        Converts templates to actions.

        :param action_template (ActionTemplate): The template to convert into an action.
        """
        action_cls = Action.get_action_class(action_template.action_definition_name)

        on_complete = []
        for response_template in action_template.on_complete:
            on_complete.append(Response.make_from_template(response_template))

        on_pause = []
        for response_template in action_template.on_pause:
            on_pause.append(Response.make_from_template(response_template))

        on_resume = []
        for response_template in action_template.on_resume:
            on_resume.append(Response.make_from_template(response_template))

        if action_cls == Action:
            return Action(action_definition=action_template.action_definition_name,
                          preemptable=action_template.preemptable,
                          inputs=action_template.inputs, status=ActionStatus.NEW,
                          on_complete=on_complete, on_pause=on_pause, on_resume=on_resume)
        else:
            return action_cls(preemptable=action_template.preemptable,
                              inputs=action_template.inputs, status=ActionStatus.NEW,
                              on_complete=on_complete, on_pause=on_pause, on_resume=on_resume)

    @classmethod
    def set_response(cls, response):
        """Loads data from the server to Action and any of its derived classes

        :param response: The data that has been received from the server
        :return: The loaded data
        """
        if cls == Action:
            # Action is a base class so we shouldn't be using it
            # Get the right derived class
            return_cls = Action.get_action_class(response['action_definition'])
        else:
            # The derived class called this function
            return_cls = cls
        try:
            return return_cls(**response)
        except TypeError:
            return None

    @property
    def task(self):
        """Gets the associated task of the action.

        :return: The associated task.
        :rtype: fetchcore.resources.Task
        """
        from fetchcore.resources import Task
        return Task.load(self.task_id)

    @property
    def task_id(self):
        """Gets the ID of the associated task of the action.

        :return: ID of the associated task.
        :rtype: int
        """
        return self._get('task')

    @property
    def status(self):
        """Gets the status of the action

        :return: The action status
        :rtype: str
        """
        return self._get("status")

    @status.setter
    def status(self, status):
        """Sets the status of the action

        :param str status: An action status
        :raises fetchcore.exceptions.ValidationError: Thrown if status is not in the list of action statuses
        """
        if status in ActionStatus.values():
            self._set("status", status)
        else:
            raise ValidationError(
                "%s is not an allowed action status (%s)" % (status, ", ".join(ActionStatus.values())))

    @property
    def start(self):
        """Gets the timestamp that indicates when the action started execution

        :return: The start timestamp
        :rtype: ~datetime.datetime
        """
        return self._get("start")

    @start.setter
    def start(self, start):
        """Sets the timestamp that indicates when the action started execution

        :param str, ~datetime.datetime start: A timestamp
        """
        if start is None:
            self._set("start", start)
        else:
            try:
                self._set("start", Timestamp.to_datetime(start))
            except (TypeError, ValueError) as e:
                raise ValidationError(e)

    @property
    def end(self):
        """Gets the timestamp that indicates when the action stopped execution

        :return: The end timestamp
        :rtype: ~datetime.datetime
        """
        return self._get("end")

    @end.setter
    def end(self, end):
        """Sets the timestamp that indicates when the action stopped execution

        :param str, ~datetime.datetime end: A timestamp
        """
        if end is None:
            self._set("end", end)
        else:
            try:
                self._set("end", Timestamp.to_datetime(end))
            except (TypeError, ValueError) as e:
                raise ValidationError(e)

    @property
    def outputs(self):
        """Gets the output values for the action if they exist-otherwise an empty dictionary is returned

        :return: Action outputs
        :rtype: dict
        """
        if self.is_set("outputs"):
            return self._get("outputs")
        else:
            return {}

    @outputs.setter
    def outputs(self, outputs):
        """Sets the output values for the action

        :param dict outputs: Output parameters
        :raises fetchcore.exceptions.ValidationError: Thrown if values is not a dict
        """
        if outputs is None:
            self._set("outputs", {})
        elif isinstance(outputs, dict):
            self._set("outputs", outputs)
        else:
            raise ValidationError("Outputs must be a dict or None but %s is a %s" % (outputs, type(outputs).__name__))

    @property
    def states(self):
        """Gets the survey values for the action if they exist-otherwise an empty dictionary is returned

        :return: Action states
        :rtype: dict
        """
        if self.is_set("states"):
            return self._get("states")
        else:
            return {}

    @states.setter
    def states(self, states):
        """Sets the survey values for the action

        :param dict states: Output parameters
        :raises fetchcore.exceptions.ValidationError: Thrown if values is not a dict
        """
        if states is None:
            self._set("states", {})
        elif isinstance(states, dict):
            self._set("states", states)
        else:
            raise ValidationError("States must be a dict or None but %s is a %s" % (states, type(states).__name__))

    def to_json_dict(self):
        """Gets the copy of the JSON document

        :return: the JSON document
        :rtype: dict
        """
        self.check_input_fields()
        return super(Action, self).to_json_dict()
