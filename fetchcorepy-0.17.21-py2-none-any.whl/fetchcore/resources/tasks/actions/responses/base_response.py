# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua

# Future
from __future__ import unicode_literals

# Fetchcore
from fetchcore.exceptions import ValidationError
from fetchcore.resources import TimestampedResource

# Responses
from .response_definition import ResponseDefinition


class Condition(object):
    """
    Conditions state what the required value of an output field of an action should be for its response to be evaluated.
    """
    def __init__(self, output_field=None, output_value=None):
        """
        :param str output_field: Name of output field.
        :type output_field: str, None
        :param object output_value: The required value of the output field.
        """
        self.__output_field = None
        self.__output_value = None
        self.output_field = output_field
        self.output_value = output_value

    @property
    def output_field(self):
        """Returns the name of action output field to evaluate.

        :return: The name of action output field to evaluate.
        :rtype: str
        """
        return self.__output_field

    @output_field.setter
    def output_field(self, output_field):
        """Sets the name of action output field to evaluate.

        :param output_field: The name of action output field to evaluate.
        :type output_field: str, None
        :raise fetchcore.exceptions.ValidationError: Thrown if output_field is not a string or None
        """
        if output_field is None or isinstance(output_field, basestring):
            self.__output_field = output_field
        else:
            raise ValidationError('Output field should be a string, not a ' + type(output_field).__name__)

    @property
    def output_value(self):
        """Returns the required value of the specified output field.

        :return: The required value of the specified output field.
        """
        return self.__output_value

    @output_value.setter
    def output_value(self, output_value):
        """Sets the required value of the specified output field.

        :param object output_value: The required value of the specified output field.
        """
        self.__output_value = output_value

    def to_json_dict(self):
        """Returns the condition's content in a dict.

        :return: The content of the condition.
        :rtype: dict
        """
        return {'output_field': self.output_field, 'output_value': self.output_value}

    def __eq__(self, other):
        return self.output_field == other.output_field and self.output_value == other.output_value


class BaseResponse(TimestampedResource):
    """
    BaseResponse is the base class for Response and ResponseTemplate.
    """

    required_fields = []

    def __init__(self, id=None, response_definition=None, inputs=None, condition=None,
                 created=None, modified=None, **kwargs):
        """

        :param int id: The resource ID of the response.
        :param str response_definition: Name of the associated response definition.
        :param inputs: Input parameters of the response.
        :param condition: Condition to evaluate before this response can be executed.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type inputs: dict, None
        :type condition: dict, Condition, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(BaseResponse, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.response_definition = response_definition
        self.inputs = inputs
        self.__condition = None
        self.condition = condition

    @property
    def response_definition_name(self):
        """

        :return: Name of the associated response definition.
        :rtype: dict, None
        """
        return self._get('response_definition')

    @property
    def response_definition(self):
        """

        :return: Name of the associated response definition.
        :rtype: dict, None
        """
        return ResponseDefinition.load(self._get('response_definition'))

    @response_definition_name.setter
    def response_definition_name(self, response_definition_name):
        """

        :param str response_definition: Name of the associated response definition.
        :raise fetchcore.exceptions.ValidationError: Thrown if response_definition is not a string.
        """
        if not isinstance(response_definition_name, basestring):
            raise ValidationError('Response definition name must be a string, not a %s'
                                  % type(response_definition_name).__name__)
        self._set('response_definition', response_definition_name)

    @response_definition.setter
    def response_definition(self, response_definition):
        """

        :param str response_definition: Name of the associated response definition.
        :raise fetchcore.exceptions.ValidationError: Thrown if response_definition is not a string.
        """
        if isinstance(response_definition, basestring):
            self._set('response_definition', response_definition)
        elif isinstance(response_definition, ResponseDefinition):
            self._set('response_definition', response_definition.name)
        else:
            raise ValidationError('Response definition must be a string, not a %s' % type(response_definition).__name__)

    @property
    def inputs(self):
        """

        :return: Input parameters of the response.
        :rtype: dict, None
        """
        return self._get('inputs')

    @inputs.setter
    def inputs(self, inputs):
        """

        :param inputs: Input parameters of the response.
        :type inputs: dict, None
        """
        if isinstance(inputs, dict):
            for field in self.required_fields:
                if field not in inputs:
                    raise ValidationError('Required field %s is missing in the inputs.' % field)
            self._set('inputs', inputs)
        elif inputs is None:
            if self.required_fields:
                raise ValidationError('Inputs cannot be empty for %s. Required fields are %s.'
                                      % (self.__class__.__name__, ', '.join(self.required_fields)))
            self._set('inputs', {})
        else:
            raise ValidationError('Inputs must be None or a dict, not a %s.' % type(inputs).__name__)

    def get_input(self, field):
        """Gets the value of an input field.

        :param field: Name of the field.
        :return: Value of the specified input field.
        """
        try:
            return self.inputs[field]
        except KeyError:
            raise KeyError('%s field does not exist in the inputs.' % field)

    def set_input(self, field, value):
        """Sets the value of an input field

        :param field: Name of the field.
        :param value: New value of the field.
        """
        if not self.is_set('inputs'):
            self._set('inputs', {})
        self.inputs[field] = value

    @property
    def condition(self):
        """

        :return: Condition to evaluate before this response can be executed.
        :rtype: Condition, None
        """
        return self.__condition

    @condition.setter
    def condition(self, condition):
        """

        :param condition: Condition to evaluate before this response can be executed.
        :type condition: dict, Condition, None
        :raise fetchcore.exceptions.ValidationError: Thrown if condition does not have the correct type, or has
               unexpected fields if it is a dict.
        """
        if condition is None:
            self.__condition = None
        elif isinstance(condition, dict):
            self._set('condition', condition)
            try:
                self.__condition = Condition(**condition)
            except TypeError as e:
                raise ValidationError('Error when setting condition, ' + str(e))
        elif isinstance(condition, Condition):
            self._set('condition', condition.to_json_dict())
            self.__condition = condition
        else:
            raise ValidationError('Condition can only be None, dict or Condition, not a ' + type(condition).__name__)
