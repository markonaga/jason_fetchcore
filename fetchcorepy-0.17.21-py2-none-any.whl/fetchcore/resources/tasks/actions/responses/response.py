# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua

# Future
from __future__ import unicode_literals

# Standard library
from copy import deepcopy

# Fetchcore
from fetchcore.definitions import ResponseStatus
from fetchcore.exceptions import UnsupportedOperation, ValidationError
from .base_response import BaseResponse


class Response(BaseResponse):
    endpoint = 'tasks/actions/responses'

    @staticmethod
    def get_response_class(response_definition):
        """Gets the class of response template by its response definition.

        :param response_definition: (string) Name of an response definition.
        :return: Class for the response template in response definition (defaults to ResponseTemplate if not known).
        :rtype: Response template class
        """
        try:
            from fetchcore.resources.tasks.actions.responses.definitions import RESPONSE_CLASSES
            return RESPONSE_CLASSES[response_definition]
        except KeyError:
            return Response

    @staticmethod
    def make_from_template(response_template):
        """
        Converts templates to responses.

        :param response_template (ResponseTemplate): The template to convert into a response.
        """
        response_cls = Response.get_response_class(response_template.response_definition_name)
        if response_cls == Response:
            return Response(response_definition=response_template.response_definition_name,
                            inputs=response_template.inputs, status=ResponseStatus.NEW,
                            condition=response_template.condition)
        else:
            return response_cls(inputs=response_template.inputs, status=ResponseStatus.NEW,
                                condition=response_template.condition)

    def __init__(self, id=None, response_definition=None, inputs=None, condition=None, status=None, outputs=None,
                 created=None, modified=None, **kwargs):
        """

        :param int id: The resource ID of the response.
        :param str response_definition: Name of the associated response definition.
        :param inputs: Input parameters of the response.
        :param condition: Condition to evaluate before this response can be executed.
        :param str status: Status of this response.
        :param dict outputs: Output values of this response.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type inputs: dict, None
        :type condition: dict, .base_response.Condition, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Response, self).__init__(id=id, response_definition=response_definition, inputs=inputs,
                                       condition=condition, created=created, modified=modified, **kwargs)
        self.status = status
        self.outputs = outputs

    @property
    def status(self):
        """

        :return: Status of this response.
        :rtype: str
        """
        return self._get('status')

    @status.setter
    def status(self, status):
        """

        :param status: Status of this response.
        :raise fetchcore.exceptions.ValidationError: Thrown if status is one of the allowed statuses.
        """
        if not isinstance(status, basestring) or status not in ResponseStatus.values():
            raise ValidationError('%s is not an allowed response status (%s).'
                                  % (status, ','.join(ResponseStatus.values())))
        self._set('status', status)

    @property
    def outputs(self):
        """

        :return: Output values of this response.
        :rtype: dict
        """
        return self._get('outputs')

    @outputs.setter
    def outputs(self, outputs):
        """

        :param outputs: Output values of this response.
        :type outputs: dict, None
        :raise fetchcore.exceptions.ValidationError: Thrown if outputs is not a dict or None.
        """
        if outputs is None:
            self._set('outputs', {})
        elif isinstance(outputs, dict):
            self._set('outputs', outputs)
        else:
            raise ValidationError('Outputs must be None or dict, not a ' + type(outputs).__name__)

    def get_output(self, field):
        """Gets the value of an output field.

        :param field: Name of the field.
        :return: Value of the specified output field.
        """
        try:
            return self.outputs[field]
        except KeyError:
            raise KeyError('%s field does not exist in the outputs.' % field)

    def set_output(self, field, value):
        """Sets the value of an output field

        :param field: Name of the field.
        :param value: New value of the field.
        """
        if not self.is_set('outputs'):
            self._set('outputs', {})
        self.outputs[field] = value

    def save(self, client=None):
        """Overwrites base class save. Response cannot be saved on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Saving responses is unsupported by Fetchcore.')

    def update(self, client=None):
        """Overwrites base class save. Response cannot be updated on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Updating responses is unsupported by Fetchcore.')

    def delete(self, client=None):
        """Overwrites base class save. Response cannot be deleted on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Deleting responses is unsupported by Fetchcore.')

    @classmethod
    def set_response(cls, response):
        if 'response_definition' not in response:
            raise ValidationError('Response definition is required to create a response object.')
        response_definition = response.get('response_definition')
        from .definitions import RESPONSE_CLASSES
        if response_definition in RESPONSE_CLASSES:
            response_copy = deepcopy(response)
            response_copy.pop('response_definition')
            return RESPONSE_CLASSES[response_definition](**response_copy)
        else:
            return Response(**response)
