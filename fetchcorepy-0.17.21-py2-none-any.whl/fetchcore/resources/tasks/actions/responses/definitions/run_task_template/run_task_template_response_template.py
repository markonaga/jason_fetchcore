# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Future
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.resources import ResponseTemplate

# run_task_template
from .base_run_task_template import BaseRunTaskTemplate


class RunTaskTemplateResponseTemplate(BaseRunTaskTemplate, ResponseTemplate):
    """
    Fetchcore response template to run a task template as a subtask.
    """

    def __init__(
            self, id=None, condition=None, task_template_id_input=None, cascade_status_input=None, inputs=None,
            created=None, modified=None, **kwargs
    ):
        """

        :param int id: The resource ID of the response.
        :param inputs: Input parameters of the response.
        :param condition: Condition to evaluate before this response can be executed.
        :param int task_template_id_input: The ID of the task template to run.
        :param bool cascade_status_input: Whether to propagate the response's status to the action.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type inputs: dict, None
        :type condition: dict, .base_response.Condition, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(RunTaskTemplateResponseTemplate, self).__init__(
            id=id, condition=condition, inputs=inputs, task_template_id_input=task_template_id_input,
            cascade_status_input=cascade_status_input,
            created=created, modified=modified, **kwargs
        )
