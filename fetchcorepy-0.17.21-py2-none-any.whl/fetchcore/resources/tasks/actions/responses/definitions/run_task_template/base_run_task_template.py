# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua

# Future
from __future__ import unicode_literals

# Fetchcore
from fetchcore.exceptions import ValidationError
from ...base_response import BaseResponse
from fetchcore.utils import Number


class BaseRunTaskTemplate(BaseResponse):
    """
    Base class for RUN_TASK_TEMPLATE response and response template.
    """
    required_fields = ['task_template_id', 'cascade_status']

    def __init__(self, id=None, inputs=None, condition=None, task_template_id_input=None,
                 cascade_status_input=None, created=None, modified=None, **kwargs):
        """

        :param int id: The resource ID of the response.
        :param inputs: Input parameters of the response.
        :param condition: Condition to evaluate before this response can be executed.
        :param int task_template_id_input: The ID of the task template to run.
        :param bool cascade_status_input: Whether to propagate the response's status to the action.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type inputs: dict, None
        :type condition: dict, .base_response.Condition, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        if inputs is None:
            using_inputs = {
                'task_template_id': task_template_id_input,
                'cascade_status': cascade_status_input,
            }
        else:
            using_inputs = inputs
        super(BaseRunTaskTemplate, self).__init__(id=id, response_definition='RUN_TASK_TEMPLATE', inputs=using_inputs,
                                                  condition=condition, created=created, modified=modified, **kwargs)
        # TODO: override response_definition setter so that modifying response definition is not allowed

    @property
    def task_template_id_input(self):
        """Gets the ID of the task template to run.

        :return: Task template ID
        """
        return self.get_input('task_template_id')

    @task_template_id_input.setter
    def task_template_id_input(self, value):
        """Sets the ID of the task template to run.

        :param value: (integer) Task template ID
        :raises ValidationError if value is not an integer
        :raises ValidationError if value not a positive finite integer
        """
        if Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError('Task template ID must be a finite positive number (value is %s)' % value)
            self.set_input('task_template_id', value)
        else:
            raise ValidationError('Task template ID must be a number (value %s is %s)' % (value, type(value).__name__))

    @property
    def cascade_status_input(self):
        """Gets whether the response's status should be propagated to the action that spawned it.

        :return: Whether to propagate the response's status to the action.
        """
        return self.get_input('cascade_status')

    @cascade_status_input.setter
    def cascade_status_input(self, cascade_status):
        """Sets whether the response's status should be propagated to the action that spawned it.

        :param cascade_status: (bool) Whether to propagate the response's status to the action.
        :raises: ValidationError if cascade_status is not a bool
        """
        if not isinstance(cascade_status, bool):
            raise ValidationError('Cascade status must be a bool')
        else:
            self.set_input('cascade_status', cascade_status)
