from .run_task_template import RunTaskTemplateResponse, RunTaskTemplateResponseTemplate  # NOQA

# TODO: can this be smarter/cleaner?
RESPONSE_CLASSES = {
    'RUN_TASK_TEMPLATE': RunTaskTemplateResponse,
}

RESPONSE_TEMPLATE_CLASSES = {
    'RUN_TASK_TEMPLATE': RunTaskTemplateResponseTemplate,
}
