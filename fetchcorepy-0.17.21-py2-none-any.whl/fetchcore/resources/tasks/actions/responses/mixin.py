# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua, Michael Hwang

# Standard Library
import inspect
from copy import deepcopy

# Fetch
from fetchcore.exceptions import ValidationError, KeyWordArgumentError
from .response import Response
from .definitions import RESPONSE_CLASSES


class ResponseMixin(object):
    """Mixin for adding response-related tracking fields to a Resource.

    Requires the following fields to be initialized to work properly:
    * _on_complete
    * _on_resume
    * _on_pause

    Optional fields to change the behavior:
    * response_types
    * response_class
    """

    response_types = ('on_complete', 'on_pause', 'on_resume')
    response_class = Response
    response_classes = RESPONSE_CLASSES

    def to_json_dict(self):
        # Get json dict from each response
        for response_type in self.response_types:
            self._set(response_type, [response.to_json_dict() for response in getattr(self, response_type)])
        return super(ResponseMixin, self).to_json_dict()

    @property
    def on_complete(self):
        """Gets the list of responses to execute when the action is complete.

        :return: (list) A list of Response objects.
        """
        return self._on_complete

    @on_complete.setter
    def on_complete(self, value):
        """Sets the list of responses to execute when the action is complete.

        :param value: (list) A list of dict or Response objects.
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a list, or any element in the list is
            not a dict or a Response object.
        """
        if not isinstance(value, list):
            raise ValidationError("On complete responses must be a list")
        elif not value:
            self._on_complete = value
        else:
            original_on_complete = self._on_complete[:]
            self._on_complete = []
            try:
                for on_complete_response in value:
                    self.add_on_complete_response(on_complete_response)
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._on_complete = original_on_complete
                raise e

    @property
    def on_pause(self):
        """Gets the list of responses to execute when the action is paused.

        :return: (list) A list of Response objects.
        """
        return self._on_pause

    @on_pause.setter
    def on_pause(self, value):
        """Sets the list of responses to execute when the action is paused.

        :param value: (list) A list of dict or Response objects.
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a list, or any element in the list is
            not a dict or a Response object.
        """
        if not isinstance(value, list):
            raise ValidationError("On pause responses must be a list")
        elif not value:
            self._on_pause = value
        else:
            original_on_pause = self._on_pause[:]
            self._on_pause = []
            try:
                for on_pause_response in value:
                    self.add_on_pause_response(on_pause_response)
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._on_pause = original_on_pause
                raise e

    @property
    def on_resume(self):
        """Gets the list of responses to execute when the action is resumed.

        :return: (list) A list of Response objects.
        """
        return self._on_resume

    @on_resume.setter
    def on_resume(self, value):
        """Sets the list of responses to execute when the action is resumed.

        :param value: (list) A list of dict or Response objects.
        :raises fetchcore.exceptions.ValidationError: Thrown if value is not a list, or any element in the list is
            not a dict or a Response object.
        """
        if not isinstance(value, list):
            raise ValidationError("On resume responses must be a list")
        elif not value:
            self._on_resume = value
        else:
            original_on_resume = self._on_resume[:]
            self._on_resume = []
            try:
                for on_resume_response in value:
                    self.add_on_resume_response(on_resume_response)
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._on_resume = original_on_resume
                raise e

    def __add_response(self, response, responses_list, pos=None):
        """Add a response to one list of the action's responses.

        :param response: A new response to insert.
        :param list responses_list: The list to insert the new response to.
        :param int pos: Position of the new response to add to.
        :type response: dict, Response
        :raise ValidationError: Thrown if response is not a dict, an Response object, derived from Response, or has
            extra fields.
        """
        if pos is None:
            pos = len(responses_list)
        if isinstance(response, self.response_class):
            # If response is an Response object, the user should have gone through all the trouble to set attributes so
            # no need to do any checking
            responses_list.insert(pos, response)
        elif isinstance(response, dict):
            # Create a deepcopy of the response so as not to mess up the input
            response_dict = deepcopy(response)

            try:
                # Get response definition
                response_name = response_dict.get('response_definition')
            except KeyError:
                raise ValidationError('Response does not have a response definition.')

            try:
                # Try create an object
                responses_list.insert(pos, self.response_class.set_response(response_dict))
            except TypeError:
                # This happens when there are unexpected keyword argument passed into __init__
                response_class = self.response_classes.get(response_name, self.response_class)
                argspec = inspect.getargspec(response_class.__init__)
                # List of allowed keyword arguments
                keywords = argspec.args[-len(argspec.defaults):]
                # All the keys in on_complete_response
                response_fields = response_dict.keys()
                extra_fields = set(response_fields) - set(keywords)
                raise KeyWordArgumentError(
                    "%s has extra field(s) %s " % (self.response_class.__name__, ", ".join(extra_fields)) +
                    "(allowed field are %s)" % ", ".join(keywords))
        else:
            raise ValidationError("Response should either be an OnCompleteResponse object or a dict, not a %s"
                                  % type(response).__name__)

    def __pop_response(self, responses_list, pos=None):
        """Pops a response from a list of responses.

        :param responses_list: A list of responses.
        :param pos: (integer|None) The position of the on complete response to pop out.
        :return: The response that was removed.
        """
        if pos is None:
            pos = len(responses_list) - 1
        return responses_list.pop(pos)

    def add_on_complete_response(self, on_complete_response, pos=None):
        """Adds an on complete response to the Action.

        :param on_complete_response: (dict|OnCompleteResponse) The new on complete response.
        :param pos: (integer|None) Position of the on complete response to add to.
        :raises ValidationError: Thrown if on_complete_response is not a dict, a Response object, derived
            from OnCompleteResponse, or has extra fields.
        """
        self.__add_response(on_complete_response, self._on_complete, pos=pos)

    def add_on_pause_response(self, on_pause_response, pos=None):
        """Adds an on pause response to the Action.

        :param on_pause_response: (dict|OnCompleteResponse) The new on pause response.
        :param pos: (integer|None) Position of the on pause response to add to.
        :raises ValidationError: Thrown if on_pause_response is not a dict, a Response object, derived
            from OnCompleteResponse, or has extra fields.
        """
        self.__add_response(on_pause_response, self._on_pause, pos=pos)

    def add_on_resume_response(self, on_resume_response, pos=None):
        """Adds an on resume response to the Action.

        :param on_resume_response: (dict|OnCompleteResponse) The new on resume response.
        :param pos: (integer|None) Position of the on resume response to add to.
        :raises ValidationError: Thrown if on_resume_response is not a dict, a Response object, derived
            from OnCompleteResponse, or has extra fields.
        """
        self.__add_response(on_resume_response, self._on_resume, pos=pos)

    def pop_on_complete_response(self, pos=None):
        """Removes an on complete response at a position or the last on complete response if position is not given.

        :param pos: (integer|None) The position of the on complete response to pop out.
        :return: (Response) The on complete response that was removed.
        :raises IndexError: Thrown if you attempt to pop an on complete response that from an index that doesn't exist.
        """
        try:
            return self.__pop_response(self._on_complete, pos=pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop on complete response %d but there are only %d on complete responses"
                % (pos, len(self._on_complete)))

    def pop_on_pause_response(self, pos=None):
        """Removes an on pause response at a position or the last on pause response if position is not given.

        :param pos: (integer|None) The position of the on pause response to pop out.
        :return: (Response) The on pause response that was removed.
        :raises IndexError: Thrown if you attempt to pop an on pause response that from an index that doesn't exist.
        """
        try:
            return self.__pop_response(self._on_pause, pos=pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop on pause response %d but there are only %d on pause responses"
                % (pos, len(self._on_pause)))

    def pop_on_resume_response(self, pos=None):
        """Removes an on resume response at a position or the last on resume response if position is not given.

        :param pos: (integer|None) The position of the on resume response to pop out.
        :return: (Response) The on resume response that was removed.
        :raises IndexError: Thrown if you attempt to pop an on resume response that from an index that doesn't exist.
        """
        try:
            return self.__pop_response(self._on_resume, pos=pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop on resume response %d but there are only %d on resume responses"
                % (pos, len(self._on_resume)))
