# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard library
import re

# Fetchcore
from fetchcore.resources import TimestampedResource
from fetchcore.definitions import REGEX_CAPITAL_UNDERSCORE
from fetchcore.exceptions import ValidationError


class ResponseDefinition(TimestampedResource):
    """
    Response definitions contain information necessary for defining responses to actions.
    """
    endpoint = 'tasks/actions/responses/definitions'
    pk = 'name'

    def __init__(self, id=None, name="", description=None, input_fields=None, output_fields=None, created=None,
                 modified=None, **kwargs):
        """
        :param int id: The resource ID of the response.
        :param str name: The unique name of this response definition type.
        :param str description: A description of this response.
        :param dict input_fields: Required fields for the response.
        :param dict output_fields: Return fields for the response.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(ResponseDefinition, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name
        self.description = description
        if input_fields is not None:
            self.input_fields = input_fields
        if output_fields is not None:
            self.output_fields = output_fields

    @property
    def name(self):
        """Returns the unique name of this response definition type.

        :return: The name of this response definition type.
        :rtype: str
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Sets the unique name of this response definition type.

        :param str name: Name of the response definition type.
        :raise fetchcore.exceptions.ValidationError: Thrown if name is not a string or an empty string.
        """
        try:
            if re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), name):
                self._set('name', name)
            else:
                raise ValidationError('Response name should be comprised of only capital letters and underscores.')
        except TypeError:
            raise ValidationError('Response name must be a string.')

    @property
    def description(self):
        """Returns the description for this response.

        :return: The description of this response.
        :rtype: str
        """
        return self._get("description")

    @description.setter
    def description(self, description):
        """Sets the description for the response.

        :param str description: description of the response.
        :raise fetchcore.exceptions.ValidationError: Thrown if description is not a string or an empty string.
        """
        if isinstance(description, basestring):
            self._set('description', description)
        else:
            raise ValidationError('Response description must be a string.')

    @property
    def input_fields(self):
        """Gets the input fields for this response.

        :return: The input fields.
        :rtype: dict
        """
        return self._get("input_fields")

    @input_fields.setter
    def input_fields(self, fields):
        """Sets the input fields for this response.

        :param dict fields: The input fields.
        :raise fetchcore.exceptions.ValidationError: Thrown if fields is not an array.
        """
        if not isinstance(fields, dict):
            raise ValidationError("Input fields must be a dict.")
        else:
            self._set("input_fields", fields)

    @property
    def output_fields(self):
        """Gets the return fields for this response.

        :return: The return fields.
        :rtype: dict
        """
        return self._get("output_fields")

    @output_fields.setter
    def output_fields(self, fields):
        """Sets the return fields for this response.

        :param dict fields: The return fields.
        :raise fetchcore.exceptions.ValidationError: Thrown if fields is not a dict.
        """
        if not isinstance(fields, dict):
            raise ValidationError("Return fields must be a dictionary")
        else:
            self._set("output_fields", fields)
