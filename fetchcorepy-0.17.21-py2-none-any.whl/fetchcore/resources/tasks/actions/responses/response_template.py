# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua

# Future
from __future__ import unicode_literals

# Standard library
from copy import deepcopy

# Fetchcore
from fetchcore.exceptions import ValidationError, UnsupportedOperation
from .base_response import BaseResponse


class ResponseTemplate(BaseResponse):
    endpoint = 'tasks/templates/actions/responses'

    def __init__(self, id=None, response_definition=None, inputs=None, condition=None,
                 created=None, modified=None, **kwargs):
        """

        :param int id: The resource ID of the response.
        :param str response_definition: Name of the associated response definition.
        :param inputs: Input parameters of the response.
        :param condition: Condition to evaluate before this response can be executed.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type inputs: dict, None
        :type condition: dict, Condition, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(ResponseTemplate, self).__init__(id=id, response_definition=response_definition, inputs=inputs,
                                               condition=condition, created=created, modified=modified, **kwargs)

    @classmethod
    def set_response(cls, response):
        if 'response_definition' not in response:
            raise ValidationError('Response definition is required to create a response object.')
        response_definition = response.get('response_definition')
        from .definitions import RESPONSE_TEMPLATE_CLASSES
        if response_definition in RESPONSE_TEMPLATE_CLASSES:
            response_copy = deepcopy(response)
            response_copy.pop('response_definition')
            return RESPONSE_TEMPLATE_CLASSES[response_definition](**response_copy)
        else:
            return ResponseTemplate(**response)

    def save(self, client=None):
        """Overwrites base class save. Response template cannot be saved on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Saving responses is unsupported by Fetchcore.')

    def update(self, client=None):
        """Overwrites base class save. Response template cannot be updated on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Updating responses is unsupported by Fetchcore.')

    def delete(self, client=None):
        """Overwrites base class save. Response template cannot be deleted on the server.

        :param client: The HTTP client that should be used.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Deleting responses is unsupported by Fetchcore.')
