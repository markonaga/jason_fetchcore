# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Standard library
import re
import datetime

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption, REGEX_CAPITAL_UNDERSCORE
from fetchcore.resources import TimestampedResource, ActionDefinition
from fetchcore.resources.tasks.actions.responses.mixin import ResponseMixin
from fetchcore.exceptions import ValidationError, UndefinedFieldError
from fetchcore.utils import Timestamp, Duration


class BaseAction(ResponseMixin, TimestampedResource):
    """
    The base class for actions and action templates.
    """
    # Required fields for input values
    required_fields = []
    # Optional fields for input values
    optional_fields = []

    def __init__(self, id=None, action_definition=None, inputs=None, preemptable=None, created=None, modified=None,
                 on_complete=None, on_pause=None, on_resume=None, **kwargs):
        """
        :param id: The ID of the action template.
        :param action_definition: The action definition associated with this action template.
        :param dict inputs: The input values for the action.
        :param preemptable: The preemption level of this action template.
        :param on_complete: The on complete responses associated with this action template.
        :param on_pause: The on pause responses associated with this action template.
        :param on_resume: The on resume responses associated with this action template.
        :param created: The date and time of this action templates's creation.
        :param modified: The date and time this action template was last modified.
        """
        super(BaseAction, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.action_definition = action_definition
        self.preemptable = preemptable
        if inputs:
            self.inputs = inputs
        self._on_complete = []
        self.on_complete = on_complete or []
        self._on_pause = []
        self.on_pause = on_pause or []
        self._on_resume = []
        self.on_resume = on_resume or []

    @property
    def action_definition(self):
        """Get the action definition as an ActionDefinition object.

        :return: An ActionDefinitionObject.
        """
        return ActionDefinition.load(self.action_definition_name)

    @property
    def action_definition_name(self):
        """Gets the action definition that this action object is associated with.

        :return: The associated action definition name.
        """
        return self._get("action_definition")

    @action_definition.setter
    def action_definition(self, value):
        """Sets the action definition that this action object is associated with.

        :param value: The associated action definition.
        :raises: Validation Error if value is not a string.
        :raises: Validations Error if value does not contain only capital letters and underscores.
        """
        try:
            if re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), value):
                self._set("action_definition", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_UNDERSCORE))
        except TypeError:
            raise ValidationError("Action definition must be a string")

    @property
    def preemptable(self):
        """Gets the preemption level of this action object.

        :return: The preemption level.
        """
        return self._get("preemptable")

    @preemptable.setter
    def preemptable(self, value):
        """Sets the preemption level of this action object.

        :param value: A preemption level.
        :raises ValidationError if the preemption level is not one of the allowed levels.
        """
        if value in ActionPreemption.values():
            self._set("preemptable", value)
        else:
            raise ValidationError(
                "%s is not an allowed preemption (%s)" % (value, ", ".join(ActionPreemption.values())))

    @property
    def inputs(self):
        """Gets the input values for the action object if they exist-otherwise an empty dictionary is returned.

        :return: The action object inputs.
        """
        try:
            return self._get("inputs")
        except UndefinedFieldError:
            return {}

    @inputs.setter
    def inputs(self, value):
        """Set the inputs for the action.

        :param value: The action object inputs.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value does not contain the required fields.
        """
        try:
            self.check_input_fields(inputs_to_check=value)
            self._set("inputs", value)
        except ValidationError as e:
            raise e

    def get_input(self, field):
        """Gets the input value for a field.

        :param field: The field to get input value for.
        :raises UndefinedFieldError: if the input value is not set.
        """
        try:
            return self.inputs[field]
        except KeyError:
            raise UndefinedFieldError("Input value for %s is not set" % field)

    def set_input(self, field, value):
        """Sets the input value for a field.

        :param field: The field for which to set input value.
        :param value: The value to set.
        """
        self._set(["inputs", field], value)

    def check_input_fields(self, inputs_to_check=None):
        """
        Checks to see if all required input fields are set in the inputs.

        :param inputs_to_check: The input values to check for this action object.
        :raises ValidationError: Thrown if any of the required input fields are not set.
        """
        if inputs_to_check is not None:
            inputs = inputs_to_check
        else:
            inputs = self.inputs
        inputs = set(inputs.keys())
        missing_fields = set(self.required_fields) - inputs
        if missing_fields:
            raise ValidationError("Missing required input fields: %s" % ", ".join(missing_fields))

    def to_json_dict(self):
        """Gets the copy of the JSON document

        :return: the JSON document
        """
        self.check_input_fields()
        base = super(BaseAction, self).to_json_dict()
        for key, value in base.get('inputs', {}).iteritems():
            try:
                if isinstance(value, datetime.datetime):
                    base['inputs'][key] = Timestamp.to_string(value)
                elif isinstance(value, datetime.timedelta):
                    base['inputs'][key] = Duration.to_string(value)
            except TypeError as e:
                raise ValidationError(e)
        return base
