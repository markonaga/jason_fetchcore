# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseDock


class DockAction(Action, BaseDock):
    """
    The DOCK action calls the robot's auto-docking capability. This action assumes the robot is in front
    of a dock.
    """
    optional_fields = ["dock_id", "dock_pose_x", "dock_pose_y", "dock_pose_qx", "dock_pose_qy",
                       "dock_pose_qz", "dock_pose_qw"]

    def __init__(
            self, id=None, action_definition="DOCK", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, dock_id=None, dock_pose_x=None,
            dock_pose_y=None, dock_pose_qx=None, dock_pose_qy=None, dock_pose_qz=None, dock_pose_qw=None, inputs=None,
            outputs=None, states=None, on_complete=None, on_pause=None, on_resume=None, created=None, modified=None,
            **kwargs
    ):
        super(DockAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, dock_id=dock_id, dock_pose_x=dock_pose_x, dock_pose_y=dock_pose_y,
            dock_pose_qx=dock_pose_qx, dock_pose_qy=dock_pose_qy, dock_pose_qz=dock_pose_qz, dock_pose_qw=dock_pose_qw,
            inputs=inputs, outputs=outputs, states=states, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, created=created, modified=modified, **kwargs
        )
