# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class BaseDock(RestrictedListMixin, BaseAction):
    """
    The DOCK class for setting DOCK action and action template inputs.
    """
    optional_fields = ["dock_id", "dock_pose_x", "dock_pose_y", "dock_pose_qx", "dock_pose_qy",
                       "dock_pose_qz", "dock_pose_qw"]

    def __init__(
            self, id=None, action_definition="DOCK", preemptable=ActionPreemption.NONE, dock_id=None,
            dock_pose_x=None, dock_pose_y=None, dock_pose_qx=None, dock_pose_qy=None,
            dock_pose_qz=None, dock_pose_qw=None, inputs=None, created=None, modified=None, on_complete=None,
            on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseDock, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            if dock_id:
                self.dock_id = dock_id
            if dock_pose_x is not None:
                self.dock_pose_x = dock_pose_x
            if dock_pose_y is not None:
                self.dock_pose_y = dock_pose_y
            if dock_pose_qx is not None:
                self.dock_pose_qx = dock_pose_qx
            if dock_pose_qy is not None:
                self.dock_pose_qy = dock_pose_qy
            if dock_pose_qz is not None:
                self.dock_pose_qz = dock_pose_qz
            if dock_pose_qw is not None:
                self.dock_pose_qw = dock_pose_qw
        else:
            self.inputs = inputs

    @property
    def dock_id(self):
        """Gets the ID of the dock

        :return: Dock ID
        """
        return self.get_input("dock_id")

    @dock_id.setter
    def dock_id(self, value):
        """Sets the ID of the dock

        :param value: (integer) Dock ID
        :raises ValidationError if value is not an integer
        :raises ValidationError if value not a positive finite integer
        """
        if Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError("Dock ID must be a finite positive number (value is %s)" % value)
            self.set_input("dock_id", value)
        else:
            raise ValidationError("Dock ID must be a number (value is %s)" % value)

    @property
    def dock_pose_x(self):
        """Gets the x-coordinate of dock position
        :return: The x coordinate
        """
        return self.get_input("dock_pose_x")

    @dock_pose_x.setter
    def dock_pose_x(self, x):
        """Sets the x-coordinate of dock position
        :param x: (float) X value
        :raises ValidationError if x is not a number
        :raises ValidationError if x is not a finite number
        """
        if not Number.is_real_number(x):
            raise ValidationError("X coordinate must be a number (value is %s)" % x)
        elif not Number.is_finite(x):
            raise ValidationError("X coordinate must be a finite number "
                                  "(value is %s)" % x)
        else:
            self.set_input("dock_pose_x", x)

    @property
    def dock_pose_y(self):
        """Gets the y-coordinate of dock position
        :return: The y coordinate
        """
        return self.get_input("dock_pose_y")

    @dock_pose_y.setter
    def dock_pose_y(self, y):
        """Sets the y-coordinate of dock position
        :param y: (float) Y value
        :raises ValidationError if y is not a number
        :raises ValidationError if y is not a finite number
        """
        if not Number.is_real_number(y):
            raise ValidationError("Y coordinate must be a number (value is %s)" % y)
        elif not Number.is_finite(y):
            raise ValidationError("Y coordinate must be a finite number "
                                  "(value is %s)" % y)
        else:
            self.set_input("dock_pose_y", y)

    @property
    def dock_pose_qx(self):
        """Gets the x component of the dock quaternion

        :return: The x component
        """
        return self.get_input("dock_pose_qx")

    @dock_pose_qx.setter
    def dock_pose_qx(self, qx):
        """Sets the x component of the dock quaternion

        :param qx: (float) X component
        :raises ValidationError if qx is not a number
        :raises ValidationError if qx is not a finite number
        """
        if not Number.is_real_number(qx):
            raise ValidationError("Quarternion x component must be a number (value is %s)" % qx)
        elif not Number.is_finite(qx):
            raise ValidationError("Quaternion x component must be a finite number "
                                  "(value is %s)" % qx)
        else:
            self.set_input("dock_pose_qx", qx)

    @property
    def dock_pose_qy(self):
        """Gets the y component of the dock quaternion

        :return: The y component
        """
        return self.get_input("dock_pose_qy")

    @dock_pose_qy.setter
    def dock_pose_qy(self, qy):
        """Sets the y component of the dock quaternion

        :param qy: (float) Y component
        :raises ValidationError if qy is not a number
        :raises ValidationError if qy is not a finite number
        """
        if not Number.is_real_number(qy):
            raise ValidationError("Quarternion y component must be a number (value is %s)" % qy)
        elif not Number.is_finite(qy):
            raise ValidationError("Quaternion y component must be a finite number "
                                  "(value is %s)" % qy)
        else:
            self.set_input("dock_pose_qy", qy)

    @property
    def dock_pose_qz(self):
        """Gets the z component of the dock quaternion

        :return: The z component
        """
        return self.get_input("dock_pose_qz")

    @dock_pose_qz.setter
    def dock_pose_qz(self, qz):
        """Sets the z component of the dock quaternion

        :param qz: (float) Z component
        :raises ValidationError if qz is not a number
        :raises ValidationError if qz is not a finite number
        """
        if not Number.is_real_number(qz):
            raise ValidationError("Quarternion z component must be a number (value is %s)" % qz)
        elif not Number.is_finite(qz):
            raise ValidationError("Quaternion z component must be a finite number "
                                  "(value is %s)" % qz)
        else:
            self.set_input("dock_pose_qz", qz)

    @property
    def dock_pose_qw(self):
        """Gets the w component of the dock quaternion

        :return: The w component
        """
        return self.get_input("dock_pose_qw")

    @dock_pose_qw.setter
    def dock_pose_qw(self, qw):
        """Sets the w component of the dock quaternion

        :param qw: (float) W component
        :raises ValidationError if qw is not a number
        :raises ValidationError if qw is not a finite number
        """
        if not Number.is_real_number(qw):
            raise ValidationError("Quarternion w component must be a number (value is %s)" % qw)
        elif not Number.is_finite(qw):
            raise ValidationError("Quaternion w component must be a finite number "
                                  "(value is %s)" % qw)
        else:
            self.set_input("dock_pose_qw", qw)
