# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources.tasks.actions.definitions import BaseNavigate
from fetchcore.resources import Action


class NavigateAction(Action, BaseNavigate):
    """
    The NAVIGATE action navigates a robot to a particular location on the map.
    """
    optional_fields = [
        "pose_id", "pose_group_id", "goal_pose", "pose_name",
        "clear_costmaps", "max_velocity", "max_angular_velocity", "limit_velocity", "monitored"
    ]

    def __init__(
            self, id=None, action_definition="NAVIGATE", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, pose_id=None, pose_group_id=None, goal_pose=None,
            pose_name=None, clear_costmaps=None, max_velocity=None, max_angular_velocity=None,
            limit_velocity=None, monitored=None, inputs=None, outputs=None, states=None, on_complete=None,
            on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(NavigateAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, pose_id=pose_id, pose_group_id=pose_group_id, goal_pose=goal_pose, pose_name=pose_name,
            clear_costmaps=clear_costmaps, max_velocity=max_velocity,
            max_angular_velocity=max_angular_velocity, limit_velocity=limit_velocity, monitored=monitored,
            outputs=outputs, inputs=inputs, states=states, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, created=created, modified=modified, **kwargs
        )
