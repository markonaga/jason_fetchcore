# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard library
import numbers

# Fetchcore SDK Python
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.definitions import ActionPreemption
from fetchcore.exceptions import ValidationError


class BaseNavigate(RestrictedListMixin, BaseAction):
    """
    The NAVIGATE class for setting NAVIGATE action and action template inputs.
    """
    optional_fields = [
        "pose_id", "pose_group_id", "goal_pose", "pose_name",
        "clear_costmaps", "max_velocity", "max_angular_velocity", "limit_velocity", "monitored"
    ]

    def __init__(
            self, id=None, action_definition="NAVIGATE", preemptable=ActionPreemption.NONE,
            pose_id=None, pose_group_id=None, goal_pose=None, pose_name=None,
            clear_costmaps=None, max_velocity=None, max_angular_velocity=None, limit_velocity=None, monitored=None,
            inputs=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseNavigate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            if pose_id is not None:
                self.pose_id = pose_id
            if pose_group_id is not None:
                self.pose_group_id = pose_group_id
            if goal_pose is not None:
                self.goal_pose = goal_pose
            if pose_name is not None:
                self.pose_name = pose_name
            self.clear_costmaps = clear_costmaps
            self.max_velocity = max_velocity
            self.max_angular_velocity = max_angular_velocity
            self.limit_velocity = limit_velocity
            self.monitored = monitored
        else:
            self.inputs = inputs

    @property
    def pose_id(self):
        """Gets the poses that robot is trying to navigate to

        :return: The goal pose ID
        """
        return self.get_input("pose_id")

    @pose_id.setter
    def pose_id(self, value):
        """Sets or creates the poses that robot is trying to navigate to

        :param value: (integer) The goal pose ID
        :raises ValidationError if poses is not an ID
        """
        if value and Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError("Pose ID must be a finite positive number (value is %s)" % value)
            self.set_input("pose_id", value)
        elif value:
            raise ValidationError("Pose ID must be a number (value is %s)" % value)
        self.set_input("pose_id", value)

    @property
    def pose_group_id(self):
        """Gets the pose groups that robot is trying to navigate to

        :return: The goal pose group ID
        """
        return self.get_input("pose_group_id")

    @pose_group_id.setter
    def pose_group_id(self, value):
        """Sets or creates the pose groups that robot is trying to navigate to

        :param value: (integer) The goal pose group ID
        :raises ValidationError if pose groups is not an ID
        """
        if value and Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError("Pose Group ID must be a finite positive number (value is %s)" % value)
            self.set_input("pose_group_id", value)
        elif value:
            raise ValidationError("Pose Group ID must be a number (value is %s)" % value)
        self.set_input("pose_group_id", value)

    @property
    def pose_name(self):
        """Gets the poses that robot is trying to navigate to

        :return: The goal pose name
        """
        return self.get_input("pose_name")

    @pose_name.setter
    def pose_name(self, value):
        """Sets or creates the poses that robot is trying to navigate to

        :param pose_name: (string) The goal pose name
        :raises ValidationError if poses is not an ID
        """
        if value and not isinstance(value, basestring):
            raise ValidationError("Pose name must be a string (value is %s)" % value)
        self.set_input("pose_name", value)

    @property
    def goal_pose(self):
        """Gets the pose that the robot is trying to localize near

        :return: The goal pose
        """
        return self.get_input("goal_pose")

    @goal_pose.setter
    def goal_pose(self, goal_pose):
        """Sets pose that the robot is trying to localize near

        :param pose: pose dictionary
        :raises ValidationError if pose is not a dictionary with x, y, theta
        """
        if not isinstance(goal_pose, dict):
            raise ValidationError(
                "Pose must be a dictionary (%s is %s)" % (goal_pose, type(goal_pose).__name__))
        elif not (isinstance(
                goal_pose.get('x'), numbers.Number
        ) and isinstance(
            goal_pose.get('y'), numbers.Number
        ) and isinstance(
            goal_pose.get('theta'), numbers.Number
        )):
            raise ValidationError("Pose have x, y, and theta.")
        else:
            self.set_input("goal_pose", goal_pose)

    @property
    def clear_costmaps(self):
        """Gets whether the costmaps should be cleared

        :return: Whether to clear costmaps
        """
        return self.get_input("clear_costmaps")

    @clear_costmaps.setter
    def clear_costmaps(self, clear):
        """Sets whether the costmaps should be cleared

        :param clear: (bool) Whether to clear costmaps
        :raises ValidationError if clear is not a bool
        """
        if clear and not isinstance(clear, bool):
            raise ValidationError("Clear costmaps must be a bool")
        else:
            self.set_input("clear_costmaps", clear)

    @property
    def max_velocity(self):
        """Gets the max velocity that robot should go during navigation

        :return: The max velocity
        """
        return self.get_input("max_velocity")

    @max_velocity.setter
    def max_velocity(self, velocity):
        """Sets the max velocity that robot should go during navigation

        :param velocity: (float) The max velocity
        :raises ValidationError if velocity is not a number
        :raises ValidationError if velocity is not a non-negative finite number
        """
        if velocity and not Number.is_real_number(velocity):
            raise ValidationError("Max velocity must be a number (value is %s)" % velocity)
        elif velocity and not Number.is_finite_non_negative(velocity):
            raise ValidationError("Max velocity must be a finite non-negative number "
                                  "(value is %s)" % velocity)
        else:
            self.set_input("max_velocity", velocity)

    @property
    def max_angular_velocity(self):
        """Gets the max angular velocity that robot should go during navigation

        :return: The max angular velocity
        """
        return self.get_input("max_angular_velocity")

    @max_angular_velocity.setter
    def max_angular_velocity(self, velocity):
        """Sets the max angular velocity that robot should go during navigation

        :param velocity: (float) Max angular velocity
        :raises ValidationError if velocity is not a number
        :raises ValidationError if velocity is not a non-negative finite number
        """
        if velocity and not Number.is_real_number(velocity):
            raise ValidationError("Max angular velocity must be a number (value is %s)" % velocity)
        elif velocity and not Number.is_finite_non_negative(velocity):
            raise ValidationError("Max angular velocity must be a finite non-negative number "
                                  "(value is %s)" % velocity)
        else:
            self.set_input("max_angular_velocity", velocity)

    @property
    def limit_velocity(self):
        """Gets the variable that says whether the navigate action is velocity limited

        :return:
        """
        return self.get_input("limit_velocity")

    @limit_velocity.setter
    def limit_velocity(self, limit):
        """Sets the variable that says whether the navigate action is velocity limited

        :param limit: (bool) Says whether navigate is velocity limited
        :raises ValidationError if limit is not a bool
        """
        if limit and not isinstance(limit, bool):
            raise ValidationError("Limit velocity must be a bool")
        else:
            self.set_input("limit_velocity", limit)

    @property
    def monitored(self):
        """Gets the variable that says whether the navigate action is monitored

        :return:
        """
        return self.get_input("monitored")

    @monitored.setter
    def monitored(self, monitored):
        """Sets the variable that says whether the navigate action is monitored

        :param monitored: (bool) Says whether navigate is monitored
        :raises ValidationError if monitored is not a bool
        """
        if monitored and not isinstance(monitored, bool):
            raise ValidationError("Monitored state must be a bool")
        else:
            self.set_input("monitored", monitored)
