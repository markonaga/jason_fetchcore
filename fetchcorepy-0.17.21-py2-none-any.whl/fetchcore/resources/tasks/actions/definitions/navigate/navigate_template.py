# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseNavigate


class NavigateTemplate(ActionTemplate, BaseNavigate):
    """
    The NAVIGATE action template navigates a robot to a particular location on the map.
    """
    optional_fields = [
        "pose_id", "pose_group_id", "goal_pose", "pose_name",
        "clear_costmaps", "max_velocity", "max_angular_velocity", "limit_velocity", "monitored"
    ]

    def __init__(
            self, id=None, action_definition="NAVIGATE", preemptable=ActionPreemption.NONE,
            pose_id=None, pose_group_id=None, goal_pose=None, pose_name=None,
            clear_costmaps=None, max_velocity=None, max_angular_velocity=None, limit_velocity=None, monitored=None,
            inputs=None, task_template=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(NavigateTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, pose_id=pose_id,
            pose_group_id=pose_group_id, goal_pose=goal_pose, pose_name=pose_name,
            clear_costmaps=clear_costmaps, max_velocity=max_velocity, max_angular_velocity=max_angular_velocity,
            limit_velocity=limit_velocity, monitored=monitored, inputs=inputs, task_template=task_template,
            created=created, modified=modified, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            **kwargs
        )
