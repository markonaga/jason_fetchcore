# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseAttachCart


class AttachCartAction(Action, BaseAttachCart):
    """
    The ATTACH_CART action calls the robot's auto-carting capability. This action assumes the robot is in
    front of a Fetch cart.
    """

    optional_fields = ["hint_position_tolerance", "hint_yaw_tolerance", "goal_position_tolerance",
                       "goal_yaw_tolerance"]

    required_fields = ["cart_footprint_name", "hint_pose_x", "hint_pose_y", "hint_pose_qx", "hint_pose_qy",
                       "hint_pose_qz", "hint_pose_qw"]

    def __init__(
            self, id=None, action_definition="ATTACH_CART", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, cart_footprint_name=None,
            hint_pose_x=None, hint_pose_y=None, hint_pose_qx=None, hint_pose_qy=None, hint_pose_qz=None,
            hint_pose_qw=None, hint_position_tolerance=None, hint_yaw_tolerance=None, goal_position_tolerance=None,
            goal_yaw_tolerance=None, inputs=None, outputs=None, states=None, on_complete=None, on_pause=None,
            on_resume=None, created=None, modified=None, **kwargs
    ):
        super(AttachCartAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, cart_footprint_name=cart_footprint_name, hint_pose_x=hint_pose_x, hint_pose_y=hint_pose_y,
            hint_pose_qx=hint_pose_qx, hint_pose_qy=hint_pose_qy, hint_pose_qz=hint_pose_qz, hint_pose_qw=hint_pose_qw,
            hint_position_tolerance=hint_position_tolerance, hint_yaw_tolerance=hint_yaw_tolerance,
            goal_position_tolerance=goal_position_tolerance, goal_yaw_tolerance=goal_yaw_tolerance, inputs=inputs,
            outputs=outputs, states=states, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            created=created, modified=modified, **kwargs
        )
