# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang, Cappy Pitts

# Standard library
import re

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption, REGEX_CAPITAL_UNDERSCORE
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class BaseAttachCart(RestrictedListMixin, BaseAction):
    """
    The ATTACH_CART class for setting ATTACH_CART action and action template inputs.
    """
    optional_fields = ["hint_position_tolerance", "hint_yaw_tolerance", "goal_position_tolerance",
                       "goal_yaw_tolerance"]

    required_fields = ["cart_footprint_name", "hint_pose_x", "hint_pose_y", "hint_pose_qx", "hint_pose_qy",
                       "hint_pose_qz", "hint_pose_qw"]

    def __init__(
            self, id=None, action_definition="ATTACH_CART", preemptable=ActionPreemption.NONE, cart_footprint_name=None,
            hint_pose_x=None, hint_pose_y=None, hint_pose_qx=None, hint_pose_qy=None, hint_pose_qz=None,
            hint_pose_qw=None, hint_position_tolerance=None, hint_yaw_tolerance=None, goal_position_tolerance=None,
            goal_yaw_tolerance=None, inputs=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(BaseAttachCart, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.cart_footprint_name = cart_footprint_name
            self.hint_pose_x = hint_pose_x
            self.hint_pose_y = hint_pose_y
            self.hint_pose_qx = hint_pose_qx
            self.hint_pose_qy = hint_pose_qy
            self.hint_pose_qz = hint_pose_qz
            self.hint_pose_qw = hint_pose_qw
            if hint_position_tolerance:
                self.hint_position_tolerance = hint_position_tolerance
            if hint_yaw_tolerance:
                self.hint_yaw_tolerance = hint_yaw_tolerance
            if goal_position_tolerance:
                self.goal_position_tolerance = goal_position_tolerance
            if goal_yaw_tolerance:
                self.goal_yaw_tolerance = goal_yaw_tolerance
        else:
            self.inputs = inputs

    @property
    def cart_footprint_name(self):
        return self.get_input("cart_footprint_name")

    @cart_footprint_name.setter
    def cart_footprint_name(self, value):
        try:
            if re.match(REGEX_CAPITAL_UNDERSCORE, value):
                self.set_input("cart_footprint_name", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_UNDERSCORE))
        except TypeError:
            raise ValidationError("Cart footprint name must be a string, not a %s" % type(value).__name__)

    @property
    def hint_position_tolerance(self):
        return self.get_input("hint_position_tolerance")

    @hint_position_tolerance.setter
    def hint_position_tolerance(self, value):
        if not Number.is_real_number(value):
            raise ValidationError("Hint position tolerance must be a number (value is %s)" % value)
        elif not Number.is_finite(value):
            raise ValidationError("Hint position tolerance must be a finite number (value is %s)" % value)
        else:
            self.set_input("hint_position_tolerance", value)

    @property
    def hint_yaw_tolerance(self):
        return self.get_input("hint_yaw_tolerance")

    @hint_yaw_tolerance.setter
    def hint_yaw_tolerance(self, value):
        if not Number.is_real_number(value):
            raise ValidationError("Hint yaw tolerance must be a number (value is %s)" % value)
        elif not Number.is_finite(value):
            raise ValidationError("Hint yaw tolerance must be a finite number (value is %s)" % value)
        else:
            self.set_input("hint_yaw_tolerance", value)

    @property
    def goal_position_tolerance(self):
        return self.get_input("goal_position_tolerance")

    @goal_position_tolerance.setter
    def goal_position_tolerance(self, value):
        if not Number.is_real_number(value):
            raise ValidationError("Goal position tolerance must be a number (value is %s)" % value)
        elif not Number.is_finite(value):
            raise ValidationError("Goal position tolerance must be a finite number (value is %s)" % value)
        else:
            self.set_input("goal_position_tolerance", value)

    @property
    def goal_yaw_tolerance(self):
        return self.get_input("goal_yaw_tolerance")

    @goal_yaw_tolerance.setter
    def goal_yaw_tolerance(self, value):
        if not Number.is_real_number(value):
            raise ValidationError("Goal yaw tolerance must be a number (value is %s)" % value)
        elif not Number.is_finite(value):
            raise ValidationError("Goal yaw tolerance must be a finite number (value is %s)" % value)
        else:
            self.set_input("goal_yaw_tolerance", value)

    @property
    def hint_pose_x(self):
        """Gets the x-coordinate of dock position
        :return: The x coordinate
        """
        return self.get_input("hint_pose_x")

    @hint_pose_x.setter
    def hint_pose_x(self, x):
        """Sets the x-coordinate of dock position
        :param x: (float) X value
        :raises ValidationError if x is not a number
        :raises ValidationError if x is not a finite number
        """
        if not Number.is_real_number(x):
            raise ValidationError("X coordinate must be a number (value is %s)" % x)
        elif not Number.is_finite(x):
            raise ValidationError("X coordinate must be a finite number "
                                  "(value is %s)" % x)
        else:
            self.set_input("hint_pose_x", x)

    @property
    def hint_pose_y(self):
        """Gets the y-coordinate of dock position
        :return: The y coordinate
        """
        return self.get_input("hint_pose_y")

    @hint_pose_y.setter
    def hint_pose_y(self, y):
        """Sets the y-coordinate of dock position
        :param y: (float) Y value
        :raises ValidationError if y is not a number
        :raises ValidationError if y is not a finite number
        """
        if not Number.is_real_number(y):
            raise ValidationError("Y coordinate must be a number (value is %s)" % y)
        elif not Number.is_finite(y):
            raise ValidationError("Y coordinate must be a finite number "
                                  "(value is %s)" % y)
        else:
            self.set_input("hint_pose_y", y)

    @property
    def hint_pose_qx(self):
        """Gets the x component of the dock quaternion

        :return: The x component
        """
        return self.get_input("hint_pose_qx")

    @hint_pose_qx.setter
    def hint_pose_qx(self, qx):
        """Sets the x component of the dock quaternion

        :param qx: (float) X component
        :raises ValidationError if qx is not a number
        :raises ValidationError if qx is not a finite number
        """
        if not Number.is_real_number(qx):
            raise ValidationError("Quarternion x component must be a number (value is %s)" % qx)
        elif not Number.is_finite(qx):
            raise ValidationError("Quaternion x component must be a finite number "
                                  "(value is %s)" % qx)
        else:
            self.set_input("hint_pose_qx", qx)

    @property
    def hint_pose_qy(self):
        """Gets the y component of the dock quaternion

        :return: The y component
        """
        return self.get_input("hint_pose_qy")

    @hint_pose_qy.setter
    def hint_pose_qy(self, qy):
        """Sets the y component of the dock quaternion

        :param qy: (float) Y component
        :raises ValidationError if qy is not a number
        :raises ValidationError if qy is not a finite number
        """
        if not Number.is_real_number(qy):
            raise ValidationError("Quarternion y component must be a number (value is %s)" % qy)
        elif not Number.is_finite(qy):
            raise ValidationError("Quaternion y component must be a finite number "
                                  "(value is %s)" % qy)
        else:
            self.set_input("hint_pose_qy", qy)

    @property
    def hint_pose_qz(self):
        """Gets the z component of the dock quaternion

        :return: The z component
        """
        return self.get_input("hint_pose_qz")

    @hint_pose_qz.setter
    def hint_pose_qz(self, qz):
        """Sets the z component of the dock quaternion

        :param qz: (float) Z component
        :raises ValidationError if qz is not a number
        :raises ValidationError if qz is not a finite number
        """
        if not Number.is_real_number(qz):
            raise ValidationError("Quarternion z component must be a number (value is %s)" % qz)
        elif not Number.is_finite(qz):
            raise ValidationError("Quaternion z component must be a finite number "
                                  "(value is %s)" % qz)
        else:
            self.set_input("hint_pose_qz", qz)

    @property
    def hint_pose_qw(self):
        """Gets the w component of the dock quaternion

        :return: The w component
        """
        return self.get_input("hint_pose_qw")

    @hint_pose_qw.setter
    def hint_pose_qw(self, qw):
        """Sets the w component of the dock quaternion

        :param qw: (float) W component
        :raises ValidationError if qw is not a number
        :raises ValidationError if qw is not a finite number
        """
        if not Number.is_real_number(qw):
            raise ValidationError("Quarternion w component must be a number (value is %s)" % qw)
        elif not Number.is_finite(qw):
            raise ValidationError("Quaternion w component must be a finite number "
                                  "(value is %s)" % qw)
        else:
            self.set_input("hint_pose_qw", qw)
