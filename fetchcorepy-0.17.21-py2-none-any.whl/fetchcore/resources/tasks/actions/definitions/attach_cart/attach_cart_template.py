# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseAttachCart


class AttachCartTemplate(ActionTemplate, BaseAttachCart):
    """
    The ATTACH_CART action template calls the robot's auto-carting capability. This template assumes the robot is in
    front of a Fetch cart.
    """
    optional_fields = ["hint_position_tolerance", "hint_yaw_tolerance", "goal_position_tolerance",
                       "goal_yaw_tolerance"]

    required_fields = ["cart_footprint_name", "hint_pose_x", "hint_pose_y", "hint_pose_qx", "hint_pose_qy",
                       "hint_pose_qz", "hint_pose_qw"]

    def __init__(
            self, id=None, action_definition="ATTACH_CART", preemptable=ActionPreemption.NONE, cart_footprint_name=None,
            hint_pose_x=None, hint_pose_y=None, hint_pose_qx=None, hint_pose_qy=None, hint_pose_qz=None,
            hint_pose_qw=None, hint_position_tolerance=None, hint_yaw_tolerance=None, goal_position_tolerance=None,
            goal_yaw_tolerance=None, inputs=None, task_template=None, created=None, modified=None, on_complete=None,
            on_pause=None, on_resume=None, **kwargs
    ):
        super(AttachCartTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable,
            cart_footprint_name=cart_footprint_name, hint_pose_x=hint_pose_x, hint_pose_y=hint_pose_y,
            hint_pose_qx=hint_pose_qx, hint_pose_qy=hint_pose_qy, hint_pose_qz=hint_pose_qz, hint_pose_qw=hint_pose_qw,
            hint_position_tolerance=hint_position_tolerance, hint_yaw_tolerance=hint_yaw_tolerance,
            goal_position_tolerance=goal_position_tolerance, goal_yaw_tolerance=goal_yaw_tolerance, inputs=inputs,
            task_template=task_template, created=created, modified=modified, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, **kwargs
        )
