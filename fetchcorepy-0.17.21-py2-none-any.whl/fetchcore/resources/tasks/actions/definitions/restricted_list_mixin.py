# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.exceptions import UnsupportedOperation


class RestrictedListMixin(object):
    """Class to make list an unsupported operation for any actions other than in the base action class"""

    @classmethod
    def list(cls, client=None, page=None, offset=None, amount=None):
        """Overwrites base class list. You can get a list of all actions, but not an action with a specific action
        definition.

        :raise fetchcore.exceptions.UnsupportedOperation:
        """
        raise UnsupportedOperation(
            "Actions must be listed by using the Action resource. List method is unsupported for %s."
            % type(cls).__name__)
