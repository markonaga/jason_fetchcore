# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseDetachCart


class DetachCartTemplate(ActionTemplate, BaseDetachCart):
    """
    The DETACH_CART action template calls the on the robot's capability to automatically detach from a cart.
    This template assumes the robot is attached to a Fetch cart.
    """
    optional_fields = ["rotate_in_place", "travel_distance"]

    required_fields = ["cart_footprint_name"]

    def __init__(
            self, id=None, action_definition="DETACH_CART", preemptable=ActionPreemption.NONE, cart_footprint_name=None,
            travel_distance=None, rotate_in_place=None, inputs=None, task_template=None, created=None, modified=None,
            on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(DetachCartTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable,
            cart_footprint_name=cart_footprint_name, travel_distance=travel_distance, rotate_in_place=rotate_in_place,
            inputs=inputs, created=created, modified=modified, task_template=task_template, on_complete=on_complete,
            on_pause=on_pause, on_resume=on_resume, **kwargs
        )
