# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard library
import re

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption, REGEX_CAPITAL_UNDERSCORE
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class BaseDetachCart(RestrictedListMixin, BaseAction):
    """
    The DETACH_CART class for setting DETACH_CART action and action template inputs.
    """
    optional_fields = ["rotate_in_place", "travel_distance"]

    required_fields = ["cart_footprint_name"]

    def __init__(
            self, id=None, action_definition="DETACH_CART", preemptable=ActionPreemption.NONE, cart_footprint_name=None,
            travel_distance=None, rotate_in_place=None, inputs=None, created=None, modified=None, on_complete=None,
            on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseDetachCart, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.cart_footprint_name = cart_footprint_name
            if travel_distance is not None:
                self.travel_distance = travel_distance
            if rotate_in_place is not None:
                self.rotate_in_place = rotate_in_place
        else:
            self.inputs = inputs

    @property
    def cart_footprint_name(self):
        return self.get_input("cart_footprint_name")

    @cart_footprint_name.setter
    def cart_footprint_name(self, value):
        try:
            if re.match(REGEX_CAPITAL_UNDERSCORE, value):
                self.set_input("cart_footprint_name", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_UNDERSCORE))
        except TypeError:
            raise ValidationError("Cart footprint name must be a string, not a %s" % type(value).__name__)

    @property
    def travel_distance(self):
        return self.get_input("travel_distance")

    @travel_distance.setter
    def travel_distance(self, value):
        if not Number.is_real_number(value):
            raise ValidationError("Travel distance must be a number (value is %s)" % value)
        elif not Number.is_finite(value):
            raise ValidationError("Travel distance must be a finite number (value is %s)" % value)
        else:
            self.set_input("travel_distance", value)

    @property
    def rotate_in_place(self):
        """Gets the variable that says whether to rotate 180 degrees

        :return: Whether to rotate
        """
        return self.get_input("rotate_in_place")

    @rotate_in_place.setter
    def rotate_in_place(self, rotate):
        """Sets whether to rotate in place

        :param rotate: (bool) Says whether to rotate
        :raises ValidationError if rotate is not a bool
        """
        if isinstance(rotate, bool):
            self.set_input("rotate_in_place", rotate)
        elif rotate in ['True', 'False']:
            self.set_input('rotate_in_place', True if rotate == 'True' else False)
        else:
            raise ValidationError("Rotate in place must be a bool.")
