# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseDetachCart


class DetachCartAction(Action, BaseDetachCart):
    """
    The DETACH_CART action calls the on the robot's capability to automatically detach from a cart.
    This action assumes the robot is attached to a Fetch cart.
    """

    optional_fields = ["rotate_in_place", "travel_distance"]

    required_fields = ["cart_footprint_name"]

    def __init__(
            self, id=None, action_definition="DETACH_CART", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, cart_footprint_name=None,
            travel_distance=None, rotate_in_place=None, inputs=None, outputs=None, states=None, on_complete=None,
            on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(DetachCartAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, cart_footprint_name=cart_footprint_name, travel_distance=travel_distance,
            rotate_in_place=rotate_in_place, inputs=inputs, outputs=outputs, states=states, on_complete=on_complete,
            on_pause=on_pause, on_resume=on_resume, created=created, modified=modified, **kwargs
        )
