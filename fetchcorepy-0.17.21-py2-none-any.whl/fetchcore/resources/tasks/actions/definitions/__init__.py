from .restricted_list_mixin import RestrictedListMixin  # NOQA

from .attach_cart.base_attach_cart import BaseAttachCart  # NOQA
from .attach_cart.attach_cart_action import AttachCartAction  # NOQA
from .attach_cart.attach_cart_template import AttachCartTemplate  # NOQA

from .buildmap.base_buildmap import BaseBuildmap  # NOQA
from .buildmap.buildmap_action import BuildmapAction  # NOQA
from .buildmap.buildmap_template import BuildmapTemplate  # NOQA

from .detach_cart.base_detach_cart import BaseDetachCart  # NOQA
from .detach_cart.detach_cart_action import DetachCartAction  # NOQA
from .detach_cart.detach_cart_template import DetachCartTemplate  # NOQA

from .dock.base_dock import BaseDock  # NOQA
from .dock.dock_action import DockAction  # NOQA
from .dock.dock_template import DockTemplate  # NOQA

from .hmi_buttons.base_hmi_buttons import BaseHMIButtons  # NOQA
from .hmi_buttons.hmi_buttons_action import HMIButtonsAction  # NOQA
from .hmi_buttons.hmi_buttons_template import HMIButtonsTemplate  # NOQA

from .localize.base_localize import BaseLocalize  # NOQA
from .localize.localize_action import LocalizeAction  # NOQA
from .localize.localize_template import LocalizeTemplate  # NOQA

from .navigate.base_navigate import BaseNavigate  # NOQA
from .navigate.navigate_action import NavigateAction  # NOQA
from .navigate.navigate_template import NavigateTemplate  # NOQA

from .playsound.base_playsound import BasePlaySound  # NOQA
from .playsound.playsound_action import PlaySoundAction  # NOQA
from .playsound.playsound_template import PlaySoundTemplate  # NOQA

from .subtask.base_subtask import BaseSubtask  # NOQA
from .subtask.subtask_action import SubtaskAction  # NOQA
from .subtask.subtask_template import SubtaskTemplate  # NOQA

from .survey.base_survey import BaseSurvey  # NOQA
from .survey.survey_action import SurveyAction  # NOQA
from .survey.survey_template import SurveyTemplate  # NOQA

from .waitfor.base_waitfor import BaseWaitfor  # NOQA
from .waitfor.waitfor_action import WaitforAction  # NOQA
from .waitfor.waitfor_template import WaitforTemplate  # NOQA

from .undock.base_undock import BaseUndock  # NOQA
from .undock.undock_action import UndockAction  # NOQA
from .undock.undock_template import UndockTemplate  # NOQA

from .update.base_update import BaseUpdate  # NOQA
from .update.update_action import UpdateAction  # NOQA
from .update.update_template import UpdateTemplate  # NOQA

from .url.base_url import BaseURL  # NOQA
from .url.url_action import URLAction  # NOQA
from .url.url_template import URLTemplate  # NOQA

ACTION_TEMPLATE_CLASSES = {
    'BUILDMAP': BuildmapTemplate,
    'DOCK': DockTemplate,
    'HMI_BUTTONS': HMIButtonsTemplate,
    'LOCALIZE': LocalizeTemplate,
    'NAVIGATE': NavigateTemplate,
    'UNDOCK': UndockTemplate,
    'UPDATE': UpdateTemplate,
    'URL': URLTemplate,
    'SUBTASK': SubtaskTemplate,
    'SURVEY': SurveyTemplate,
    'WAITFOR': WaitforTemplate,
    'ATTACH_CART': AttachCartTemplate,
    'DETACH_CART': DetachCartTemplate,
    'PLAY_SOUND': PlaySoundTemplate,
}

ACTION_CLASSES = {
    'BUILDMAP': BuildmapAction,
    'DOCK': DockAction,
    'HMI_BUTTONS': HMIButtonsAction,
    'LOCALIZE': LocalizeAction,
    'NAVIGATE': NavigateAction,
    'UNDOCK': UndockAction,
    'UPDATE': UpdateAction,
    'URL': URLAction,
    'SUBTASK': SubtaskAction,
    'SURVEY': SurveyAction,
    'WAITFOR': WaitforAction,
    'ATTACH_CART': AttachCartAction,
    'DETACH_CART': DetachCartAction,
    'PLAY_SOUND': PlaySoundAction,
}
