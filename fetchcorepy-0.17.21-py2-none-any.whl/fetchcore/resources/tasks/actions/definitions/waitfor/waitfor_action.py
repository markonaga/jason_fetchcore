# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseWaitfor


class WaitforAction(Action, BaseWaitfor):
    """
    The WAITFOR action has the robot wait at its current location for a set amount of time.
    """
    required_fields = ["duration"]

    def __init__(
            self, id=None, action_definition="WAITFOR", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, duration=None, inputs=None, outputs=None, states=None,
            on_complete=None, on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(WaitforAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, duration=duration, inputs=inputs, outputs=outputs, states=states, on_complete=on_complete,
            on_pause=on_pause, on_resume=on_resume, created=created, modified=modified, **kwargs
        )
