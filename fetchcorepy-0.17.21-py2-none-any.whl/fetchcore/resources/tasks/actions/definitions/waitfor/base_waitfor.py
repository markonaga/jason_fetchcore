# Copyright 2017 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard Library
import re
from datetime import timedelta

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError
from fetchcore.definitions import REGEX_DURATION

TIMEDELTA_REGEX = re.compile(REGEX_DURATION)


class BaseWaitfor(RestrictedListMixin, BaseAction):
    """
    The WAITFOR class for setting WAITFOR action and action template inputs.
    """
    required_fields = ["duration"]

    def __init__(
            self, id=None, action_definition="WAITFOR", preemptable=ActionPreemption.NONE, duration=None, inputs=None,
            created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseWaitfor, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.duration = duration
        else:
            self.inputs = inputs

    @property
    def duration(self):
        """Gets the duration that the robot should wait for (in seconds)
        :return: The duration
        """
        base = self.get_input("duration")
        if isinstance(base, timedelta):
            return base
        else:
            match = TIMEDELTA_REGEX.match(base)
            groups = match.groupdict()
            return timedelta(hours=int(groups['hours']), minutes=int(groups['minutes']), seconds=int(groups['seconds']))

    @duration.setter
    def duration(self, value):
        """Sets the duration that the robot should wait for (in seconds)
        :param value: (float) Duration robot should wait
        :raises ValidationError if d is not a number
        :raises ValidationError if d is not a positive number
        """
        if isinstance(value, timedelta):
            self.set_input("duration", value)
        elif isinstance(value, basestring):
            match = TIMEDELTA_REGEX.match(value)
            if match:
                groups = match.groupdict()
                self.set_input("duration", timedelta(hours=int(groups['hours']),
                                                     minutes=int(groups['minutes']),
                                                     seconds=int(groups['seconds'])))
            else:
                raise ValidationError("Duration string %s could not be parsed into a timedelta." % value)
        else:
            raise ValidationError("Duration must be a timedelta or string, not a %s." % type(value).__name__)
