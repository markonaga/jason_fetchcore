# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseWaitfor


class WaitforTemplate(ActionTemplate, BaseWaitfor):
    """
    The WAITFOR action template has the robot wait at its current location for a set amount of time.
    """
    required_fields = ["duration"]

    def __init__(
            self, id=None, action_definition="WAITFOR", preemptable=ActionPreemption.NONE, duration=None, inputs=None,
            task_template=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(WaitforTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, duration=duration, inputs=inputs,
            created=created, modified=modified, task_template=task_template, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, **kwargs
        )
