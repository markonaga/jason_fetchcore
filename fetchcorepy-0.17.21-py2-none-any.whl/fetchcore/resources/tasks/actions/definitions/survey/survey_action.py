# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseSurvey


class SurveyAction(Action, BaseSurvey):
    """
    The SURVEY action allows the robot to perform data survey activities.
    """
    optional_fields = ["intermediate_task_template_id", "max_velocity", "max_angular_velocity", "limit_velocity"]

    required_fields = ["survey_path_id"]

    def __init__(
            self, id=None, action_definition="SURVEY", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, survey_path_id=None, intermediate_task_template_id=None,
            max_velocity=None, max_angular_velocity=None, limit_velocity=None,
            inputs=None, outputs=None, states=None, on_complete=None, on_pause=None, on_resume=None, created=None,
            modified=None, **kwargs
    ):
        super(SurveyAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, survey_path_id=survey_path_id, intermediate_task_template_id=intermediate_task_template_id,
            max_velocity=max_velocity, max_angular_velocity=max_angular_velocity, limit_velocity=limit_velocity,
            inputs=inputs, outputs=outputs, states=states, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, created=created, modified=modified, **kwargs
        )
