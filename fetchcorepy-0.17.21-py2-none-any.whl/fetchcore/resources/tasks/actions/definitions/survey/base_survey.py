# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class BaseSurvey(RestrictedListMixin, BaseAction):
    """
    The SURVEY class for setting SURVEY action and action template inputs.
    """
    optional_fields = ["intermediate_task_template_id", "max_velocity", "max_angular_velocity", "limit_velocity"]

    required_fields = ["survey_path_id"]

    def __init__(
            self, id=None, action_definition="SURVEY", preemptable=ActionPreemption.NONE, survey_path_id=None,
            intermediate_task_template_id=None, max_velocity=None, max_angular_velocity=None, limit_velocity=None,
            inputs=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseSurvey, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.survey_path_id = survey_path_id
            if intermediate_task_template_id is not None:
                self.intermediate_task_template_id = intermediate_task_template_id
            if max_velocity is not None:
                self.max_velocity = max_velocity
            if max_angular_velocity is not None:
                self.max_angular_velocity = max_angular_velocity
            if limit_velocity is not None:
                self.limit_velocity = limit_velocity
        else:
            self.inputs = inputs

    @property
    def survey_path_id(self):
        """Gets the ID of survey path for this action to follow.

        :return: Survey path ID
        """
        return self.get_input("survey_path_id")

    @survey_path_id.setter
    def survey_path_id(self, value):
        """Sets the ID of survey path for this action to follow.

        :param value: (integer) Survey path ID
        :raises ValidationError if value is not a positive finite integer
        """
        if Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError("Survey path ID must be a finite positive number (value is %s)" % value)
            self.set_input("survey_path_id", value)
        else:
            raise ValidationError("Survey path ID must be a number (value is %s)" % value)

    @property
    def intermediate_task_template_id(self):
        """Gets the optional ID of the task template to run at each intermediate survey pose.

        :return: Task template ID
        """
        return self.get_input("intermediate_task_template_id")

    @intermediate_task_template_id.setter
    def intermediate_task_template_id(self, value):
        """Sets the optional ID of the task template to run at each intermediate survey pose.

        :param value: (integer) Task template ID
        :raises ValidationError if value is not a positive finite integer
        """
        if Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError(
                    "Intermediate task template ID must be a finite positive number (value is %s)" % value)
            self.set_input("intermediate_task_template_id", value)
        else:
            raise ValidationError("Intermediate task template ID must be a number (value is %s)" % value)

    @property
    def max_velocity(self):
        """Gets the max velocity that robot should go during data survey

        :return: The max velocity
        """
        return self.get_input("max_velocity")

    @max_velocity.setter
    def max_velocity(self, velocity):
        """Sets the max velocity that robot should go during data survey

        :param velocity: (float) The max velocity
        :raises ValidationError if velocity is not a number
        :raises ValidationError if velocity is not a non-negative finite number
        """
        if velocity and not Number.is_real_number(velocity):
            raise ValidationError("Max velocity must be a number (value is %s)" % velocity)
        elif velocity and not Number.is_finite_non_negative(velocity):
            raise ValidationError("Max velocity must be a finite non-negative number "
                                  "(value is %s)" % velocity)
        else:
            self.set_input("max_velocity", velocity)

    @property
    def max_angular_velocity(self):
        """Gets the max angular velocity that robot should go during data survey

        :return: The max angular velocity
        """
        return self.get_input("max_angular_velocity")

    @max_angular_velocity.setter
    def max_angular_velocity(self, velocity):
        """Sets the max angular velocity that robot should go during data survey

        :param velocity: (float) Max angular velocity
        :raises ValidationError if velocity is not a number
        :raises ValidationError if velocity is not a non-negative finite number
        """
        if velocity and not Number.is_real_number(velocity):
            raise ValidationError("Max angular velocity must be a number (value is %s)" % velocity)
        elif velocity and not Number.is_finite_non_negative(velocity):
            raise ValidationError("Max angular velocity must be a finite non-negative number "
                                  "(value is %s)" % velocity)
        else:
            self.set_input("max_angular_velocity", velocity)

    @property
    def limit_velocity(self):
        """Gets the variable that says whether the survey action is velocity limited

        :return:
        """
        return self.get_input("limit_velocity")

    @limit_velocity.setter
    def limit_velocity(self, limit):
        """Sets the variable that says whether the survey action is velocity limited

        :param limit: (bool) Says whether survey is velocity limited
        :raises ValidationError if limit is not a bool
        """
        if limit and not isinstance(limit, bool):
            raise ValidationError("Limit velocity must be a bool")
        else:
            self.set_input("limit_velocity", limit)
