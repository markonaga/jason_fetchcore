# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseBuildmap


class BuildmapAction(Action, BaseBuildmap):
    """
    The BUILDMAP action builds a new Fetchcore map as the user drives around a selected robot.
    """
    required_fields = ["mapname"]

    def __init__(
            self, id=None, action_definition="BUILDMAP", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, mapname=None, inputs=None, outputs=None, states=None,
            on_complete=None, on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(BuildmapAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, mapname=mapname, inputs=inputs, outputs=outputs, states=states, on_complete=on_complete,
            on_pause=on_pause, on_resume=on_resume, created=created, modified=modified, **kwargs
        )
