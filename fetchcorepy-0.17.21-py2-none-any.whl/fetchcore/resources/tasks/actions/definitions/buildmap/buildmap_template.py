# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseBuildmap


class BuildmapTemplate(ActionTemplate, BaseBuildmap):
    """
    The BUILDMAP action template builds a new Fetchcore map as the user drives around a selected robot.
    """
    required_fields = ["mapname"]

    def __init__(
            self, id=None, action_definition="BUILDMAP", preemptable=ActionPreemption.NONE, mapname=None, inputs=None,
            task_template=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BuildmapTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, mapname=mapname, inputs=inputs,
            created=created, modified=modified, task_template=task_template, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, **kwargs
        )
