# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError


class BaseBuildmap(RestrictedListMixin, BaseAction):
    """
    The BUILDMAP class for setting BUILDMAP action and action template inputs.
    """
    required_fields = ["mapname"]

    def __init__(
            self, id=None, action_definition="BUILDMAP", preemptable=ActionPreemption.NONE, mapname=None, inputs=None,
            created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseBuildmap, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.mapname = mapname
        else:
            self.inputs = inputs

    @property
    def mapname(self):
        """Gets the name of the map to build

        :return: The name of the map
        """
        return self.get_input("mapname")

    @mapname.setter
    def mapname(self, value):
        """Sets the name of the map to build

        :param value: (string) The name of the map
        :raises ValidationError if value is not a string
        :raises ValidationError if value is an empty string
        """
        if value and not isinstance(value, basestring):
            raise ValidationError("Map name must be a string (%s is a %s)" % (value, type(value)))
        else:
            self.set_input("mapname", value)
