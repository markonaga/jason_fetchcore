# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseURL


class URLTemplate(ActionTemplate, BaseURL):
    """
    The URL action template sends a new URL for the web browser on the HMI screen to display.
    """
    required_fields = ["url"]

    def __init__(
            self, id=None, action_definition="URL", preemptable=ActionPreemption.NONE, url=None, inputs=None,
            task_template=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(URLTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, url=url, inputs=inputs,
            created=created, modified=modified, task_template=task_template, on_complete=on_complete, on_pause=on_pause,
            on_resume=on_resume, **kwargs
        )
