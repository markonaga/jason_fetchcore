# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError


class BaseURL(RestrictedListMixin, BaseAction):
    """
    The URL class for setting URL action and action template inputs.
    """
    required_fields = ["url"]

    def __init__(
            self, id=None, action_definition="URL", preemptable=ActionPreemption.NONE, url=None, inputs=None,
            created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseURL, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.url = url
        else:
            self.inputs = inputs

    @property
    def url(self):
        """Gets the URL that will be sent to the HMI screen

        :return: The URL
        """
        return self.get_input("url")

    @url.setter
    def url(self, url):
        """Sets the URL that will be sent to the HMI screen

        :param url: (string) The URL
        :raises ValidationError if url is not a string or if url is empty or None
        """
        if url is None:
            raise ValidationError("URL must not be none")
        elif not isinstance(url, basestring):
            raise ValidationError("URL must be a string (url is %s)" % url)
        elif not url:
            raise ValidationError("URL must not be an empty string")
        self.set_input("url", url)
