# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseHMIButtons


class HMIButtonsTemplate(ActionTemplate, BaseHMIButtons):
    """
    The HMI_BUTTONS action template displays a set of configured touchscreen buttons on the HMI screen.
    """
    required_fields = ["button_names"]
    optional_fields = ["buttons_per_row", "button_data"]

    def __init__(
            self, id=None, action_definition="HMI_BUTTONS", preemptable=ActionPreemption.NONE, button_names=None,
            buttons_per_row=None, button_data=None, inputs=None, task_template=None, created=None, modified=None,
            on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(HMIButtonsTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, button_names=button_names,
            buttons_per_row=buttons_per_row, button_data=button_data, inputs=inputs, task_template=task_template,
            created=created, modified=modified, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            **kwargs
        )
