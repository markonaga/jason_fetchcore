# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class BaseHMIButtons(RestrictedListMixin, BaseAction):
    """
    The HMI_BUTTONS class for setting HMI_BUTTONS action and action template inputs.
    """
    required_fields = ["button_names"]
    optional_fields = ["buttons_per_row", "button_data"]

    def __init__(
            self, id=None, action_definition="HMI_BUTTONS", preemptable=ActionPreemption.NONE, button_names=None,
            buttons_per_row=None, button_data=None, inputs=None, created=None, modified=None, on_complete=None,
            on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseHMIButtons, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.button_names = button_names
            if buttons_per_row is not None:
                self.buttons_per_row = buttons_per_row
            if button_data is not None:
                self.button_data = button_data
        else:
            self.inputs = inputs

    @property
    def button_names(self):
        """Gets the button names for the specified action

        :return: The button names
        """
        return self.get_input("button_names")

    @button_names.setter
    def button_names(self, names):
        """Sets or creates the button names for the specified action

        :param names: (list of strings) Button names
        :raises ValidationError if names is not a list
        :raises ValidationError if any item in names is not a string
        """
        if not isinstance(names, list):
            raise ValidationError("Button names must be a list")
        try:
            # Find the first item that is not a string
            wrong_name = next(name for name in names if not isinstance(name, basestring))
            raise ValidationError("Each item in button names must be a string but %s is a %s"
                                  % (wrong_name, type(wrong_name).__name__))
        except StopIteration:
            # Cannot find any item that is not a string. Everything is good.
            pass
        self.set_input("button_names", names)

    @property
    def buttons_per_row(self):
        """Sets the number of HMI buttons per row

        :return: The number of buttons
        """
        return self.get_input("buttons_per_row")

    @buttons_per_row.setter
    def buttons_per_row(self, buttons):
        """Sets number of HMI buttons per row

        :param buttons: (integer) A positive integer
        :raises ValidationError if buttons is not an integer
        :raises ValidationError if buttons is not a positive integer
        """
        if not Number.is_integer(buttons):
            raise ValidationError("Buttons per row must be a number (buttons per row is %s)" % buttons)
        elif not Number.is_finite_positive(buttons):
            raise ValidationError("Buttons per row must be a finite positive number "
                                  "(buttons is %s)" % buttons)
        else:
            self.set_input("buttons_per_row", buttons)

    @property
    def button_data(self):
        """Gets the button data for the specified action

        :return: The button data
        """
        return self.get_input("button_data")

    @button_data.setter
    def button_data(self, data):
        """Sets or creates the button data for the specified action

        :param data: (list of strings) Button data
        :raises ValidationError if data is not a list
        :raises ValidationError if any item in data is not a string
        """
        if not isinstance(data, list):
            raise ValidationError("Button data must be a list")
        try:
            # Find the first item that is not a string
            wrong_data = next(datum for datum in data if not isinstance(datum, basestring))
            raise ValidationError("Each item in button data must be a string but %s is a %s"
                                  % (wrong_data, type(wrong_data).__name__))
        except StopIteration:
            # Cannot find any item that is not a string. Everything is good.
            pass
        self.set_input("button_data", data)
