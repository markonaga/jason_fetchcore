# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseHMIButtons


class HMIButtonsAction(Action, BaseHMIButtons):
    """
    The HMI_BUTTONS action displays a set of configured touchscreen buttons on the HMI screen.
    """
    required_fields = ["button_names"]
    optional_fields = ["buttons_per_row", "button_data"]

    def __init__(
            self, id=None, action_definition="HMI_BUTTONS", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, button_names=None, buttons_per_row=None,
            button_data=None, inputs=None, outputs=None, states=None, on_complete=None, on_pause=None, on_resume=None,
            created=None, modified=None, **kwargs
    ):
        super(HMIButtonsAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, button_names=button_names, buttons_per_row=buttons_per_row, button_data=button_data, inputs=inputs,
            outputs=outputs, states=states, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            created=created, modified=modified, **kwargs
        )
