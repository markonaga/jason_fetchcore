# Copyright 2017 Fetch Robotics Inc.
# Author(s): Niharika Arora

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BasePlaySound


class PlaySoundTemplate(ActionTemplate, BasePlaySound):
    """
    The PLAY_SOUND action template has the robot wait at its current location for a set amount of time.
    """
    required_fields = ["sound_id", "repeat", "volume"]

    def __init__(
            self, id=None, action_definition="PLAY_SOUND", preemptable=ActionPreemption.NONE, sound_id=None,
            repeat=None,
            volume=None, inputs=None, task_template=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(PlaySoundTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, sound_id=sound_id, repeat=repeat,
            volume=volume, inputs=inputs, created=created, modified=modified, task_template=task_template,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
