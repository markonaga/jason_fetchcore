# Copyright 2017 Fetch Robotics Inc.
# Author(s): Niharika Arora

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BasePlaySound


class PlaySoundAction(Action, BasePlaySound):
    """
    The PLAY_SOUND action has the robot wait at its current location for a set amount of time.
    """
    required_fields = ["sound_id", "repeat", "volume"]

    def __init__(
            self, id=None, action_definition="PLAY_SOUND", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, sound_id=None, repeat=None, volume=None, inputs=None,
            outputs=None, states=None, on_complete=None, on_pause=None, on_resume=None, created=None, modified=None,
            **kwargs
    ):
        super(PlaySoundAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, sound_id=sound_id, repeat=repeat, volume=volume, inputs=inputs, outputs=outputs, states=states,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, created=created, modified=modified,
            **kwargs
        )
