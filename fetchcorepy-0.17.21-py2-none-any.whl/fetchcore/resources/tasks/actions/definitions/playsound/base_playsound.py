# Copyright 2017 Fetch Robotics Inc.
# Author(s): Niharika Arora

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.exceptions import ValidationError
from fetchcore.utils import Number
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin


class BasePlaySound(RestrictedListMixin, BaseAction):
    """
    The PLAY_SOUND class for setting PLAY_SOUND action and action template inputs.
    """
    required_fields = ["sound_id", "repeat", "volume"]

    def __init__(
            self, id=None, action_definition="PLAY_SOUND", preemptable=ActionPreemption.NONE, sound_id=None,
            repeat=None, volume=None, inputs=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(BasePlaySound, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.sound_id = sound_id
            self.repeat = repeat
            self.volume = volume
        else:
            self.inputs = inputs

    @property
    def sound_id(self):
        """Gets the ID of the sound file to play.

        :return: The sound ID
        """
        return self.get_input("sound_id")

    @sound_id.setter
    def sound_id(self, sound_id):
        """Sets the ID of the sound file to be played

        :param sound_id: (string) The sound_id
        :raises ValidationError if sound_id is not an integer or if sound_id is None
        """
        if sound_id is None:
            raise ValidationError("Sound ID must not be none")
        elif not isinstance(sound_id, int):
            raise ValidationError("Sound ID must be an integer.")
        self.set_input("sound_id", sound_id)

    @property
    def repeat(self):
        """Gets the number of times the sound should be repeated

        :return: The number of times the sound should be repeated
        """
        return self.get_input("repeat")

    @repeat.setter
    def repeat(self, value):
        """Sets the number of times the sound should be repeated

        :param value: (integer) The number of times the sound should be repeated
        :raises ValidationError if repeat is not a number
        """
        if value and Number.is_integer(value):
            if not Number.is_finite_non_negative(value):
                raise ValidationError("Repeat must be a finite positive number (value is %s)" % value)
            self.set_input("repeat", value)
        elif value:
            raise ValidationError("Repeat must be a number (value is %s)" % value)
        self.set_input("repeat", value)

    @property
    def volume(self):
        """Gets the volume that sound should be played at

        :return: The volume
        """
        return self.get_input("volume")

    @volume.setter
    def volume(self, volume):
        """Sets the volume that sound should be played at

        :param volume: (float) The volume
        :raises ValidationError if volume is not a number
        :raises ValidationError if volume is not a non-negative finite number
        """
        if volume and not Number.is_real_number(volume):
            raise ValidationError("Volume must be a number (value is %s)" % volume)
        elif volume and not Number.is_finite_non_negative(volume):
            raise ValidationError("Volume must be a finite non-negative number "
                                  "(value is %s)" % volume)
        elif not 0 <= volume <= 1:
            raise ValidationError("Volume must be between 0 and 1 (value is %s)" % volume)
        else:
            self.set_input("volume", volume)
