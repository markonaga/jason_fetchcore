# Copyright 2017 Fetch Robotics Inc.
# Author(s): Levon Avagyan, Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard Library
from fetchcore.utils import Number

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.exceptions import ValidationError
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin


class BaseSubtask(RestrictedListMixin, BaseAction):
    """
    The SUBTASK class for setting SUBTASK action and action template inputs.
    """
    required_fields = ["task_template_id", "cascade_status"]

    def __init__(
            self, id=None, action_definition="SUBTASK", preemptable=ActionPreemption.NONE, task_template_id=None,
            cascade_status=None, inputs=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(BaseSubtask, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.task_template_id_input = task_template_id
            self.cascade_status = cascade_status
        else:
            self.inputs = inputs

    def set_values(self, key, value):
        """Saves the data that is received from the server.

        :param key: The key to save the data for.
        :param value: The value to save.
        """
        if key == 'task_template_id':
            self.__setattr__('task_template_id_input', value)
        else:
            super(BaseSubtask, self).set_values(key, value)

    # TODO (question): add _input to all other setters and getters
    @property
    def task_template_id_input(self):
        """
        Gets the id of the task template this subtask will launch

        :return: The id
        """
        return self.get_input("task_template_id")

    @task_template_id_input.setter
    def task_template_id_input(self, value):
        """
        Sets the id of the task template this subtask will launch

        :param value: (integer) The id of the task template
        :raises ValidationError if id is not an integer or if id is empty or None
        """
        if not Number.is_integer(value):
            raise ValidationError("Task Template ID must be a number (value is %s)" % value)
        elif not Number.is_finite_positive(value):
            raise ValidationError("Task Template ID must be a finite positive number (value is %s)" % value)
        self.set_input("task_template_id", value)

    @property
    def cascade_status(self):
        """
        Gets the cascade status flag

        :return: The id
        """
        return self.get_input("cascade_status")

    @cascade_status.setter
    def cascade_status(self, value):
        """
        Sets the id of the task template this subtask will launch

        :param value: (boolean) The value of the flag
        :raises ValidationError if flag is not a boolean or if the flag is empty or None
        """
        if not isinstance(value, bool):
            raise ValidationError("cascade_status must be a bool")
        self.set_input("cascade_status", value)
