# Copyright 2017 Fetch Robotics Inc.
# Author(s): Levon Avagyan

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseSubtask


class SubtaskTemplate(ActionTemplate, BaseSubtask):
    """
    The SUBTASK action template launches a subtask that was created from a task template.
    """
    required_fields = ["task_template_id", "cascade_status"]

    def __init__(
            self, id=None, action_definition="SUBTASK", preemptable=ActionPreemption.NONE, task_template_id=None,
            cascade_status=None, inputs=None, created=None, modified=None, on_complete=None,
            on_pause=None, on_resume=None, **kwargs
    ):
        super(SubtaskTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable,
            task_template_id=task_template_id, cascade_status=cascade_status, inputs=inputs,
            created=created, modified=modified, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            **kwargs
        )
