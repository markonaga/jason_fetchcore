# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseUpdate


class UpdateAction(Action, BaseUpdate):
    """
    The UPDATE action has the robot update its internal software packages.
    """
    optional_fields = ["sources", "override_sources", "keys"]

    def __init__(
            self, id=None, action_definition="UPDATE", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, sources=None, override_sources=None, keys=None,
            inputs=None, outputs=None, states=None, on_complete=None, on_pause=None, on_resume=None, created=None,
            modified=None, **kwargs
    ):
        super(UpdateAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, sources=sources, override_sources=override_sources, keys=keys, inputs=inputs,
            outputs=outputs, states=states, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume,
            created=created, modified=modified, **kwargs
        )
