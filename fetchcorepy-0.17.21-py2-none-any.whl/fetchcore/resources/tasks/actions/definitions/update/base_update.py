# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError


class BaseUpdate(RestrictedListMixin, BaseAction):
    """
    The UPDATE class for setting UPDATE action and action template inputs.
    """
    optional_fields = ["sources", "override_sources", "keys"]

    def __init__(
            self, id=None, action_definition="UPDATE", preemptable=ActionPreemption.NONE, sources=None,
            override_sources=None, keys=None, inputs=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(BaseUpdate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            if sources is not None:
                self.sources = sources
            if override_sources is not None:
                self.override_sources = override_sources
            if keys is not None:
                self.keys = keys
        else:
            self.inputs = inputs

    @property
    def sources(self):
        """Gets the apt get sources for the specified action

        :return: The apt get sources
        """
        return self.get_input("sources")

    @sources.setter
    def sources(self, sources):
        """Sets or creates the apt get sources for the specified action

        :param sources: (list of strings) Action sources
        :raises ValidationError if sources is not a list
        :raises ValidationError if any item in sources is not a string
        """
        if not isinstance(sources, list):
            raise ValidationError("Sources must be a list")
        try:
            # Find the first item that is not a string
            wrong_source = next(source for source in sources if not isinstance(source, basestring))
            raise ValidationError("Each item in sources must be a string but %s is a %s"
                                  % (wrong_source, type(wrong_source).__name__))
        except StopIteration:
            # Cannot find any item that is not a string. Everything is good.
            pass
        self.set_input("sources", sources)

    @property
    def override_sources(self):
        """Gets the variable that says whether to override the given sources

        :return: Whether to override sources
        """
        return self.get_input("override_sources")

    @override_sources.setter
    def override_sources(self, override):
        """Sets whether or not to override the given sources

        :param override: (bool) Says whether to override
        :raises ValidationError if override is not a bool
        """
        if not isinstance(override, bool):
            raise ValidationError("Override sources must be a bool")
        else:
            self.set_input("override_sources", override)

    @property
    def keys(self):
        """Sets the apt keys for the specified action

        :return: The apt keys
        """
        return self.get_input("keys")

    @keys.setter
    def keys(self, keys):
        """Sets or creates the apt keys for the specified action

        :param keys: (list of strings) Action apt keys
        :raises ValidationError if keys is not a list
        :raises ValidationError if any item in keys is not a string
        """
        if not isinstance(keys, list):
            raise ValidationError("Apt keys must be a list")
        try:
            # Find the first item that is not a string
            wrong_key = next(key for key in keys if not isinstance(key, basestring))
            raise ValidationError("Each item in apt keys must be a string but %s is a %s"
                                  % (wrong_key, type(wrong_key).__name__))
        except StopIteration:
            # Cannot find any item that is not a string. Everything is good.
            pass
        self.set_input("keys", keys)
