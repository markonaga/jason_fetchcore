# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseUpdate


class UpdateTemplate(ActionTemplate, BaseUpdate):
    """
    The UPDATE action template has the robot update its internal software packages.
    """
    optional_fields = ["sources", "override_sources", "keys"]

    def __init__(
            self, id=None, action_definition="UPDATE", preemptable=ActionPreemption.NONE, sources=None,
            override_sources=None, keys=None, inputs=None, task_template=None, created=None, modified=None,
            on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(UpdateTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, sources=sources,
            override_sources=override_sources, keys=keys, inputs=inputs, task_template=task_template, created=created,
            modified=modified, on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
