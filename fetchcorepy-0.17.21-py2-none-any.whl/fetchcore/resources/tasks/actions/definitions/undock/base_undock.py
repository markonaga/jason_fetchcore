# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError


class BaseUndock(RestrictedListMixin, BaseAction):
    """
    The UNDOCK class for setting UNDOCK action and action template inputs.
    """
    optional_fields = ["rotate_in_place"]

    def __init__(
            self, id=None, action_definition="UNDOCK", preemptable=ActionPreemption.NONE, rotate_in_place=None,
            inputs=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseUndock, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            if rotate_in_place is not None:
                self.rotate_in_place = rotate_in_place
        else:
            self.inputs = inputs

    @property
    def rotate_in_place(self):
        """Gets the variable that says whether to rotate 180 degrees

        :return: Whether to rotate
        """
        return self.get_input("rotate_in_place")

    @rotate_in_place.setter
    def rotate_in_place(self, rotate):
        """Sets whether to rotate in place

        :param rotate: (bool) Says whether to rotate
        :raises ValidationError if rotate is not a bool
        """
        if isinstance(rotate, bool):
            self.set_input("rotate_in_place", rotate)
        elif rotate in ['True', 'False']:
            self.set_input('rotate_in_place', True if rotate == 'True' else False)
        else:
            raise ValidationError("Rotate in place must be a bool.")
