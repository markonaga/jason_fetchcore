# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseUndock


class UndockAction(Action, BaseUndock):
    """
    The UNDOCK action calls the robot's undocking capability. This action assumes the robot is currently on a dock.
    """
    optional_fields = ["rotate_in_place"]

    def __init__(
            self, id=None, action_definition="UNDOCK", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, rotate_in_place=None, outputs=None, states=None,
            inputs=None, on_complete=None, on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(UndockAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, rotate_in_place=rotate_in_place, inputs=inputs, outputs=outputs, states=states,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, created=created, modified=modified,
            **kwargs
        )
