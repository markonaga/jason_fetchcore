# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import ActionTemplate
from fetchcore.resources.tasks.actions.definitions import BaseUndock


class UndockTemplate(ActionTemplate, BaseUndock):
    """
    The UNDOCK action template calls the robot's undocking capability. This template assumes the robot is
    currently on a dock.
    """
    optional_fields = ["rotate_in_place"]

    def __init__(
            self, id=None, action_definition="UNDOCK", preemptable=ActionPreemption.NONE, rotate_in_place=None,
            inputs=None, task_template=None, created=None, modified=None, on_complete=None, on_pause=None,
            on_resume=None, **kwargs
    ):
        super(UndockTemplate, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, rotate_in_place=rotate_in_place,
            inputs=inputs, task_template=task_template, created=created, modified=modified, on_complete=on_complete,
            on_pause=on_pause, on_resume=on_resume, **kwargs
        )
