# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard library
import numbers

# Fetchcore SDK Python
from fetchcore.definitions import ActionPreemption
from fetchcore.resources import BaseAction
from fetchcore.resources.tasks.actions.definitions import RestrictedListMixin
from fetchcore.exceptions import ValidationError


class BaseLocalize(RestrictedListMixin, BaseAction):
    """
    The LOCALIZE class for setting LOCALIZE action and action template inputs.
    """
    required_fields = ["pose_estimate"]

    def __init__(
            self, id=None, action_definition="LOCALIZE", preemptable=ActionPreemption.NONE, pose_estimate=None,
            inputs=None, created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs
    ):
        super(BaseLocalize, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, created=created, modified=modified,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs
        )
        if inputs is None:
            self.pose_estimate = pose_estimate
        else:
            self.inputs = inputs

    @property
    def pose_estimate(self):
        """Gets the pose that the robot is trying to localize near

        :return: The pose estimate
        """
        return self.get_input("pose_estimate")

    @pose_estimate.setter
    def pose_estimate(self, pose_estimate):
        """Sets pose that the robot is trying to localize near

        :param pose_estimate: pose dictionary
        :raises ValidationError if pose_estimate is not a dictionary with x, y, theta
        """
        if not isinstance(pose_estimate, dict):
            raise ValidationError(
                "Pose must be a dictionary (%s is %s)" % (pose_estimate, type(pose_estimate).__name__))
        elif not (isinstance(
                pose_estimate.get('x'), numbers.Number
        ) and isinstance(
            pose_estimate.get('y'), numbers.Number
        ) and isinstance(
            pose_estimate.get('theta'), numbers.Number
        )):
            raise ValidationError("Pose have x, y, and theta.")
        else:
            self.set_input("pose_estimate", pose_estimate)
