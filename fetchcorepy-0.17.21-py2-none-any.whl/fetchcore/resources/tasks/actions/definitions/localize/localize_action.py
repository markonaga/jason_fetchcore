# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Fetchcore SDK Python
from fetchcore.definitions import ActionStatus, ActionPreemption
from fetchcore.resources import Action
from fetchcore.resources.tasks.actions.definitions import BaseLocalize


class LocalizeAction(Action, BaseLocalize):
    """
    The LOCALIZE action provides an initial estimate of the robot's current position and orientation in the map.
    """
    required_fields = ["pose_estimate"]

    def __init__(
            self, id=None, action_definition="LOCALIZE", preemptable=ActionPreemption.NONE, task=None,
            status=ActionStatus.NEW, start=None, end=None, pose_estimate=None, inputs=None, outputs=None,
            states=None, on_complete=None, on_pause=None, on_resume=None, created=None, modified=None, **kwargs
    ):
        super(LocalizeAction, self).__init__(
            id=id, action_definition=action_definition, preemptable=preemptable, task=task, status=status, start=start,
            end=end, pose_estimate=pose_estimate, inputs=inputs, outputs=outputs, states=states,
            on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, created=created, modified=modified,
            **kwargs
        )
