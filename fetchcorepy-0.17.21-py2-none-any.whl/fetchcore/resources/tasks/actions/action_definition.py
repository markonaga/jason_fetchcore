# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard library
import re

# fetchcore
from fetchcore.resources import TimestampedResource
from fetchcore.definitions import VERSION_PATTERN, ROS_LAUNCH_FILE_PATTERN, ROS_MESSAGE_TYPE_PATTERN, \
    REGEX_CAPITAL_UNDERSCORE, REGEX_LOWER_CASE_UNDERSCORE_SLASHES
from fetchcore.exceptions import ValidationError


class ActionDefinition(TimestampedResource):
    """
    Action definitions contain configuration and runtime information necessary for executing an action.
    """
    endpoint = 'tasks/actions/definitions'
    pk = 'name'

    def __init__(self, id=None, name="", description=None, message_type=None, namespace=None, input_fields=None,
                 output_fields=None, state_fields=None, required_packages=None, required_config=None,
                 required_actions=None, launch_file=None, launch_file_parameters=None, map_required=True,
                 can_timeout=True, can_pause=True, can_terminate=True, force_undock=True, externally_managed=False,
                 version=None, created=None, modified=None, **kwargs):
        """
        :param int id: The resource ID of the action.
        :param str name: Name of the action.
        :param str description: Description of the action.
        :param str message_type: ROS message type for this action.
        :param str namespace: Action's ROS namespace.
        :param dict input_fields: Required fields for the action.
        :param dict output_fields: Return fields for the action.
        :param dict state_fields: The required survey fields for the action.
        :param ~__builtin__.list required_packages: Required packages for the action.
        :param ~__builtin__.list required_config: List of hardware configurations necessary for action execution.
        :param ~__builtin__.list required_actions: Required actions that must be installed before action execution.
        :param str launch_file: Launch file that launches the ActionServer.
        :param dict launch_file_parameters: The key-value pairs to run as parameters for the actions launch file.
        :param bool map_required: Whether a map is required for the action.
        :param bool can_timeout: Whether this action can time out.
        :param bool can_pause: Can this action be paused?
        :param bool can_terminate: Can this action be preempted or canceled?
        :param bool force_undock: Should a charging robot be foreced to undock first?
        :param bool externally_managed: Is this action managed by an external resource?
        :param str version: Version of this action definition.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(ActionDefinition, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name
        self.description = description
        self.message_type = message_type
        self.namespace = namespace
        self.launch_file = launch_file
        self.map_required = map_required
        self.can_timeout = can_timeout
        self.can_pause = can_pause
        self.can_terminate = can_terminate
        self.force_undock = force_undock
        self.externally_managed = externally_managed
        if required_config:
            self.required_config = required_config
        if version:
            self.version = version
        if input_fields is not None:
            self.input_fields = input_fields
        if output_fields is not None:
            self.output_fields = output_fields
        if state_fields is not None:
            self.state_fields = state_fields
        if required_packages is not None:
            self.required_packages = required_packages
        if required_actions is not None:
            self.required_actions = required_actions
        if launch_file_parameters is not None:
            self.launch_file_parameters = launch_file_parameters

    @property
    def name(self):
        """Returns the name for this action.

        :return: The name of this action.
        :rtype: str
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Sets the name for the action.

        :param str name: Name of the action.
        :raise fetchcore.exceptions.ValidationError: Thrown if name is not a string or an empty string.
        """
        try:
            if re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), name):
                self._set('name', name)
            else:
                raise ValidationError('Action name should be comprised of only capital letters and underscores.')
        except TypeError:
            raise ValidationError('Action name must be a string.')

    @property
    def description(self):
        """Returns the description for this action.

        :return: The description of this action.
        :rtype: str
        """
        return self._get("description")

    @description.setter
    def description(self, description):
        """Sets the description for the action.

        :param str description: description of the action.
        :raise fetchcore.exceptions.ValidationError: Thrown if description is not a string or an empty string.
        """
        if isinstance(description, basestring):
            self._set('description', description)
        else:
            raise ValidationError('Action description must be a string.')

    @property
    def message_type(self):
        """Gets the ROS message type for this action.

        :return: Message type for this action.
        :rtype: str
        """
        return self._get("message_type")

    @message_type.setter
    def message_type(self, message_type):
        """Sets the ROS message type for this action.

        :param str message_type: ROS message type for this action in the format package_name/ActionMessage.
        :raise fetchcore.exceptions.ValidationError: Thrown if message_type is not None, not a string or not in the
        correct format.
        """
        try:
            if message_type is None or re.match(re.compile(ROS_MESSAGE_TYPE_PATTERN), message_type):
                self._set("message_type", message_type)
            else:
                raise ValidationError("%s does not match the pattern %s." % (message_type, ROS_MESSAGE_TYPE_PATTERN))
        except TypeError:
            raise ValidationError("Action type must be a string or None.")

    @property
    def namespace(self):
        """Gets the namespace for this action.

        :return: The namespace for this action.
        :rtype: str
        """
        return self._get("namespace")

    @namespace.setter
    def namespace(self, namespace):
        """Sets the namespace for this action.

        :param str namespace: Name of the action as a string comprised of lower case letters and underscores.
        :raise fetchcore.exceptions.ValidationError: Thrown if namespace is not None, not a string or not in the
        correct format.
        """
        try:
            if namespace is None or re.match(re.compile(REGEX_LOWER_CASE_UNDERSCORE_SLASHES), namespace):
                self._set('namespace', namespace)
            else:
                raise ValidationError(
                    'Action namespace should only be comprised of lower case letters, underscores, or slashes.')
        except TypeError:
            raise ValidationError('Action namespace must be a string or None.')

    @property
    def input_fields(self):
        """Gets the input fields for this action.

        :return: The input fields.
        :rtype: dict
        """
        return self._get("input_fields")

    @input_fields.setter
    def input_fields(self, fields):
        """Sets the input fields for this action.

        :param dict fields: The input fields.
        :raise fetchcore.exceptions.ValidationError: Thrown if fields is not an array.
        """
        if not isinstance(fields, dict):
            raise ValidationError("Input fields must be a dict.")
        else:
            self._set("input_fields", fields)

    @property
    def output_fields(self):
        """Gets the return fields for this action.

        :return: The return fields.
        :rtype: dict
        """
        return self._get("output_fields")

    @output_fields.setter
    def output_fields(self, fields):
        """Sets the return fields for this action.

        :param dict fields: The return fields.
        :raise fetchcore.exceptions.ValidationError: Thrown if fields is not a dict.
        """
        if not isinstance(fields, dict):
            raise ValidationError("Return fields must be a dictionary")
        else:
            self._set("output_fields", fields)

    @property
    def state_fields(self):
        """Gets the required survey fields for the action.

        :return: The survey fields.
        :rtype: dict
        """
        return self._get("state_fields")

    @state_fields.setter
    def state_fields(self, fields):
        """Sets the required survey fields for the action.

        :param dict fields: The survey fields.
        :raise fetchcore.exceptions.ValidationError: Thrown if fields is not a dict.
        """
        if not isinstance(fields, dict):
            raise ValidationError("State fields must be a dictionary")
        else:
            self._set("state_fields", fields)

    @property
    def required_packages(self):
        """Gets the required ROS packages for this action.

        :return: The list of required ROS packages.
        :rtype: ~__builtin__.list
        """
        return self._get("required_packages")

    @required_packages.setter
    def required_packages(self, pkgs):
        """Sets the required packages for this action.

        :param ~__builtin__.list pkgs: The required packages as a list of strings.
        :raise fetchcore.exceptions.ValidationError: Thrown if pkgs is not a list or if any item in pkgs is not a
        string.
        """
        if not isinstance(pkgs, list):
            raise ValidationError("Required packages must be a list")
        try:
            # Find the first pkg that is not a string
            wrong_pkg = next(pkg for pkg in pkgs if not isinstance(pkg, basestring))
            raise ValidationError("Each item in required packages must be a string but %s is a %s"
                                  % (wrong_pkg, type(wrong_pkg).__name__))
        except StopIteration:
            # Cannot find any item that is not a string. Everything is good.
            pass
        self._set("required_packages", pkgs)

    @property
    def required_config(self):
        """Gets the required hardware configurations necessary for this action.

        :return: A list of RobotConfiguration objects.
        :rtype: ~__builtin__.list
        """
        from fetchcore.resources.robots import RobotConfiguration
        return [RobotConfiguration.load(name) for name in
                self.required_config_names] if self.required_config_names is not None else None

    @property
    def required_config_names(self):
        """Gets the required hardware configurations necessary for this action.

        :return: A list of hardware configuration names.
        :rtype: ~__builtin__.list
        """
        return self._get("required_config")

    @required_config.setter
    def required_config(self, configs):
        """Sets the required hardware configurations necessary for this action.

        :param ~__builtin__.list configs: The list of required configuration names comprised of only capital letters and
        underscores.
        :raise fetchcore.exceptions.ValidationError: Thrown if configs is not a list or if any item in configs is not
        a string in the correct format.
        """
        if configs is None:
            self._set("required_config", configs)
        else:
            if not isinstance(configs, list):
                raise ValidationError("Required configurations must be a list")
            for config in configs:
                try:
                    if not re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), config):
                        raise ValidationError(
                            'Required configuration "%s" is in the wrong format (should be comprised of only capital '
                            'letters and underscore)' % config)
                except TypeError:
                    raise ValidationError("All items in required configurations must be string (%s is a %s)."
                                          % (config, type(config).__name__))
            self._set("required_config", configs)

    @property
    def required_actions(self):
        """Gets the required actions for this action as a list of ActionDefinition objects.

        :return: A list of ActionDefinition objects.
        :rtype: ~__builtin__.list
        """
        return [ActionDefinition.load(name) for name in
                self.required_action_names] if self.required_action_names is not None else None

    @property
    def required_action_names(self):
        """Gets the names required actions that must be installed before execution of this action.

        :return: A list of required actions.
        :rtype: ~__builtin__.list
        """
        return self._get("required_actions")

    @required_actions.setter
    def required_actions(self, actions):
        """Sets the required actions that must be installed before execution of this action.

        :param ~__builtin__.list actions: The required actions.
        :raise fetchcore.exceptions.ValidationError: Thrown if actions is not a list or if any item in actions is not
        a string in the correct format.
        """
        if actions is None:
            self._set("required_actions", actions)
        else:
            if not isinstance(actions, list):
                raise ValidationError("Required actions must be a list")
            for action in actions:
                try:
                    if not re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), action):
                        raise ValidationError(
                            'Required action "%s" is in the wrong format (should be comprised of only capital '
                            'letters and underscore)' % action)
                except TypeError:
                    raise ValidationError("All items in required actions must be string (%s is a %s)."
                                          % (action, type(action).__name__))
            self._set("required_actions", actions)

    @property
    def launch_file(self):
        """Gets the ROS launch file that starts the ROS ActionServer that this action depends on.

        :return: Name of the ROS launch file.
        :rtype: str
        """
        return self._get("launch_file")

    @launch_file.setter
    def launch_file(self, launch_file):
        """Sets the ROS launch file that starts the ROS ActionServer that this action depends on.

        :param str launch_file: Name of the ROS launch file in the format package_name/launch_file_name.launch(.xml).
        :raise fetchcore.exceptions.ValidationError: Thrown if launch_file is not None, not a string or does not
            match the format.
        """
        try:
            if launch_file is None or re.match(re.compile(ROS_LAUNCH_FILE_PATTERN), launch_file):
                self._set("launch_file", launch_file)
            else:
                raise ValidationError("%s does not match the pattern %s"
                                      % (launch_file, ROS_LAUNCH_FILE_PATTERN))
        except TypeError:
            raise ValidationError("Launch file must be a string")

    @property
    def launch_file_parameters(self):
        """Gets the key-value pairs to run as parameters for this action's launch file.

        :return: The launch file parameters.
        :rtype: dict
        """
        return self._get("launch_file_parameters")

    @launch_file_parameters.setter
    def launch_file_parameters(self, parameters):
        """Sets or creates the key-value pairs to run as parameters for this action's launch file.

        :param dict parameters: Launch file parameters as a dictionary.
        :raise fetchcore.exceptions.ValidationError: Thrown if parameters is not a dict.
        """
        if not isinstance(parameters, dict):
            raise ValidationError("Launch file parameters must be a dictionary")
        else:
            self._set("launch_file_parameters", parameters)

    @property
    def map_required(self):
        """Gets whether this action requires a map to be available.

        :return: Whether this action requires a map to be available.
        :rtype: bool
        """
        return self._get("map_required")

    @map_required.setter
    def map_required(self, map_required):
        """Sets whether this action requires a map to be available.

        :param bool map_required: Whether map is required or not.
        :raise fetchcore.exceptions.ValidationError: Thrown if map_required is not a bool.
        """
        if not isinstance(map_required, bool):
            raise ValidationError("Map required must be a bool")
        else:
            self._set("map_required", map_required)

    @property
    def can_timeout(self):
        """Gets whether this action can timeout during execution.

        :return: Whether this action can timeout during execution.
        :rtype: bool
        """
        return self._get("can_timeout")

    @can_timeout.setter
    def can_timeout(self, can_timeout):
        """Sets whether this action can timeout during execution.

        :param bool can_timeout: Whether this action can timeout during execution.
        :raise fetchcore.exceptions.ValidationError: Thrown if can_timeout is not a bool.
        """
        if not isinstance(can_timeout, bool):
            raise ValidationError("Can timeout must be a bool")
        else:
            self._set("can_timeout", can_timeout)

    @property
    def can_pause(self):
        """Gets whether this action can be paused.

        :return: Whether this action can be paused
        :rtype: bool
        """
        return self._get('can_pause')

    @can_pause.setter
    def can_pause(self, can_pause):
        """Sets whether this action can be paused.

        :param bool can_pause: Whether this action can be paused.
        :raise fetchcore.exceptions.ValidationError: Thrown if can_pause is not a bool.
        """
        if not isinstance(can_pause, bool):
            raise ValidationError("Can pause must be a bool")
        else:
            self._set('can_pause', can_pause)

    @property
    def can_terminate(self):
        """Gets whether this action can be terminated during execution.

        :return: Whether this action can terminated during execution.
        :rtype: bool
        """
        return self._get('can_terminate')

    @can_terminate.setter
    def can_terminate(self, can_terminate):
        """Sets whether this action can be terminated during execution.

        :param bool can_terminate: Whether this action can be terminated during execution.
        :raise fetchcore.exceptions.ValidationError: Thrown if can_terminate is not a bool.
        """
        if not isinstance(can_terminate, bool):
            raise ValidationError("Can terminated must be a bool")
        else:
            self._set('can_terminate', can_terminate)

    @property
    def force_undock(self):
        """Gets whether this action should force an undock before execution.

        :return: Whether this action should force an undock before execution.
        :rtype: bool
        """
        return self._get('force_undock')

    @force_undock.setter
    def force_undock(self, force_undock):
        """Sets whether this action should force an undock before execution.

        :param bool force_undock: Whether this action should force an undock before execution.
        :raise fetchcore.exceptions.ValidationError: Thrown if force_undock is not a bool.
        """
        if not isinstance(force_undock, bool):
            raise ValidationError("Force undock must be a bool")
        else:
            self._set('force_undock', force_undock)

    @property
    def externally_managed(self):
        """Gets whether this action is externally manged.

        :return: Whether this action is externally manged.
        :rtype: bool
        """
        return self._get('externally_managed')

    @externally_managed.setter
    def externally_managed(self, externally_managed):
        """Sets whether this action is externally manged.

        :param bool externally_managed: Whether this action is externally manged.
        :raise fetchcore.exceptions.ValidationError: Thrown if externally_managed is not a bool.
        """
        if not isinstance(externally_managed, bool):
            raise ValidationError("externally_managed must be a bool.")
        else:
            self._set('externally_managed', externally_managed)

    @property
    def version(self):
        """Gets the version number of this action definition.

        :return: The version number of this action definition.
        :rtype: str
        """
        return self._get("version")

    @version.setter
    def version(self, version):
        """Sets the version number of this action definition.

        :param version: Version number of this action in the format "MAJOR.MINOR.PATCH".
        :raise fetchcore.exceptions.ValidationError: Thrown if version is not a string or does not have the correct
        pattern.
        """
        try:
            if re.match(re.compile(VERSION_PATTERN), version):
                self._set("version", version)
            else:
                raise ValidationError("%s does not match the pattern %s"
                                      % (version, VERSION_PATTERN))
        except TypeError:
            raise ValidationError("Version must be a string (%s is %s)"
                                  % (version, type(version).__name__))
