# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts

# Fetchcore SDK Python
from fetchcore.resources import BaseAction, ResponseTemplate
from fetchcore.resources.tasks.actions.responses.definitions import RESPONSE_TEMPLATE_CLASSES


class ActionTemplate(BaseAction):
    """
    Class for Fetchcore action templates.
    """
    # Read only fields for action
    read_only_fields = ('task_template',)

    # Required fields for input values
    required_fields = []
    # Optional fields for input values
    optional_fields = []

    endpoint = 'tasks/templates/actions'

    response_class = ResponseTemplate
    response_classes = RESPONSE_TEMPLATE_CLASSES

    def __init__(self, id=None, action_definition=None, inputs=None, preemptable=None, task_template=None,
                 created=None, modified=None, on_complete=None, on_pause=None, on_resume=None, **kwargs):
        """
        :param id: The ID of the action template.
        :param action_definition: The action definition associated with this action template.
        :param dict inputs: The input values for the action.
        :param preemptable: The preemption level of this action template.
        :param int task_template: ID of the associated task template.
        :param on_complete: The on complete responses associated with this action template.
        :param on_pause: The on pause responses associated with this action template.
        :param on_resume: The on resume responses associated with this action template.
        :param created: The date and time of this action templates's creation.
        :param modified: The date and time this action template was last modified.
        """
        super(ActionTemplate, self).__init__(id=id, action_definition=action_definition, inputs=inputs,
                                             preemptable=preemptable, created=created, modified=modified,
                                             on_complete=on_complete, on_pause=on_pause, on_resume=on_resume, **kwargs)

        if task_template:
            self._set('task_template', task_template)

    @staticmethod
    def get_action_class(action_definition):
        """Gets the class of action template by its action definition.

        :param action_definition: (string) Name of an action definition.
        :return: Class for the action template in action definition (defaults to ActionTemplate if not known).
        :rtype: Action template class
        """
        try:
            from fetchcore.resources.tasks.actions.definitions import ACTION_TEMPLATE_CLASSES
            return ACTION_TEMPLATE_CLASSES[action_definition]
        except KeyError:
            return ActionTemplate

    @classmethod
    def set_response(cls, response):
        """Loads data from the server to Action and any of its derived classes

        :param response: The data that has been received from the server
        :return: The loaded data
        """
        if cls == ActionTemplate:
            # Action is a base class so we shouldn't be using it
            # Get the right derived class
            return_cls = ActionTemplate.get_action_class(response['action_definition'])
        else:
            # The derived class called this function
            return_cls = cls
        try:
            return return_cls(**response)
        except TypeError:
            return None

    @property
    def task_template(self):
        """Gets the associated task template for the action template.

        :return: The associated task template.
        :rtype: fetchcore.resources.TaskTemplate
        """
        from fetchcore.resources import TaskTemplate
        return TaskTemplate.load(self.task_template_id)

    @property
    def task_template_id(self):
        """Gets the associated task template ID for the action template.

        :return: ID of the associated task template.
        :rtype: int
        """
        return self._get('task_template')

    def to_json_dict(self):
        """Gets the copy of the JSON document

        :return: the JSON document
        :rtype: dict
        """
        self.check_input_fields()
        return super(ActionTemplate, self).to_json_dict()
