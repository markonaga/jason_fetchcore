# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Standard library
from copy import deepcopy
import collections
import re

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource, ActionTemplate
from fetchcore.resources.robots import Robot
from fetchcore.exceptions import ValidationError, KeyWordArgumentError
from fetchcore.definitions import ROBOT_NAME_PATTERN
from fetchcore.utils import Number


class TaskTemplate(TimestampedResource):
    """
    Class for Fetchcore task templates
    """
    endpoint = 'tasks/templates'

    def __init__(self, id=None, name=None, assignable_robots=None, action_templates=None, created=None, modified=None,
                 parent=None, children=None, **kwargs):
        """
        :param integer id: The ID of the task template.
        :param str name: The human-readable name of the task template.
        :param schedules: The list of schedules associated with this task template.
        :param assignable_robots: The list of robots assigned to this task template.
        :param action_templates: The list of action templates associated with this task template
        :param created: The date and time of this task templates's creation.
        :param modified: The date and time this task template was last modified.
        :type schedules: list of int
        :type assignable_robots: list of int
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(TaskTemplate, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.name = name
        self._action_templates = []
        for action_template in action_templates or []:
            self.add_action_template(action_template)
        self.assignable_robots = assignable_robots
        self.parent = parent
        self.children = children

    @property
    def name(self):
        """Gets the human-readable name of this task template

        :return: The task template name
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Sets or creates the name of this task template

        :param name: Name of the task template
        :raises ValidationError if name is not a string
        :raises ValidationError if name is an empty string
        """
        if not isinstance(name, basestring):
            raise ValidationError("Task template name must be a string")
        elif not name:
            raise ValidationError("Task template name cannot be empty")
        else:
            self._set("name", name)

    @property
    def assignable_robot_names(self):
        """Get the list of robot names assigned to this task template.

        :return: The list of assignable robot names.
        """
        return self._get('assignable_robots')

    @assignable_robot_names.setter
    def assignable_robot_names(self, assignable_robot_names):
        """Set the list of robot names assigned to this task template.

        :param assignable_robot_names: A list of assignable robot names.
        :type assignable_robot_names: list of int
        :raise: fetchcore.exceptions.ValidationError Thrown if assignable_robot_names is not a list or if each item's
                name is not None or not a Freight's name.
        """
        if assignable_robot_names is None:
            self._set('assignable_robots', [])
        elif not isinstance(assignable_robot_names, list):
            raise ValidationError(
                "Assignable robot names must be a list, not a %s." % type(assignable_robot_names).__name__)
        else:
            for assignable_robot_name in assignable_robot_names:
                try:
                    if not re.compile(ROBOT_NAME_PATTERN).match(assignable_robot_name):
                        raise ValidationError(
                            'Only Freights can be assigned to tasks. %s does not seem to be a Freight.'
                            % assignable_robot_name)
                except TypeError:
                    raise ValidationError('Robot name can only be the name of a Freight or None.')
            self._set("assignable_robots", assignable_robot_names)

    @property
    def assignable_robots(self):
        """Get the list of robots assigned to this task template.

        :return: The list of assignable_robots as Robot objects.
        """
        return [Robot.load(assignable_robot_name) for assignable_robot_name in self.assignable_robot_names]

    @assignable_robots.setter
    def assignable_robots(self, assignable_robots):
        """Set the list of robots assigned to this task template.

        :param assignable_robots: A list of assignable robots or assignable robot
            names.
        :type assignable_robots: list of integers, list of Robots
        :raise: fetchcore.exceptions.ValidationError Thrown if assignable_robots is not a list, if each item in values
            is not a AssignableRobot object, or if each item in the list is not a finite positive integer.
        """
        if assignable_robots is None:
            self.assignable_robot_names = assignable_robots
        elif not isinstance(assignable_robots, (list, tuple)):
            raise ValidationError('Assignable robots must be either None, a list or a tuple.')
        elif not all(isinstance(assignable_robot, (basestring, Robot)) for assignable_robot in assignable_robots):
            raise ValidationError('Assignable robots must be a list of Robot objects or strings.')
        else:
            self.assignable_robot_names = [assignable_robot.name if isinstance(assignable_robot, Robot)
                                           else assignable_robot for assignable_robot in assignable_robots]

    @property
    def action_templates(self):
        """Gets a list of ActionTemplate objects

        :return: The list of action template objects
        """
        return self._action_templates

    @action_templates.setter
    def action_templates(self, value):
        """Sets a list of action template objects

        :param value: A list of dict or action template objects
        :raises ValidationError if value is not a list, or any element in the list is not a dict or an ActionTemplate
        object
        """
        if not isinstance(value, list):
            raise ValidationError("Action templates must be a list")
        elif not value:
            self._action_templates = value
        else:
            original_action_templates = self._action_templates[:]
            self.action_templates = []
            try:
                for action_template in value:
                    self.add_action_template(action_template)
            except (AttributeError, ValidationError, KeyWordArgumentError) as e:
                self._action_templates = original_action_templates
                raise e

    def add_action_template(self, action_template, pos=None):
        """
        Adds an action template to the Resource

        :param action_template: An action template object or a dict
        :param pos: Position of the action template to add to
        :raises AttributeError: if an action template is not implemented
        :raises ValidationError: if action_template is not a dict or an ActionTemplate object or derived from
            ActionTemplate
        """
        if pos is None:
            pos = len(self._action_templates)

        if isinstance(action_template, ActionTemplate):
            # If action_template is an ActionTemplate object, the user should have gone through
            # all the trouble to set attributes so no need to do any checking
            self._action_templates.insert(pos, action_template)
        elif isinstance(action_template, dict):
            # Create a deepcopy of the action so as not to mess up the input
            action_template_dict = deepcopy(action_template)
            try:
                # Get action template name
                action_template_name = action_template_dict.pop("action_definition")
            except KeyError:
                raise ValidationError("Action template does not have an action definition")
            # Get the name of the class
            action_template_class = ActionTemplate.get_action_class(action_template_name)

            # Custom action template support
            if action_template_class == ActionTemplate:
                action_template_dict['action_definition'] = action_template_name

            # Try to create an object
            self._action_templates.insert(pos, action_template_class(**action_template_dict))
        else:
            raise ValidationError("Action template should either be an Action template object or a dict, not a %s" %
                                  type(action_template).__name__)

    def pop_action_template(self, pos=None):
        """
        Removes an action template at a position or the last action template if position is not given

        :param pos: An integer
        :return: The action template that was removed
        :raises IndexError: if you attempt to pop an action template that from an index that doesn't exist
        """
        if pos is None:
            pos = len(self._action_templates) - 1
        try:
            return self._action_templates.pop(pos)
        except IndexError:
            raise IndexError(
                "Attempted to pop action template %d but there are only %d action templates"
                % (pos, len(self._action_templates)))

    @property
    def parent_id(self):
        """The ID of the task template that this template derived from.

        :return: The ID of the parent task template.
        """
        return self._get('parent')

    @property
    def parent(self):
        """The ID of the task template that this template derived from.

        :return: The ID of the parent task template.
        """
        if self.parent_id is None:
            return None
        else:
            return TaskTemplate.load(self.parent_id)

    @parent.setter
    def parent(self, parent):
        """Set the parent task template.

        :param parent: Parent task template.
        :type: None, integer, TaskTemplate
        :raises fetchcore.exceptions.ValidationError: thrown if parent is not None, a positive integer, or a
            TaskTemplate.
        """
        if parent is None or Number.is_integer(parent) and Number.is_finite_positive(parent):
            self._set('parent', parent)
        elif isinstance(parent, TaskTemplate):
            if not parent.is_set('id'):
                parent.save()
            self._set('parent', parent.id)
        else:
            raise ValidationError('Parent must be None, an positive integer, or a TaskTemplate object.')

    @property
    def children(self):
        """Task templates that derive from this task template.

        :return: List of child task template IDs.
        """
        return self._get('children')

    @children.setter
    def children(self, children):
        if children is None:
            self._set('children', [])
        elif isinstance(children, collections.Iterable) and not isinstance(children, basestring):
            [child.save() for child in children if isinstance(child, TaskTemplate) and not child.is_set('id')]
            copied = [getattr(child, 'id', child) for child in children]
            if not all(Number.is_integer(child) and Number.is_finite_positive(child) for child in copied):
                raise ValidationError('Children must be a list of TaskTemplate objects or positive integers.')
            self._set('children', copied)
        else:
            raise ValidationError('Children must be a list or None.')

    def to_json_dict(self):
        """Gets the task template document as a json dictionary

        :return: The JSON dictionary
        """
        # Get json dict from each action template
        action_template_json = [action_template.to_json_dict() for action_template in self._action_templates]
        self._set("action_templates", action_template_json)
        return super(TaskTemplate, self).to_json_dict()
