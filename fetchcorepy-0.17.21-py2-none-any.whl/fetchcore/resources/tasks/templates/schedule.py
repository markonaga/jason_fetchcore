# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Russell Toris, Rushane Hua

# Futures
from __future__ import unicode_literals

# fetchcore
from fetchcore.resources import TimestampedResource
from fetchcore.definitions import RepeatTypes, Weekdays
from fetchcore.utils import Timestamp, Number, Duration
from fetchcore.exceptions import ValidationError


class Schedule(TimestampedResource):
    """
    Schedules contain information about when associated tasks templates should run.
    """

    # The endpoint in fetchcore for schedules.
    endpoint = 'tasks/templates/schedules'

    def __init__(self, id=None, name=None, task_templates=None, enabled=False, repeat=None, frequency=1, weekdays=None,
                 number_agents_required=None, start=None, end=None, duration=None, created=None, modified=None,
                 **kwargs):
        """
        :param int id: The ID of the schedule (assigned automatically upon creation).
        :param str name: The human-readable name of the schedule.
        :param task_templates: The associated task templates.
        :param boolean enabled: If this schedule is enabled and should schedule tasks.
        :param RepeatType repeat: The repeatableness of the schedule.
        :param int frequency: The repeat frequency of the schedule (e.g., every 2 days).
        :param weekdays: The days of the week this schedule can operate on.
        :param int number_agents_required: The number of required agents running this schedule concurrently.
        :param start: The timestamp for the first scheduled instance.
        :param end:  The timestamp for the last scheduled instance
        :param duration: The duration that this is valid for scheduling.
        :param created: The date and time of this schedule's creation (assigned automatically).
        :param modified: The date and time this schedule was last modified (updated automatically).
        :type task_templates: list of int, list of TaskTemplate
        :type start: str, ~datetime.datetime
        :type end: str, ~datetime.datetime
        :type duration: str, ~datetime.timedelta
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        :type weekdays: list of Weekdays
        """
        super(Schedule, self).__init__(id=id, created=created, modified=modified, **kwargs)

        # Required fields first
        self.enabled = enabled
        self.repeat = repeat
        self.frequency = frequency
        self.number_agents_required = number_agents_required
        self.start = start
        self.duration = duration

        self.name = name
        self.task_templates = task_templates
        self.weekdays = weekdays
        self.end = end

    # TODO: should this return None if it does not exist?
    @property
    def name(self):
        """Get the human-readable name of the schedule.

        :return: The schedule name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """Set the human-readable name of the schedule

        :param string name The schedule name.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is not a string or if value is an empty string.
        """
        if name is None:
            self._set('name', name)
        elif isinstance(name, basestring):
            # Server does not allow name to be blank (but it can be null)
            if not name:
                raise ValidationError("Schedule name cannot be empty.")
            self._set('name', name)
        else:
            raise ValidationError("Schedule name must be a string, not a %s." % type(name).__name__)

    @property
    def task_template_ids(self):
        """Get the associated task template IDs for this schedule.

        :return: The list of task template IDs.
        """
        return self._get('task_templates')

    @task_template_ids.setter
    def task_template_ids(self, task_template_ids):
        """Set the associated task templates IDs for this schedule.

        :param task_template_ids: A list of task template IDs.
        :type task_template_ids: list of int
        :raise: ValidationError: Thrown if task_template_ids is not a list, if each item's ID
                is not an integer, or if each item's ID in the list is not a finite positive integer.
        """
        if task_template_ids is None:
            self._set('task_templates', [])
        elif not isinstance(task_template_ids, list):
            raise ValidationError("Task template ids must be a list, not a %s." % type(task_template_ids).__name__)
        else:
            task_template_ids = list(set(task_template_ids))
            for task_template_id in task_template_ids:
                if not Number.is_integer(task_template_id):
                    raise ValidationError("Each item in task template IDs must be an int (%s is %s)."
                                          % (task_template_id, type(task_template_id).__name__))
                elif not Number.is_finite_positive(task_template_id):
                    raise ValidationError(
                        "Each item in task template IDs must be finite positive (item is %s)." % task_template_id)
            self._set('task_templates', task_template_ids)

    @property
    def task_templates(self):
        """Get the associated task template for this schedule.

        :return: The list of task templates as TaskTemplate objects.
        """
        from .task_template import TaskTemplate
        return [TaskTemplate.load(task_template_id) for task_template_id in self.task_template_ids]

    @task_templates.setter
    def task_templates(self, task_templates):
        """Set the associated task templates for this schedule.

        :param task_templates: (list of integers|list of TaskTemplates) A list of task templates or task template IDs.
        :raise: fetchcore.exceptions.ValidationError Thrown if task_templates is not a list, if each item in values
                is not an integer, or if each item in the list is not a finite positive integer.
        """
        from .task_template import TaskTemplate
        if task_templates is None:
            self.task_template_ids = task_templates
        elif not isinstance(task_templates, (list, tuple)):
            raise ValidationError('Task templates must be either None, a list or a tuple.')
        elif not all(isinstance(task_template, (int, TaskTemplate)) for task_template in task_templates):
            raise ValidationError('Task templates must be a list of TaskTemplate objects or integers.')
        else:
            for task_template in task_templates:
                if isinstance(task_template, TaskTemplate) and not hasattr(task_template, 'id'):
                    task_template.save()
            self.task_template_ids = [task_template.id if isinstance(task_template, TaskTemplate) else task_template
                                      for task_template in task_templates]

    @property
    def enabled(self):
        """Get if this schedule is enabled and should schedule tasks.

        :return: Whether this schedule is enabled.
        """
        return self._get('enabled')

    @enabled.setter
    def enabled(self, enabled):
        """Set if this schedule is enabled and should schedule tasks.

        :param boolean enabled: Says whether schedule is enabled.
        :raise fetchcore.exceptions.ValidationError: Thrown if enabled is not a boolean.
        """
        if not isinstance(enabled, bool):
            raise ValidationError("Enabled must be a bool, not a %s." % type(enabled).__name__)
        else:
            self._set('enabled', enabled)

    @property
    def repeat(self):
        """Get the repeatableness of the schedule.

        :return: How often to repeat the schedule.
        """
        return self._get('repeat')

    @repeat.setter
    def repeat(self, repeat):
        """Set the repeatableness of the schedule.

        :param RepeatType repeat: How often to repeat the schedule.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is not in RepeatTypes
        """
        if repeat in RepeatTypes.values():
            self._set('repeat', repeat)
        else:
            raise ValidationError("%s is not an allowed repeat type (%s)." % (repeat, ', '.join(RepeatTypes.values())))

    @property
    def frequency(self):
        """Get the repeat frequency of the schedule (e.g., every 2 days).

        :return: The schedule repeat frequency.
        """
        return self._get('frequency')

    @frequency.setter
    def frequency(self, frequency):
        """Set the repeat frequency of the schedule (e.g., every 2 days).

        :param int frequency: The schedule repeat frequency.
        :raise: fetchcore.exceptions.ValidationError: Thrown if frequency is not a finite positive integer.
        """
        if Number.is_integer(frequency):
            if not Number.is_finite_positive(frequency):
                raise ValidationError("Frequency must be a finite positive number (frequency is %s)." % frequency)
            self._set('frequency', frequency)
        else:
            raise ValidationError("Frequency must be an int (frequency is %s)." % frequency)

    # TODO: should this return None if it does not exist?
    @property
    def weekdays(self):
        """Get the days of the week this schedule can operate on.

        :return: The days of the week.
        """
        return self._get('weekdays')

    @weekdays.setter
    def weekdays(self, weekdays):
        """Set the days of the week this schedule can operate on.

        :param weekdays: (list of Weekdays) The days of the week.
        :raise: fetchcore.exceptions.ValidationError: Thrown if values is not a list, or if each item in weekdays is not
                a value in the enum Weekdays.
        """
        if weekdays is None:
            self._set('weekdays', weekdays)
        elif not isinstance(weekdays, list):
            raise ValidationError("Weekdays must be a list not a %s." % type(weekdays).__name__)
        else:
            incorrect = [str(weekday) for weekday in weekdays if weekday not in Weekdays.values()]
            if incorrect:
                raise ValidationError("[%s] are not an allowed weekdays (%s)."
                                      % (', '.join(incorrect), ', '.join(Weekdays.values())))
            self._set('weekdays', weekdays)

    @property
    def number_agents_required(self):
        """Get the number of required agents running this schedule concurrently.

        :return: The number of required agents.
        """
        return self._get('number_agents_required')

    @number_agents_required.setter
    def number_agents_required(self, number_agents_required):
        """Set the number of required agents running this schedule concurrently.

        :param int number_agents_required: The number of required agents.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is not a positive finite integer.
        """
        if Number.is_integer(number_agents_required):
            if not Number.is_finite_positive(number_agents_required):
                raise ValidationError("Number agents required must be a finite positive number "
                                      "(number agents required is %s)." % number_agents_required)
            self._set('number_agents_required', number_agents_required)
        else:
            raise ValidationError("Number agents required must be an int (number required is %s)." %
                                  number_agents_required)

    @property
    def start(self):
        """Get the timestamp for the first scheduled instance (as a datetime).

        :return: The start timestamp.
        """
        return self._get('start')

    @start.setter
    def start(self, start):
        """Set the timestamp for the first scheduled instance.

        :param start: The start timestamp.
        :type start: str, ~datetime.datetime
        :raise ~fetchcore.exceptions.ValidationError: Thrown if the timestamp is not a string or cannot be parsed.
        """
        try:
            self._set('start', Timestamp.to_datetime(start))
        except (TypeError, ValueError) as e:
            raise ValidationError(e)

    # TODO: should this return None if it does not exist?
    @property
    def end(self):
        """Get the timestamp for the last scheduled instance (as a datetime).

        :return: The end timestamp.
        """
        return self._get('end')

    @end.setter
    def end(self, end):
        """Set the timestamp for the last scheduled instance

        :param end: The end timestamp.
        :type end: str, ~datetime.datetime
        :raise: ~fetchcore.exceptions.ValidationError Thrown if the timestamp is not a string or cannot be parsed.
        """
        if end is None:
            self._set('end', end)
        else:
            try:
                self._set('end', Timestamp.to_datetime(end))
            except (TypeError, ValueError) as e:
                raise ValidationError(e)

    @property
    def duration(self):
        """Get the duration as a datetime.timedelta object that this is valid for scheduling.

        :return: The schedule duration.
        """
        return self._get('duration')

    @duration.setter
    def duration(self, duration):
        """Set the duration as a string that this is valid for scheduling.

        :param value: The schedule duration as a string in the form [%d ]%H:%M:%S or as a
            ~datetime.timedelta object.
        :type value: str, ~datetime.timedelta
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is not a positive finite integer.
        """
        try:
            duration = Duration.to_timedelta(duration)
        except (ValueError, TypeError) as e:
            raise ValidationError(e)

        if duration.total_seconds() < 0:
            raise ValidationError('Duration must be positive.')
        self._set('duration', duration)
