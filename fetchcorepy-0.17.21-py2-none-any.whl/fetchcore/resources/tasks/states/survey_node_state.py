# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import SurveyStates
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class SurveyNodeState(TimestampedResource):
    """
    Class for fetchcore survey node states.
    """
    endpoint = 'tasks/actions/states/survey/nodes'

    @staticmethod
    def endpoint_by_survey_state_id(id):
        return 'tasks/actions/states/survey/%s/nodes' % id

    def __init__(
            self, id=None, survey_state=None, survey_node=None, state=None, created=None, modified=None, **kwargs):
        """
        :param id: The ID of the survey node.
        :param survey_state: The survey state that this node belongs to.
        :param survey_node: The survey node that this state represents.
        :param state: The current state of the node (SUCCEEDED or FAILED).
        :param created: The date and time of this survey node's creation.
        :param modified: The date and time this survey node was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(SurveyNodeState, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.survey_state = survey_state
        self.state = state
        if survey_node:
            self.survey_node = survey_node

    @property
    def survey_state_id(self):
        """Get the survey state ID that this node belongs to.

        :return: The survey state ID.
        """
        return self._get('survey_state')

    @survey_state_id.setter
    def survey_state_id(self, survey_state_id):
        """Set the survey state ID that this node belongs to.

        :param integer survey_state_id: The survey_state ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_state_id not a finite positive integer.
        """
        if Number.is_integer(survey_state_id):
            if not Number.is_finite_positive(survey_state_id):
                raise ValidationError("Survey state ID must be finite positive (item is %s)." % survey_state_id)
            self._set('survey_state', survey_state_id)
        else:
            raise ValidationError("Survey state ID must be an integer (%s is %s)."
                                  % (survey_state_id, type(survey_state_id).__name__))

    @property
    def survey_state(self):
        """Get the survey state object that this node belongs to.

        :return: The Map object.
        """
        from fetchcore.resources import SurveyState
        return SurveyState.load(self.survey_state_id)

    @survey_state.setter
    def survey_state(self, survey_state):
        """Set the survey state object that this node belongs to.

        :param survey_state: (integer|SurveyState) A survey state object or survey state ID.
        :type survey_state: int, SurveyState
        :raise fetchcore.exceptions.ValidationError: Thrown if survey state is not a survey state object or an integer.
        """
        from fetchcore.resources import SurveyState
        if isinstance(survey_state, SurveyState):
            if not survey_state.is_set("id"):
                survey_state.save()
            self.survey_state_id = survey_state.id
        elif isinstance(survey_state, int):
            self.survey_state_id = survey_state
        else:
            raise ValidationError('Survey state can only be an integer or SurveyState (%s is %s).'
                                  % (survey_state, type(survey_state).__name__))

    @property
    def state(self):
        """Gets the current state of the node (SUCCEEDED or FAILED).

        :return: The state
        :rtype: str
        """
        return self._get("state")

    @state.setter
    def state(self, state):
        """Sets the current state of the node (SUCCEEDED or FAILED).

        :param str state: A survey state
        :raises fetchcore.exceptions.ValidationError: Thrown if state is not in the list of survey states
        """
        if state in SurveyStates.values():
            self._set("state", state)
        else:
            raise ValidationError("%s is not an allowed survey state (%s)" % (state, ", ".join(SurveyStates.values())))

    @property
    def survey_node_id(self):
        """Gets the survey node ID that this state represents.

        :return: (integer) The resource ID of the survey node.
        """
        return self._get('survey_node')

    @survey_node_id.setter
    def survey_node_id(self, id):
        """Sets the survey node ID that this state represents.

        :param id: (integer) The resource id of the survey node.
        :raise fetchcore.exceptions.ValidationError: Thrown if id is not None or a positive integer.
        """
        if id is None:
            self._set("survey_node", id)
        elif Number.is_integer(id):
            if not Number.is_finite_positive(id):
                raise ValidationError("Survey node ID must be a finite positive number or None (value is %s)" % id)
            self._set("survey_node", id)
        else:
            raise ValidationError("Survey node ID must be a number or None (value is %s)" % id)

    @property
    def survey_node(self):
        """Gets the survey node that this state represents.

        :return: (Schedule) The survey node as a SurveyNode object.
        """
        from fetchcore.resources.maps import SurveyNode
        return None if self.survey_node_id is None else SurveyNode.load(self.survey_node_id)

    @survey_node.setter
    def survey_node(self, survey_node):
        """Sets the survey node that this state represents.

        :param survey_node: (integer|SurveyNode|None) The associated survey node.
        :raise fetchcore.exception.ValidationError: Thrown if value is not an integer, a SurveyNode object, or None.
        """
        from fetchcore.resources.maps import SurveyNode
        if isinstance(survey_node, SurveyNode):
            if not survey_node.is_set("id"):
                raise ValidationError('Survey node must already have an ID.')
            self.survey_node_id = survey_node.id
        elif survey_node is None or isinstance(survey_node, int):
            self.survey_node_id = survey_node
        else:
            raise ValidationError('Survey node can only be an integer, SurveyNode or None (%s is %s).'
                                  % (survey_node, type(survey_node).__name__))
