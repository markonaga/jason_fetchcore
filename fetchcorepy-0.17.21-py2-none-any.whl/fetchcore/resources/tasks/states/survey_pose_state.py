# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.definitions import SurveyStates
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError


class SurveyPoseState(TimestampedResource):
    """
    Class for fetchcore survey pose states.
    """
    endpoint = 'tasks/actions/states/survey/poses'

    @staticmethod
    def endpoint_by_survey_state_id(id):
        return 'tasks/actions/states/survey/%s/poses' % id

    def __init__(
            self, id=None, survey_state=None, survey_pose=None, state=None, created=None, modified=None, **kwargs):
        """
        :param id: The ID of the survey pose.
        :param survey_state: The survey state that this pose belongs to.
        :param survey_pose: The survey pose that this state represents.
        :param state: The current state of the pose (SUCCEEDED or FAILED).
        :param created: The date and time of this survey pose's creation.
        :param modified: The date and time this survey pose was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(SurveyPoseState, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.survey_state = survey_state
        self.state = state
        if survey_pose:
            self.survey_pose = survey_pose

    @property
    def survey_state_id(self):
        """Get the survey state ID that this pose belongs to.

        :return: The survey state ID.
        """
        return self._get('survey_state')

    @survey_state_id.setter
    def survey_state_id(self, survey_state_id):
        """Set the survey state ID that this pose belongs to.

        :param integer survey_state_id: The survey_state ID.
        :raise fetchcore.exceptions.ValidationError: Thrown if survey_state_id not a finite positive integer.
        """
        if Number.is_integer(survey_state_id):
            if not Number.is_finite_positive(survey_state_id):
                raise ValidationError("Survey state ID must be finite positive (item is %s)." % survey_state_id)
            self._set('survey_state', survey_state_id)
        else:
            raise ValidationError("Survey state ID must be an integer (%s is %s)."
                                  % (survey_state_id, type(survey_state_id).__name__))

    @property
    def survey_state(self):
        """Get the survey state object that this pose belongs to.

        :return: The Map object.
        """
        from fetchcore.resources import SurveyState
        return SurveyState.load(self.survey_state_id)

    @survey_state.setter
    def survey_state(self, survey_state):
        """Set the survey state object that this pose belongs to.

        :param survey_state: (integer|SurveyState) A survey state object or survey state ID.
        :type survey_state: int, SurveyState
        :raise fetchcore.exceptions.ValidationError: Thrown if survey state is not a survey state object or an integer.
        """
        from fetchcore.resources import SurveyState
        if isinstance(survey_state, SurveyState):
            if not survey_state.is_set("id"):
                survey_state.save()
            self.survey_state_id = survey_state.id
        elif isinstance(survey_state, int):
            self.survey_state_id = survey_state
        else:
            raise ValidationError('Survey state can only be an integer or SurveyState (%s is %s).'
                                  % (survey_state, type(survey_state).__name__))

    @property
    def state(self):
        """Gets the current state of the pose (SUCCEEDED or FAILED).

        :return: The state
        :rtype: str
        """
        return self._get("state")

    @state.setter
    def state(self, state):
        """Sets the current state of the pose (SUCCEEDED or FAILED).

        :param str state: A survey state
        :raises fetchcore.exceptions.ValidationError: Thrown if state is not in the list of survey states
        """
        if state in SurveyStates.values():
            self._set("state", state)
        else:
            raise ValidationError("%s is not an allowed survey state (%s)" % (state, ", ".join(SurveyStates.values())))

    @property
    def survey_pose_id(self):
        """Gets the survey pose ID that this state represents.

        :return: (integer) The resource ID of the survey pose.
        """
        return self._get('survey_pose')

    @survey_pose_id.setter
    def survey_pose_id(self, id):
        """Sets the survey pose ID that this state represents.

        :param id: (integer) The resource id of the survey pose.
        :raise fetchcore.exceptions.ValidationError: Thrown if id is not None or a positive integer.
        """
        if id is None:
            self._set("survey_pose", id)
        elif Number.is_integer(id):
            if not Number.is_finite_positive(id):
                raise ValidationError("Survey pose ID must be a finite positive number or None (value is %s)" % id)
            self._set("survey_pose", id)
        else:
            raise ValidationError("Survey pose ID must be a number or None (value is %s)" % id)

    @property
    def survey_pose(self):
        """Gets the survey pose that this state represents.

        :return: (Schedule) The survey pose as a SurveyPose object.
        """
        from fetchcore.resources.maps import SurveyPose
        return None if self.survey_pose_id is None else SurveyPose.load(self.survey_pose_id)

    @survey_pose.setter
    def survey_pose(self, survey_pose):
        """Sets the survey pose that this state represents.

        :param survey_pose: (integer|SurveyPose|None) The associated survey pose.
        :raise fetchcore.exception.ValidationError: Thrown if value is not an integer, a SurveyPose object, or None.
        """
        from fetchcore.resources.maps import SurveyPose
        if isinstance(survey_pose, SurveyPose):
            if not survey_pose.is_set("id"):
                raise ValidationError('Survey pose must already have an ID.')
            self.survey_pose_id = survey_pose.id
        elif survey_pose is None or isinstance(survey_pose, int):
            self.survey_pose_id = survey_pose
        else:
            raise ValidationError('Survey pose can only be an integer, SurveyPose or None (%s is %s).'
                                  % (survey_pose, type(survey_pose).__name__))
