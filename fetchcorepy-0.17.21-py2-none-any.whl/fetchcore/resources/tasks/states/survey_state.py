# Copyright 2017 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Futures
from __future__ import unicode_literals

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class SurveyState(TimestampedResource):
    """
    Class for fetchcore survey states.
    """
    endpoint = 'tasks/actions/states/survey'

    read_only_fields = ['survey_pose_states', 'survey_node_states']

    def __init__(
            self, id=None, action=None, survey_pose_states=None, survey_node_states=None, created=None, modified=None,
            **kwargs):
        """
        :param id: The ID of the survey state.
        :param action: The action that this state belongs to.
        :param survey_pose_states: The survey poses associated with this survey state.
        :param survey_node_states: The survey nodes associated with this survey state.
        :param created: The date and time of this survey state's creation.
        :param modified: The date and time this survey state was last modified.
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(SurveyState, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.action = action
        if survey_pose_states is None:
            self._set('survey_pose_states', [])
        elif not isinstance(survey_pose_states, list):
            raise ValidationError("Survey poses must be a list, not a %s." % type(survey_pose_states).__name__)
        else:
            self._set('survey_pose_states', survey_pose_states)
        if survey_node_states is None:
            self._set('survey_node_states', [])
        elif not isinstance(survey_node_states, list):
            raise ValidationError("Survey nodes must be a list, not a %s." % type(survey_node_states).__name__)
        else:
            self._set('survey_node_states', survey_node_states)

    @property
    def survey_pose_states(self):
        """Get the survey poses associated with this survey state.

        :return: The survey poses.
        """
        return self._get("survey_pose_states")

    @property
    def survey_node_states(self):
        """Get the survey nodes associated with this survey state.

        :return: The survey nodes.
        """
        return self._get("survey_node_states")

    @property
    def action_id(self):
        """Gets the action ID that this survey state belongs to.

        :return: (integer) The action ID of the survey state.
        """
        return self._get('action')

    @action_id.setter
    def action_id(self, id):
        """Sets the action ID that this survey state belongs to.

        :param id: (integer) The action id of the survey state.
        :raise fetchcore.exceptions.ValidationError: Thrown if id is not a positive integer.
        """
        if Number.is_integer(id):
            if not Number.is_finite_positive(id):
                raise ValidationError("Action ID must be a finite positive number (value is %s)" % id)
            self._set("action", id)
        else:
            raise ValidationError("Action ID must be a number (value is %s)" % id)

    @property
    def action(self):
        """Gets the action that this survey state belongs to.

        :return: (SurveyAction) The action as a SurveyAction object.
        """
        from fetchcore.resources.tasks.actions.definitions import SurveyAction
        return SurveyAction.load(self.action_id)

    @action.setter
    def action(self, action):
        """Sets the action that this survey state belongs to.

        :param action: (integer|SurveyAction) The associated survey action.
        :raise fetchcore.exception.ValidationError: Thrown if value is not an integer or a SurveyAction object.
        """
        from fetchcore.resources.tasks.actions.definitions import SurveyAction
        if isinstance(action, SurveyAction):
            if not action.is_set("id"):
                raise ValidationError('Action must already have an ID.')
            self.action_id = action.id
        elif isinstance(action, int):
            self.action_id = action
        else:
            raise ValidationError('Action can only be an integer or a SurveyAction (%s is %s).'
                                  % (action, type(action).__name__))

    @classmethod
    def list(cls, client=None, page=None, offset=None, amount=None):
        """Overwrites base class list. Survey state cannot be listed on the server.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :param page: The optional page to load.
        :param offset: The first n elements to skip when loading.
        :param amount: The number of elements to load (set to any negative integer to try to load all of them).
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation('Listing survey states is unsupported by Fetchcore.')
