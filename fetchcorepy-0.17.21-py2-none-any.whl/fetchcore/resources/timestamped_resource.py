# Copyright 2016 Fetch Robotics Inc.
# Author(s): Rushane Hua, Cappy Pitts, Russell Toris

# Futures
from __future__ import unicode_literals

# Fetchcore
from fetchcore import exceptions
from fetchcore.resources import Resource
from fetchcore.utils import Timestamp


class TimestampedResource(Resource):
    """
    Base class for all timestamped fetchcore resources.
    """

    def __init__(self, id=None, created=None, modified=None, **kwargs):
        """Creates a new Resource with the given optional arguments.

        :param int id: The ID of the resource (assigned automatically upon creation).
        :param created: The created timestamp (assigned automatically).
        :param modified: The modification timestamp (updated automatically).
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(TimestampedResource, self).__init__(id=id)

        try:
            if created:
                self._set('created', Timestamp.to_datetime(created))
            if modified:
                self._set('modified', Timestamp.to_datetime(modified))
        except (TypeError, ValueError) as e:
            raise exceptions.ValidationError(e)

    @property
    def created(self):
        """Date and time this resource was created.

        :return: The date and time this resource was created.
        """
        return self._get('created')

    @property
    def modified(self):
        """Date and time this resource was last modified.

        :return: The date and time this resource was last modified.
        """
        return self._get('modified')

    def set_values(self, key, value):
        """Saves the data that is received from the server.

        :param key: The key to save the data for.
        :param value: The value to save.
        """
        if key == 'created' or key == 'modified':
            try:
                self._set(key, Timestamp.to_datetime(value))
            except (TypeError, ValueError) as e:
                raise exceptions.ValidationError(e)
        elif key == 'id':
            self._set(key, value)
        elif key in self.read_only_fields:
            self._set(key, value)
        else:
            self.__setattr__(key, value)

    def save(self, client=None):
        """Save the current resource to the server. If the resource does not yet exist, it will be created. If it
        already exists all fields on the server will be overwritten with the current values.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        try:
            return super(TimestampedResource, self).save(client)
        except exceptions.DoesNotExist as e:
            self._set('created', None)
            self._set('modified', None)
            raise e

    def update(self, client=None):
        """Update the resource on the server with fields changed for the current resource since the last update call.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource does not exist on the server (updates only).
        :raise UnsupportedOperation: Thrown if the saves are not supported for this resource.
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        try:
            return super(TimestampedResource, self).update(client)
        except exceptions.DoesNotExist as e:
            self._set('created', None)
            self._set('modified', None)
            raise e

    def delete(self, client=None):
        """Delete this resource from the server. The resource's ID must be set for this operation to work.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise ValidationError: Thrown if there was an issue validating the data on the server.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise UnsupportedOperation: Thrown if DELETE is not allowed or the resource doesn't exist.
        :raise InternalServerError: Thrown if the server responds with an error.
        """

        try:
            super(TimestampedResource, self).delete(client)
        except exceptions.DoesNotExist as e:
            self._set('created', None)
            self._set('modified', None)
            raise e

        # TODO: Add actual destructor? I don't think it's necessary or done in most modules anyway
        # Safe removal of ID, created, and modified
        self._pop('created')
        self._pop('modified')

    def refresh(self, client=None):
        """Refresh this resource instance with the latest data from the server.

        :param client: The client that should be used (if None, the global fetchcore client is used).
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        :raise DoesNotExist: Thrown if the resource longer exists on the server (updates only).
        :raise InternalServerError: Thrown if the server responds with an error.
        """
        try:
            super(TimestampedResource, self).refresh(client)
        except exceptions.DoesNotExist as e:
            self._set('created', None)
            self._set('modified', None)
            raise e

    @staticmethod
    def __validate_client(client):
        """Validate the given fetchcore client and throw an exception if there are connection issues.

        :param client: The client to validate.
        :raise ConnectionError: Thrown if a connection to fetchcore cannot be made.
        """
        if client is None:
            raise exceptions.ConnectionError("Client is not configured correctly. Check global client settings.")
        client.connect()
