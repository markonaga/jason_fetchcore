# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Russell Toris

# Futures
from __future__ import unicode_literals

# Standard Library
import re

# fetchcore
from .group import Group
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number
from fetchcore.definitions import REGEX_EMAIL
from fetchcore import exceptions

INVALID_PASSWORD = 123


class User(TimestampedResource):
    """
    The model for fetchcore users
    """

    # The endpoint in fetchcore for users.
    endpoint = 'users'

    pk = 'id'

    def __init__(self, id=None, email=None, first_name=None, last_name=None, password=None, groups=None,
                 created=None, modified=None, **kwargs):
        """
        :param int id: The ID of the user (assigned automatically upon creation).
        :param str email: The human-readable name of the user.
        :param str first_name: The user's first name.
        :param str last_name: The user's last name.
        :param str password: The user's password.
        :param groups: The user's groups
        :param created: The date and time of this user's latest login (updated automatically).
        :param modified: The date and time this user joined (updated automatically).
        :type groups: list of int, list of Group
        :type created: str, ~datetime.datetime
        :type modifed: str, ~datetime.datetime
        """
        super(User, self).__init__(id=id, created=created, modified=modified, **kwargs)

        # Required fields
        self.email = email
        self.password = password

        # Optional fields
        if first_name is not None:
            self.first_name = first_name
        if last_name is not None:
            self.last_name = last_name
        if groups is not None:
            self.groups = groups

    @classmethod
    def set_response(cls, response):
        """Loads data from the server to User

        :param response: The data that has been received from the server
        :return: The loaded data
        """
        # Password is write only so when you load data from the server password is not included
        # As a result you can set password to something invalid (i.e. a number) and its setter will take the invalid
        # data and set password equal to None
        # TODO: Add try-except for NoneType response?
        return cls(password=INVALID_PASSWORD, **response)

    @property
    def email(self):
        """Get the human-readable name of the user.
        :return: The user's name.
        """
        return self._get('email')

    @email.setter
    def email(self, email):
        """Set the email of the user.

        :param username: (string) The user's email.
        :raise: fetchcore.exceptions.ValidationError: Thrown if email is not a string or if email is empty.
        """
        try:
            if re.match(REGEX_EMAIL, email):
                self._set("email", email)
            else:
                raise exceptions.ValidationError("Email must have the format of an email but, %s does not" % email)
        except TypeError:
            raise exceptions.ValidationError("Email must be a string")

    # TODO: should this return None if it does not exist?
    @property
    def first_name(self):
        """Get the first name of the user.

        :return: The user's first name.
        """
        return self._get('first_name')

    @first_name.setter
    def first_name(self, first_name):
        """Set the first name of the user

        :param first_name: (string) The user's first name.
        :raise: fetchcore.exceptions.ValidationError: Thrown if first_name is not a string.
        """
        if first_name is None or not first_name:
            self._set('first_name', None)
        elif isinstance(first_name, basestring):
            self._set('first_name', first_name)
        else:
            raise exceptions.ValidationError("First name must be a string, not a %s." % type(first_name).__name__)

    # TODO: should this return None if it does not exist?
    @property
    def last_name(self):
        """Get the last name of the user.

        :return: The user's last name.
        """
        return self._get('last_name')

    @last_name.setter
    def last_name(self, last_name):
        """Set the last name of the user.

        :param last_name: (string) The user's last name.
        :raise: fetchcore.exceptions.ValidationError: Thrown if last_name is not a string.
        """
        if last_name is None or not last_name:
            self._set('last_name', None)
        elif isinstance(last_name, basestring):
            self._set('last_name', last_name)
        else:
            raise exceptions.ValidationError("Last name must be a string, not a %s." % type(last_name).__name__)

    @property
    def password(self):
        """
        :raises: AttributeError: Thrown if the user's password is accessed
        """
        raise AttributeError("Cannot get user's password")

    @password.setter
    def password(self, password):
        """Set the user's password.
        :param password: (string) The user's password.
        :raise: fetchcore.exceptions.ValidationError: Thrown if password is not a string or if password is empty.
        """
        if password == INVALID_PASSWORD:
            self._set('password', None)
        elif isinstance(password, basestring):
            if not password:
                raise exceptions.ValidationError("Password cannot be empty.")
            self._set('password', password)
        else:
            raise exceptions.ValidationError("Password must be a string, not a %s." % type(password).__name__)

    @property
    def groups(self):
        """Get the associated group for this user.

        :return: The list of groups as Group objects.
        """
        return [Group.load(group_id) for group_id in self.group_ids]

    @property
    def group_ids(self):
        """Get the associated group IDs for this user.

        :return: The list of group IDs.
        """
        return self._get('groups')

    @groups.setter
    def groups(self, groups):
        """Set the associated group IDs for this user.

        :param groups: (list of integers) A list of group IDs.
        :raise: fetchcore.exceptions.ValidationError Thrown if groups is not a list or if each item in the list is not a
        finite positive integer.
        """
        if groups is None:
            self._set('groups', [])
        elif not isinstance(groups, list):
            raise exceptions.ValidationError("Groups must be a list, not a %s." % type(groups).__name__)
        else:
            groups = list(set(groups))
            for group in groups:
                if not Number.is_integer(group):
                    raise exceptions.ValidationError(
                        "Each item in groups must be an integer (%s is %s)." % (group, type(group).__name__))
                elif not Number.is_finite_positive(group):
                    raise exceptions.ValidationError(
                        "Each item in groups must be finite positive (item is %s)." % group)
            self._set('groups', groups)
