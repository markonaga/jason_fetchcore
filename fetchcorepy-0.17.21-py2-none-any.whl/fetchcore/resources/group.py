# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Russell Toris

# Futures
from __future__ import unicode_literals

# fetchcore
from fetchcore.resources import Resource
from fetchcore.exceptions import ValidationError


class Group(Resource):
    """
    Groups contain information about the organization of users
    """

    # The endpoint in fetchcore for groups.
    endpoint = 'users/groups'

    # TODO: update docs that say duration can be a timedelta when it's accepted.
    def __init__(self, id=None, name=None):
        """
        :param int id: The ID of the group (assigned automatically upon creation).
        :param str name: The human-readable name of the group.
        """
        super(Group, self).__init__(id=id)

        # Required fields first
        self.name = name

    @property
    def name(self):
        """Get the human-readable name of the group.

        :return: The group name.
        """
        return self._get('name')

    @name.setter
    def name(self, name):
        """Set the human-readable name of the group

        :param str name: The group name.
        :raise ValidationError: Thrown if name is not a string or if name is an empty string.
        """
        if isinstance(name, basestring):
            if not name:
                raise ValidationError("Group name cannot be empty.")
            self._set('name', name)
        else:
            raise ValidationError("Group name must be a string, not a %s." % type(name).__name__)
