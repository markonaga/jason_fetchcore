# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts, Michael Hwang, Russell Toris

# Futures
from __future__ import unicode_literals

# fetchcore
from ..tasks.task import Task
from ..user import User
from ..robots import Robot
from fetchcore.definitions import LogLevel
from fetchcore.resources import TimestampedResource
from fetchcore.utils import Number, IP
from fetchcore.exceptions import ValidationError, UnsupportedOperation


class Log(TimestampedResource):
    """
    Logs contain system level information from fetchcore. Logs are immutable once created.
    """

    # The endpoint in fetchcore for logs.
    endpoint = 'system/logs'

    def __init__(self, id=None, level=None, task=None, user=None, robot=None, process=None, file=None, function=None,
                 line=None, message=None, ip=IP.current_local_ip(), created=None, modified=None, **kwargs):
        """
        :param int id: The ID of the log (assigned automatically upon creation).
        :param ~fetchcore.definitions.enums.LogLevel level: The level of this log.
        :param int task: (OPTIONAL) The ID of the task that created this log.
        :param str user: (OPTIONAL) The username of the user that created this log.
        :param str robot: (OPTIONAL) The name of the robot that created this log.
        :param str process: The process that created this log.
        :param str file: (OPTIONAL) The name of the file that created this log.
        :param str function: (OPTIONAL) The function that created this log.
        :param int line: (OPTIONAL) The line number that created this log.
        :param str message: The log's message.
        :param str ip: The IP of the requester that created this log.
        :param created: The date and time of this log's creation (assigned automatically).
        :param modified: The date and time this log was last modified (updated automatically).
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(Log, self).__init__(id=id, created=created, modified=modified, **kwargs)

        # Required fields first
        self.level = level
        self.process = process
        self.message = message
        self.ip = ip

        # Now check optional fields
        if task:
            self.task = task
        if user:
            self.user = user
        if robot:
            self.robot = robot
        if file:
            self.file = file
        if function:
            self.function = function
        if line:
            self.line = line

    def update(self, _=None):
        """
        Overwrites base class update. Logs are immutable and cannot be updated on the server.

        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation("Logs are immutable and cannot be updated on the server.")

    def delete(self, _=None):
        """Overwrites base class delete. Logs are immutable and cannot be deleted on the server.

        :param _: Unused client parameter.
        :raise: fetchcore.exceptions.UnsupportedOperation
        """
        raise UnsupportedOperation("Logs are immutable and cannot be deleted on the server.")

    @property
    def level(self):
        """The current level of this log as defined as a LogLevel enum.

        :return: The current level of this log.
        """
        return self._get('level')

    @level.setter
    def level(self, level):
        """Set the current level of this log.

        :param LogLevel level: The level of this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the given level is not valid.
        """
        if level in LogLevel.values():
            self._set('level', level)
        else:
            raise ValidationError("%s is not an allowed log level (%s)." % (str(level), ', '.join(LogLevel.values())))

    # TODO: should this return None if it does not exist?
    @property
    def task_id(self):
        """Get the ID of the task that reported this log.

        :return: The ID of the associated task
        """
        return self._get('task')

    @task_id.setter
    def task_id(self, task_id):
        """Set the task ID for the task that generated this log.

        :param int task_id: The ID of the task that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the ID is not a finite positive number.
        """
        # Task ID is optional, we can unset it
        if task_id is None:
            self._set('task', task_id)
        elif not Number.is_real_number(task_id):
            raise ValidationError("Task ID must be a number (value is %s)." % str(task_id))
        elif not Number.is_finite_positive(task_id):
            raise ValidationError("Task ID must be a finite positive number (value is %s)." % str(task_id))
        elif not Number.is_integer(task_id):
            raise ValidationError("Task ID must be an integer (value is %s)." % str(task_id))
        else:
            self._set('task', task_id)

    @property
    def task(self):
        """Get the task that generated this log.

        :return: The task that generated this log.
        """
        return Task.load(self.task_id) if self.task_id else None

    @task.setter
    def task(self, task):
        """Set the task ID for the task that generated this log.

        :param int|Task task: The ID of the task that generated this log or the actual Task resource.
        :raise: fetchcore.exceptions.ValidationError Thrown if the ID is not a finite positive number.
        """
        if isinstance(task, Task) and not task.is_set('id'):
            task.save()
        self.task_id = task if not hasattr(task, 'id') else task.id

    # TODO: should this return None if it does not exist?
    @property
    def username(self):
        """Get the username of the user that reported this log.

        :return: The username of the associated user.
        """
        return self._get('user')

    @username.setter
    def username(self, username):
        """Set the username for the user that generated this log.

        :param str|None username: The username of the user that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the username is not a string or None.
        """
        # Username is optional, we can unset it
        if username is None or isinstance(username, basestring):
            self._set('user', username)
        else:
            raise ValidationError("The username must be a string, not a %s." % type(username).__name__)

    # TODO: should this return None if it does not exist?
    @property
    def user(self):
        return User.load(self.username) if self.username else None

    @user.setter
    def user(self, user):
        """Set the username for the user that generated this log.

        :param str user: The username of the user that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the username is not a string.
        """
        if isinstance(user, User) and not user.is_set('id'):
            user.save()
        self.username = user if not hasattr(user, 'email') else user.email

    # TODO: should this return None if it does not exist?
    @property
    def robot_name(self):
        """Get the name of the robot that reported this log.

        :return: The name of the associated robot
        """
        return self._get('robot')

    @robot_name.setter
    def robot_name(self, robot_name):
        """Set the robot name for the robot that generated this log.

        :param int robot_name: The name of the robot that generated this log.
        """
        # Robot name is optional, we can unset it
        if robot_name is None or isinstance(robot_name, basestring):
            self._set('robot', robot_name)
        else:
            raise ValidationError("The robot name must be a string, not a %s." % type(robot_name).__name__)

    @property
    def robot(self):
        """Get the robot that generated this log.

        :return: The robot that generated this log.
        """
        return Robot.load(self.robot_name) if self.robot_name else None

    @robot.setter
    def robot(self, robot):
        """Set the robot name for the robot that generated this log.

        :param str|Robot robot: The name of the robot that generated this log or the actual Robot resource.
        :raise: fetchcore.exceptions.ValidationError Thrown if the ID is not a finite positive number.
        """
        if isinstance(robot, Robot) and not robot.is_set('id'):
            robot.save()
        self.robot_name = robot if not hasattr(robot, 'name') else robot.name

    @property
    def process(self):
        """Get the process that made this log.

        :return: The name of the process that generated this log.
        """
        return self._get('process')

    @process.setter
    def process(self, process):
        """Set the name of the process that made this log.

        :param str process: The name of the process that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the process is not a string or is empty.
        """
        if isinstance(process, basestring):
            if not process:
                # The server does not allow process to be blank.
                raise ValidationError("Process cannot be an empty string.")
            self._set('process', process)
        else:
            raise ValidationError("Process must be a string, not a %s." % type(process).__name__)

    # TODO: should this return None if it does not exist?
    @property
    def file(self):
        """Get the file name that made this log.

        :return: The name of the file that generated this log.
        """
        return self._get('file')

    @file.setter
    def file(self, file):
        """Set the name of the file that made this log.

        :param str process: The name of the file that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the file is not a string or is empty.
        """
        # File is optional, we can unset it
        if file is None:
            self._set('file', file)
        elif isinstance(file, basestring):
            # The server does not allow file to be blank.
            if not file:
                raise ValidationError("File cannot be an empty string.")
            self._set('file', file)
        else:
            raise ValidationError("File must be a string, not a %s." % type(file).__name__)

    # TODO: should this return None if it does not exist?
    @property
    def function(self):
        """Get the function name that made this log.

        :return: The name of the function that generated this log.
        """
        return self._get('function')

    @function.setter
    def function(self, function):
        """Set the name of the function that made this log.

        :param str function: The name of the function that generated this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the function is not a string or is empty.
        """
        # Function is optional, we can unset it
        if function is None:
            self._set('function', function)
        elif isinstance(function, basestring):
            # The server does not allow function to be blank.
            if not function:
                raise ValidationError("Function cannot be an empty string.")
            self._set('function', function)
        else:
            raise ValidationError("Function must be a string, not a %s." % type(function).__name__)

    # TODO: should this return None if it does not exist?
    @property
    def line(self):
        """Get the line number within the file that made this log.

        :return: The line number within the file that made this log.
        """
        return self._get('line')

    @line.setter
    def line(self, line):
        """Set the line number within the file that made this log.

        :param int line: The line number within the file that made this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the line is not a finite positive number.
        """
        # Line is optional, we can unset it
        if line is None:
            self._set('line', line)
            # TODO: we should consider to better validation helper classes to wrap up some of these checks
        elif not Number.is_integer(line):
            raise ValidationError("Line must be an integer (value is %s)." % str(line))
        elif not Number.is_finite_positive(line):
            raise ValidationError("Line must be a finite positive number (value is %s)." % str(line))
        else:
            self._set('line', line)

    @property
    def message(self):
        """Get the actual message of this log entry.

        :return: The actual message of this log entry.
        """
        return self._get('message')

    @message.setter
    def message(self, message):
        """Set the message of this log entry.

        :param str message: The message associated with this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the message is not a string or is empty.
        """
        if isinstance(message, basestring):
            # The server does not allow message to be blank.
            if not message:
                raise ValidationError("Message cannot be an empty string.")
            self._set('message', message)
        else:
            raise ValidationError("Message must be a string, not a %s." % type(message).__name__)

    @property
    def ip(self):
        """Get the IP address of the reporter of this log.

        :return: The IP address of the reporter of this log.
        """
        return self._get('ip')

    @ip.setter
    def ip(self, ip):
        """Set the IP address of the reporter of this log.

        :param str ip: The IP address of the reporter of this log.
        :raise: fetchcore.exceptions.ValidationError Thrown if the ip is not a valid IP address string.
        """
        if not IP.valid_type(ip):
            raise ValidationError("IP must be a string.")
        elif not IP.valid_address(ip):
            raise ValidationError("%s is not a legal IP address." % ip)
        else:
            self._set('ip', ip)
