# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard Library
import re
from datetime import timedelta

# Fetchcore SDK Python
from fetchcore.resources import SingletonResource
from fetchcore.exceptions import ValidationError
from fetchcore.definitions import REGEX_DURATION

TIMEDELTA_REGEX = re.compile(REGEX_DURATION)


class StageSettings(SingletonResource):
    """
    Class for Fetchcore stage management settings.
    """

    endpoint = "system/settings/stage"

    def __init__(self, id=None, enabled=None, max_idle_time=None, created=None, modified=None, **kwargs):
        """
        :param enabled: Whether stage management is enabled.
        :param max_idle_time: The duration a robot can be idle before staging.
        :param created: The date and time of these settings' creation.
        :param modified: The date and time these settings were last modified.
        """

        super(StageSettings, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.enabled = enabled
        self.max_idle_time = max_idle_time

    @property
    def enabled(self):
        """
        :return: Whether or not stage management is currently activated.
        """
        return self._get("enabled")

    @enabled.setter
    def enabled(self, value):
        """
        :param value: A new activation state for stage management.
        :raise ValidationError if value is not a strict boolean.
        """
        if isinstance(value, bool):
            self._set("enabled", value)
        else:
            raise ValidationError("Enabled must be a boolean, not a %s." % type(value).__name__)

    @property
    def max_idle_time(self):
        """
        :return: The maximum amount of time a robot can be idle before being sent to a staging area.
        """
        return self._get("max_idle_time")

    @max_idle_time.setter
    def max_idle_time(self, value):
        """
        :param value: A new maximum idle time before staging robots.
        :raise ValidationError if value is not a datetime.timedelta object.
        """
        if isinstance(value, timedelta):
            self._set("max_idle_time", value)
        elif isinstance(value, basestring):
            match = TIMEDELTA_REGEX.match(value)
            if match:
                groups = match.groupdict()
                self._set("max_idle_time", timedelta(hours=int(groups['hours']),
                                                     minutes=int(groups['minutes']),
                                                     seconds=int(groups['seconds'])))
            else:
                raise ValidationError("Max idle time string %s could not be parsed into a timedelta." % value)
        else:
            raise ValidationError("Max idle time must be a timedelta, not a %s." % type(value).__name__)
