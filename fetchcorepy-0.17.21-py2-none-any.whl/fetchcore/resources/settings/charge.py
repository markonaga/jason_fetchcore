# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard Library
import re
from datetime import timedelta

# Fetchcore SDK Python
from fetchcore.resources import SingletonResource
from fetchcore.exceptions import ValidationError
from fetchcore.definitions import REGEX_DURATION

TIMEDELTA_REGEX = re.compile(REGEX_DURATION)


class ChargeSettings(SingletonResource):
    """
    Class for Fetchcore charge management settings.
    """

    endpoint = "system/settings/charge"

    def __init__(
            self, id=None, enabled=None, max_idle_time=None, min_idle_battery_state=None, min_battery_state=None,
            max_run_time=None, pause_tasks=None, deep_charge_sunday=None, deep_charge_monday=None,
            deep_charge_tuesday=None, deep_charge_wednesday=None, deep_charge_thursday=None, deep_charge_friday=None,
            deep_charge_saturday=None, created=None, modified=None, **kwargs
    ):
        """
        :param enabled: Whether charge management is enabled.
        :param max_idle_time: The duration a robot can be idle before charging.
        :param min_idle_battery_state:
            The minimum battery level percentage an idle robot must drop below before being sent to charge.
        :param min_battery_state:
            The minimum battery level percentage a non-idle robot must drop below before being sent to charge.
        :param max_run_time: The maximum amount of time a robot can run before being sent to charge.
        :param created: The date and time of these settings' creation.
        :param modified: The date and time these settings were last modified.
        """

        super(ChargeSettings, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.enabled = enabled
        self.max_idle_time = max_idle_time
        self.min_idle_battery_state = min_idle_battery_state
        self.min_battery_state = min_battery_state
        self.max_run_time = max_run_time
        self.pause_tasks = pause_tasks
        self.deep_charge_sunday = deep_charge_sunday
        self.deep_charge_monday = deep_charge_monday
        self.deep_charge_tuesday = deep_charge_tuesday
        self.deep_charge_wednesday = deep_charge_wednesday
        self.deep_charge_thursday = deep_charge_thursday
        self.deep_charge_friday = deep_charge_friday
        self.deep_charge_saturday = deep_charge_saturday

    @property
    def enabled(self):
        """
        :return: Whether or not charge management is currently active.
        """
        return self._get("enabled")

    @enabled.setter
    def enabled(self, value):
        """
        :param value: The new value for charge management activation status.
        :raise ValidationError if value is not a strict boolean.
        """
        if isinstance(value, bool):
            self._set("enabled", value)
        else:
            raise ValidationError("Enabled must be a boolean.")

    @property
    def max_idle_time(self):
        """
        :return: The maximum allowed time a robot can be idle before being sent to charge.
        """
        return self._get("max_idle_time")

    @max_idle_time.setter
    def max_idle_time(self, value):
        """
        :param value: The new maximum allowed time a robot can be idle before being sent to charge.
        :raise ValidationError if value is not a datetime.timedelta object or timedelta-parseable string.
        """
        if isinstance(value, timedelta):
            self._set("max_idle_time", value)
        elif isinstance(value, basestring):
            match = TIMEDELTA_REGEX.match(value)
            if match:
                groups = match.groupdict()
                self._set("max_idle_time", timedelta(hours=int(groups['hours']),
                                                     minutes=int(groups['minutes']),
                                                     seconds=int(groups['seconds'])))
            else:
                raise ValidationError("Max idle time string %s could not be parsed into a timedelta." % value)
        else:
            raise ValidationError("Max idle time must be a timedelta or string, not a %s." % type(value).__name__)

    @property
    def min_idle_battery_state(self):
        """
        :return: The minimum battery level in the interval [0.0, 1.0] an idle robot must drop below before being
            sent to charge.
        """
        return self._get("min_idle_battery_state")

    @min_idle_battery_state.setter
    def min_idle_battery_state(self, value):
        """
        :param value: The new minimum battery level for idle robots.
        :raise ValidationError: if value is:
            - Not a number
            - A number not contained in the interval [0.0, 1.0]
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Min idle battery state must be a number, not a %s." % type(value).__name__)

        if 0 <= value <= 1:
            self._set("min_idle_battery_state", value)
        else:
            raise ValidationError("Min idle battery state must be set between 0.0 and 1.0.")

    @property
    def min_battery_state(self):
        """
        :return: The minimum battery level in the interval [0.0, 1.0] an robot must drop below before being sent
            to charge.
        """
        return self._get("min_battery_state")

    @min_battery_state.setter
    def min_battery_state(self, value):
        """
        :param value: The new minimum battery level for non-idle robots.
        :raise ValidationError if value is:
            - Not a number
            - A number not contained within the interval [0.0, 1.0]
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Min battery state must be a number, not a %s." % type(value).__name__)

        if 0 <= value <= 1:
            self._set("min_battery_state", value)
        else:
            raise ValidationError("Min idle battery state must be set between 0.0 and 1.0.")

    @property
    def max_run_time(self):
        """
        :return: The maximum time a robot should run before considering whether or not it should be forcibly charged.
        """
        return self._get("max_run_time")

    @max_run_time.setter
    def max_run_time(self, value):
        """
        :param value: The new maximum run time for a robot.
        :raise ValidationError: if value is not a ~datetime.timedelta object.
        """
        if isinstance(value, timedelta):
            self._set("max_run_time", value)
        elif isinstance(value, basestring):
            match = TIMEDELTA_REGEX.match(value)
            if match:
                groups = match.groupdict()
                self._set("max_run_time", timedelta(hours=int(groups['hours']),
                                                    minutes=int(groups['minutes']),
                                                    seconds=int(groups['seconds'])))
            else:
                raise ValidationError("Max run time string %s could not be parsed into a timedelta." % value)
        else:
            raise ValidationError("Max run time must be a timedelta, not a %s." % type(value).__name__)

    @property
    def pause_tasks(self):
        """
        :return: Whether to cancel or pause currently active tasks.
        """
        return self._get("pause_tasks")

    @pause_tasks.setter
    def pause_tasks(self, value):
        """
        :param value: Whether to cancel or pause currently active tasks.
        :raise ValidationError if value is not a strict boolean.
        """
        if isinstance(value, bool):
            self._set("pause_tasks", value)
        else:
            raise ValidationError("Pause tasks must be a boolean.")

    @property
    def deep_charge_sunday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_sunday")

    @deep_charge_sunday.setter
    def deep_charge_sunday(self, value):
        """
        param value: The array of deep charge settings
        :raise ValidationError if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_sunday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_monday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_monday")

    @deep_charge_monday.setter
    def deep_charge_monday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_monday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_tuesday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_tuesday")

    @deep_charge_tuesday.setter
    def deep_charge_tuesday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError: if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_tuesday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_wednesday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_wednesday")

    @deep_charge_wednesday.setter
    def deep_charge_wednesday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError: if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_wednesday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_thursday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_thursday")

    @deep_charge_thursday.setter
    def deep_charge_thursday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError: if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_thursday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_friday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_friday")

    @deep_charge_friday.setter
    def deep_charge_friday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_friday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")

    @property
    def deep_charge_saturday(self):
        """
        :return: The deep charge times that are available for deep charge on this day.
        """
        return self._get("deep_charge_saturday")

    @deep_charge_saturday.setter
    def deep_charge_saturday(self, value):
        """
        :param value: The array of deep charge settings
        :raise ValidationError: if value is not an array
        """
        if isinstance(value, list) and len(value) == 24:
            self._set("deep_charge_saturday", value)
        else:
            raise ValidationError("Deep charge times must be arrays of size 24")
