# Copyright 2017 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import SingletonResource
from fetchcore.exceptions import ValidationError


class HMISettings(SingletonResource):
    """
    Class for Fetchcore update settings.
    """

    endpoint = "system/settings/hmi"

    def __init__(self, id=None, default_url=None, created=None, modified=None, **kwargs):
        """
        :param default_url: The default URL for HMI screens.
        :param created: The date and time of these settings' creation.
        :param modified: The date and time these settings were last modified.
        """

        super(HMISettings, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.default_url = default_url or ''

    @property
    def default_url(self):
        """
        :return: The default URL for HMI screens.
        """
        return self._get("default_url")

    @default_url.setter
    def default_url(self, value):
        """
        :param value: A new URL the HMI screen should display by default.
        :raise ValidationError if value is:
            - Neither string nor NoneType
            - A malformed URL
        """
        if isinstance(value, basestring):
            if not valid_url(value):
                raise ValidationError("Given URL %s in default_url does not appear to be valid." % value)
            self._set("default_url", value)
        elif value is None:
            self._set("default_url", value)
        else:
            raise ValidationError("default_url must be a valid URL.")


def valid_url(url):
    """Determine whether url is a valid URL. This is pretty simplistic; a better way might be to use django's URL
    validation scheme somehow.

    :param url: The potentially valid URL.
    :return: True if url is valid. False otherwise.
    """
    valid_schemes = ('http:', 'https:', 's3:')

    if isinstance(url, basestring):
        split_url = url.split("/")
        if len(split_url) >= 3 and split_url[0] in valid_schemes and not split_url[1]:
            # URL is long enough (valid scheme + netloc + optional path), separated by '//'
            return True
    return False
