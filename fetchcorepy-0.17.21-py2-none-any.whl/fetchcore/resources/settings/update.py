# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import SingletonResource
from fetchcore.exceptions import ValidationError


class UpdateSettings(SingletonResource):
    """
    Class for Fetchcore update settings.
    """

    endpoint = "system/settings/update"

    def __init__(self, id=None, mirrors=None, keys=None, created=None, modified=None, **kwargs):
        """
        :param mirrors: A list of debian package locations to use for updates.
        :param keys: A list of urls for GPG keys to use during apt-get calls.
        :param created: The date and time of these settings' creation.
        :param modified: The date and time these settings were last modified.
        """

        super(UpdateSettings, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.keys = keys or []
        self.mirrors = mirrors or []

    @property
    def keys(self):
        """
        :return: A list of keys to download and use during apt-get calls in robot updates.
        """
        return self._get("keys")

    @keys.setter
    def keys(self, value):
        """
        :param value: A new list of keys to download and use during apt-get calls in robot updates.
        :raise ValidationError if value is:
            - Not a list or tuple
            - A list or tuple not containing only valid URL strings
        """
        if isinstance(value, (list, tuple)):
            for url in value:
                if not valid_url(url):
                    raise ValidationError("Given URL %s in keys does not appear to be valid." % url)
            self._set("keys", value)
        else:
            raise ValidationError("keys must be a list of valid URLs.")

    @property
    def mirrors(self):
        """
        :return: A list of apt repository mirrors to use during apt-get calls in robot updates.
        """
        return self._get("mirrors")

    @mirrors.setter
    def mirrors(self, value):
        """
        :param value: A new list of apt repository mirrors to use during apt-get calls in robot updates.
        :raise ValidationError if value is:
            - Not a list or tuple
            - A list or tuple not containing only valid URL strings
        """
        if isinstance(value, (list, tuple)):
            for deb_url in value:
                if not valid_deb_url(deb_url):
                    raise ValidationError("Given deb URL %s in mirrors does not appear to be valid." % deb_url)
            self._set("mirrors", value)
        else:
            raise ValidationError("mirrors must be a list of valid debian URLs.")


def valid_url(url):
    """Determine whether url is a valid URL. This is pretty simplistic; a better way might be to use django's URL
    validation scheme somehow.

    :param url: The potentially valid URL.
    :return: True if url is valid. False otherwise.
    """
    valid_schemes = ('http:', 'https:', 's3:')

    if isinstance(url, basestring):
        split_url = url.split("/")
        if len(split_url) >= 3 and split_url[0] in valid_schemes and not split_url[1]:
            # URL is long enough (valid scheme + netloc + optional path), separated by '//'
            return True
    return False


def valid_deb_url(deb_url):
    """Determine whether deb_url is a valid deb URL string.

    :param deb_url: The potentially valid deb URL.
    :return: True if deb_url is valid. False otherwise.
    """
    if isinstance(deb_url, basestring) and deb_url.startswith('deb ') and deb_url.endswith(' trusty main'):
        url = deb_url.replace('deb ', '').replace(' trusty main', '')
        return valid_url(url)
    else:
        return False
