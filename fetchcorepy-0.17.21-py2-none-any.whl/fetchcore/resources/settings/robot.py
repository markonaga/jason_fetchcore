# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import SingletonResource
from fetchcore.exceptions import ValidationError
from fetchcore.utils import Number


class RobotSettings(SingletonResource):
    """
    Class for Fetchcore robot system settings.
    """

    endpoint = "system/settings/robot"

    def __init__(self, id=None, max_velocity=None, max_angular_velocity=None, created=None, modified=None, **kwargs):
        """
        :param max_velocity: The maximum linear velocity a robot should achieve.
        :param max_angular_velocity: The maximum angular velocity a robot should achieve.
        :param created: The date and time of these settings' creation.
        :param modified: The date and time these settings were last modified.
        """

        super(RobotSettings, self).__init__(id=id, created=created, modified=modified, **kwargs)

        self.max_velocity = max_velocity
        self.max_angular_velocity = max_angular_velocity

    @property
    def max_velocity(self):
        """
        :return: The currently-configured maximum linear velocity for robots system-wide.
        """
        return self._get("max_velocity")

    @max_velocity.setter
    def max_velocity(self, value):
        """
        :param value: A new maximum linear velocity for robots in this system.
        :raise ValidationError if value is:
            - Not a number
            - A negative number
        """
        if not Number.is_real_number(value) or isinstance(value, bool):
            raise ValidationError("Max velocity must be a number (max velocity is %s)" % value)
        elif value < 0.3 or value > 1.5:
            raise ValidationError("Max velocity must be between 0.3 and 1.5 (max velocity is %s)" % value)
        else:
            self._set("max_velocity", value)

    @property
    def max_angular_velocity(self):
        """
        :return: The currently-configured maximum angular velocity for robots system-wide.
        """
        return self._get("max_angular_velocity")

    @max_angular_velocity.setter
    def max_angular_velocity(self, value):
        """
        :param value: A new maximum angular velocity for robots in this system.
        :raise ValidationError if value is:
            - Not a number
            - A negative number
        """
        if not Number.is_real_number(value) or isinstance(value, bool):
            raise ValidationError("Max angular velocity must be a number (max angular velocity is %s)" % value)
        elif value < 0.0 or value > 2.5:
            raise ValidationError(
                "Max angular velocity must be between 0.0 and 2.5 (max angular velocity is %s)" % value)
        else:
            self._set("max_angular_velocity", value)
