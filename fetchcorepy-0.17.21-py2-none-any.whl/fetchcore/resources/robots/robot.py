# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard library
import re

# Fetchcore SDK Python
from fetchcore import configuration, exceptions
from fetchcore.definitions import ROBOT_NAME_PATTERN, REGEX_CAPITAL_NUMBER_UNDERSCORE, REGEX_MAC_ADDRESS, RobotStatus, \
    REGEX_CAPITAL_UNDERSCORE
from fetchcore.exceptions import ValidationError
from fetchcore.resources import TimestampedResource
from fetchcore.resources.maps import Map
from fetchcore.resources.robots import RobotFootprint, CartFootprint
from fetchcore.utils import IP, Number, Timestamp

MAC_ADDRESS_PATTERN = re.compile(REGEX_MAC_ADDRESS)
REGEX_ROBOT_NAME = re.compile(ROBOT_NAME_PATTERN)


class Robot(TimestampedResource):
    """
    A class to represent a Fetchcore robot document.
    """

    endpoint = 'robots'
    available_tasks_endpoint = 'robots/%s/tasks'
    pk = 'name'

    def __init__(self, id=None, name=None, password=None, ip=None, installed_actions=None, map=None, footprint=None,
                 configurations=None, status=RobotStatus.OFFLINE, localized=False, charging_state=False,
                 ap_mac_address=None, ap_ssid=None, last_status_change=None, last_charge=None,
                 last_connection_time=None, last_boot=None, cart_footprint=None, created=None, modified=None, **kwargs):
        """
        :param id: The resource ID of this robot.
        :param name: The unique name of this robot.
        :param password: The password of this robot (used by fetch system user)
        :param ip: The last known IP address of the robot.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        :param map: The map the robot is operating in.
        :param footprint: The footprint that this robot is associated with.
        :param configurations: The hardware configurations this robot is capable of.
        :param status: The robot's current status.
        :param localized: Whether or not the robot is currently localized.
        :param charging_state: Whether or not the robot is currently charging.
        :param ap_mac_address: The MAC address of the robot's current access point (AP).
        :param ap_ssid: The SSID of the robot's current access point (AP).
        :param last_status_change: Last time the robot status changed.
        :param last_charge: The last time the robot charged.
        :param cart_footprint: The cart footprint this robot is attached to, or null if it does not have a cart.
        """
        super(Robot, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name
        if password:
            self.password = password
        self.ip = ip
        if installed_actions:
            self.installed_actions = installed_actions
        self.map = map
        self.footprint = footprint
        self.configurations = configurations
        self.status = status
        self.localized = localized
        self.charging_state = charging_state
        if ap_mac_address:
            self.ap_mac_address = ap_mac_address
        if ap_ssid:
            self.ap_ssid = ap_ssid
        self.last_status_change = last_status_change
        if last_charge:
            self.last_charge = last_charge
        if last_connection_time:
            self.last_connection_time = last_connection_time
        if last_boot:
            self.last_boot = last_boot
        self.cart_footprint = cart_footprint

    @property
    def name(self):
        """
        :return: The robot's unique name.
        """
        return self._get("name")

    @name.setter
    def name(self, value):
        """
        :param value: The new name for this robot.
        :raises ValidationError: if the new value is:
            - A non-string
            - An empty string
            - A string not matching the regex pattern "^freight\d+$"
        """
        if isinstance(value, basestring):
            if not value:
                raise ValidationError("Name cannot be an empty string")
            if not REGEX_ROBOT_NAME.match(value):
                raise ValidationError("Name must match freightXX pattern (ex: 'freight21').")
            self._set("name", value)
        else:
            raise ValidationError("Name must be a string, not a %s"
                                  % type(value).__name__)

    @property
    def password(self):
        """
        :raises AttributeError: Thrown if the robot's password is accessed
        """
        raise AttributeError("Cannot get robot's password")

    @password.setter
    def password(self, value):
        """Set the robot's password.

        :param password: (string) The robot's password.
        :raise fetchcore.exceptions.ValidationError: Thrown if password is not a string or if password is empty.
        """
        if isinstance(value, basestring):
            if not value:
                raise ValidationError("Password cannot be empty.")
            self._set('password', value)
        else:
            raise ValidationError("Password must be a string, not a %s." % type(value).__name__)

    @property
    def ip(self):
        """
        :return: The last known IP of the robot.
        """
        return self._get("ip")

    @ip.setter
    def ip(self, value):
        """
        :param value: The new value for the robot's IP.
        :raises ValidationError if the new value is:
            - Not a string
            - A string not matching the IPv4 address pattern (e.g. "127.0.0.1")
        """
        if value is None:
            self._set("ip", value)
        elif IP.valid_type(value) and IP.valid_address(value):
            self._set("ip", value)
        else:
            raise ValidationError(
                "Given IP %s does not appear to be a valid IP string." % str(value))

    @property
    def installed_actions(self):
        """
        :return: A list of installed actions for this robot.
        """
        return self._get("installed_actions")

    @installed_actions.setter
    def installed_actions(self, value):
        if isinstance(value, (list, tuple)):
            self._set("installed_actions", value)
        else:
            raise ValidationError("Installed actions must be a list, not a %s." % type(value).__name__)

    @property
    def map(self):
        """Get the map object for this robot.

        :return: The robot's map object.
        """
        return None if self.map_id is None else Map.load(self.map_id)

    @map.setter
    def map(self, value):
        """Set the map ID for this robot.

        :param value: (integer|Map) The ID of the robot's map or the actual Map resource.
        :raise ~fetchcore.exceptions.ValidationError: if the ID is not a finite positive integer.
        """
        self.map_id = value if not hasattr(value, 'id') else value.id

    @property
    def map_id(self):
        """
        :return: The current map the robot is operating in.
        """
        return self._get("map")

    @map_id.setter
    def map_id(self, value):
        """Set the associated map ID for this robot.

        :param value: (integer) The map ID.
        :raise ~fetchcore.exceptions.ValidationError: Thrown if value is not a finite positive integer.
        """
        if value is None:
            self._set('map', value)
        elif Number.is_integer(value):
            if not Number.is_finite_positive(value):
                raise ValidationError("Map ID must be a finite positive integer (item is %s)." % value)
            self._set('map', value)
        else:
            raise ValidationError("Map ID must be an integer (%s is %s)." % (value, type(value).__name__))

    @property
    def footprint_name(self):
        """Gets the robot footprint name associated with this robot.

        :return: (string) The name of the robot footprint.
        """
        return self._get("footprint")

    @property
    def footprint(self):
        """Gets the robot footprint associated with this robot.

        :return: (RobotFootprint) The robot footprint object.
        """
        return RobotFootprint.load(self.footprint_name)

    @footprint.setter
    def footprint(self, value):
        """Sets the robot footprint associated with this robot.

        :param value: The associated robot footprint.
        :raises: Validation Error if value is not a string or does not contain only capital letters and underscores
        """
        try:
            if re.match(REGEX_CAPITAL_NUMBER_UNDERSCORE, value):
                self._set("footprint", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_NUMBER_UNDERSCORE))
        except TypeError:
            raise ValidationError("Footprint must be a string")

    @property
    def cart_footprint_name(self):
        """Gets the cart footprint name associated with this robot or null if it is not docked.

        :return: (string) The name of the cart footprint.
        """
        return self._get('cart_footprint')

    @property
    def cart_footprint(self):
        """Gets the cart footprint associated with this robot or null if it is not docked.

        :return: (CartFootprint) The robot footprint object.
        """
        return CartFootprint.load(self.cart_footprint_name) if self.cart_footprint_name else None

    @cart_footprint.setter
    def cart_footprint(self, value):
        """Sets the cart footprint associated with this robot.

        :param value: The associated cart footprint.
        :raises: Validation Error if value is not a string or does not contain only capital letters and underscores
        """
        try:
            if value is None or re.match(REGEX_CAPITAL_NUMBER_UNDERSCORE, value):
                self._set("cart_footprint", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_NUMBER_UNDERSCORE))
        except TypeError:
            raise ValidationError("Footprint must be a string or none.")

    @property
    def configuration_names(self):
        """Gets the name of the hardware configurations the robot possesses.

        :return: The names pertaining to this robot's hardware configurations.
        :rtype: ~__builtin__.list
        """
        return self._get("configurations")

    @property
    def configurations(self):
        """Gets the RobotConfiguration objects for the hardware configurations the robot possesses.

        :return: The robots configurations.
        :rtype: ~__builtin__.list
        """
        from fetchcore.resources.robots import RobotConfiguration
        return [RobotConfiguration.load(name) for name in
                self.configuration_names] if self.configuration_names is not None else None

    @configurations.setter
    def configurations(self, configs):
        """Set the robot's current hardware configurations.

        :param ~__builtin__.list configs: The list of robot configuration names comprised of only capital letters and
        underscores.
        :raise fetchcore.exceptions.ValidationError: Thrown if configs is not a list or if any item in configs is not
        a string in the correct format.
        """
        if configs is None:
            self._set("configurations", configs)
        else:
            if not isinstance(configs, list) or not configs:
                raise ValidationError("Configurations must be a non-empty list.")
            for config in configs:
                try:
                    if not re.match(re.compile(REGEX_CAPITAL_UNDERSCORE), config):
                        raise ValidationError(
                            'Configuration "%s" is in the wrong format (should be comprised of only capital '
                            'letters and underscore)' % config)
                except TypeError:
                    raise ValidationError("All items in configurations must be a string (%s is a %s)."
                                          % (config, type(config).__name__))
            self._set("configurations", configs)

    @property
    def status(self):
        """
        :return: The current state of the robot.
        """
        return self._get("status")

    @status.setter
    def status(self, value):
        """
        :param value: The new status of the robot.
        :raises ValidationError if value is not a valid RobotStatus
        """
        if value in RobotStatus.values():
            self._set("status", value)
        else:
            raise ValidationError("%s is not an allowed robot status (%s)"
                                  % (value, ", ".join(RobotStatus.values())))

    @property
    def localized(self):
        """
        :return: Whether or not the robot is currently localized.
        """
        return self._get("localized")

    @localized.setter
    def localized(self, value):
        """
        :param value: The new value for the robot's localization state.
        :raise ValidationError if value is not a strict boolean.
        """
        if isinstance(value, bool):
            self._set("localized", value)
        else:
            raise ValidationError("Localized must be a boolean.")

    @property
    def charging_state(self):
        """
        :return: Whether or not the robot is currently charging.
        """
        return self._get("charging_state")

    @charging_state.setter
    def charging_state(self, value):
        """
        :param value: The new value for robot's charging status.
        :raise ValidationError if value is not a strict boolean.
        """
        if isinstance(value, bool):
            self._set("charging_state", value)
        else:
            raise ValidationError("Charging state must be a boolean.")

    @property
    def ap_mac_address(self):
        """
        :return: The MAC address of the robot's access point.
        """
        return self._get("ap_mac_address")

    @ap_mac_address.setter
    def ap_mac_address(self, value):
        """
        :param value: The new MAC address for this robot's AP.
        :raises ValidationError if the new value is:
            - A non-string that is not None
            - An empty string
            - A string not in MAC address notation
        """
        if isinstance(value, basestring):
            if not MAC_ADDRESS_PATTERN.match(value):
                raise ValidationError("Name must match MAC address pattern: xx-xx-xx-xx-xx-xx).")
            self._set("ap_mac_address", value)
        elif value is None:
            self._set("ap_mac_address", value)
        else:
            raise ValidationError("MAC address must be a string, not a %s." % type(value).__name__)

    @property
    def ap_ssid(self):
        """
        :return: The SSID of the robot's access point.
        """
        return self._get("ap_ssid")

    @ap_ssid.setter
    def ap_ssid(self, value):
        """
        :param value: The new SSID for this robot's AP.
        :raises ValidationError if the new value is:
            - A non-string that is not None
            - An empty string
        """
        if isinstance(value, basestring):
            if not value:
                raise ValidationError("AP SSID cannot be an empty string.")
            self._set("ap_ssid", value)
        elif value is None:
            self._set("ap_ssid", value)
        else:
            raise ValidationError("AP SSID must be a string or None, not %s." % type(value).__name__)

    @property
    def last_status_change(self):
        """Gets the timestamp that indicates when the robot status last changed

        :return: (datetime.datetime) The last_status_change timestamp
        """
        return self._get("last_status_change")

    @last_status_change.setter
    def last_status_change(self, last_status_change):
        """Sets the timestamp that indicates when the robot status last changed

        :param last_status_change: (string|datetime.datetime) A timestamp
        """
        if last_status_change is None:
            self._set("last_status_change", last_status_change)
        else:
            try:
                self._set("last_status_change", Timestamp.to_datetime(last_status_change))
            except (TypeError, ValueError) as e:
                raise exceptions.ValidationError(e)

    @property
    def last_charge(self):
        """Gets the timestamp that indicates when the robot was lat charged

        :return: (datetime.datetime) The last_charge timestamp
        """
        return self._get("last_charge")

    @last_charge.setter
    def last_charge(self, last_charge):
        """Sets the timestamp that indicates when the robot was last charged

        :param last_charge: (string|datetime.datetime) A timestamp
        """
        if last_charge is None:
            self._set("last_charge", last_charge)
        else:
            try:
                self._set("last_charge", Timestamp.to_datetime(last_charge))
            except (TypeError, ValueError) as e:
                raise exceptions.ValidationError(e)

    @property
    def last_connection_time(self):
        """Gets the timestamp that indicates when the robot last connected

        :return: (datetime.datetime) The last_connection_time timestamp
        """
        return self._get("last_connection_time")

    @last_connection_time.setter
    def last_connection_time(self, last_connection_time):
        """Sets the timestamp that indicates when the robot last connected

        :param last_connection_time: (string|datetime.datetime) A timestamp
        """
        if last_connection_time is None:
            self._set("last_connection_time", last_connection_time)
        else:
            try:
                self._set("last_connection_time", Timestamp.to_datetime(last_connection_time))
            except (TypeError, ValueError) as e:
                raise exceptions.ValidationError(e)

    @property
    def last_boot(self):
        """Gets the timestamp that indicates when the robot's computer last booted

        :return: (datetime.datetime) The last_boot timestamp
        """
        return self._get("last_boot")

    @last_boot.setter
    def last_boot(self, last_boot):
        """Sets the timestamp that indicates when the robot's computer last booted

        :param last_boot: (string|datetime.datetime) A timestamp
        """
        if last_boot is None:
            self._set("last_boot", last_boot)
        else:
            try:
                self._set("last_boot", Timestamp.to_datetime(last_boot))
            except (TypeError, ValueError) as e:
                raise exceptions.ValidationError(e)

    def get_tasks(self, status=None, client=None):
        """Special function to get tasks assigned to the robot.

        :param status: The status of the tasks to retrieve.
        :param client: The client to make this request with. If not provided, it will default to the global client.

        :returns: A list of Tasks for this Robot, if any exist and were retrieved, matching the status (if provided).
        :rtype: list of Tasks
        """

        if not client:
            client = configuration.__GLOBAL_CLIENT__
        self._Resource__validate_client(client)

        # Download tasks
        url = self.available_tasks_endpoint % self.name
        if status:
            url += '/%s' % status
        tasks_response = client.get(url)

        if not tasks_response:
            return []

        # Cache the areas
        from fetchcore.resources import Task
        tasks = []
        for task_response in tasks_response.get('results', []):
            new_task = Task.set_response(task_response)
            tasks.append(new_task)
        return tasks

    @property
    def current_task(self):
        """Special function to get the current task assigned to the robot.

        :returns: The current Task for this Robot, if it exists.
        :rtype: Task object
        """
        current_task = self.get_tasks(status='WORKING')
        if current_task == []:
            return None
        else:
            return current_task[0]

    @property
    def current_task_id(self):
        """Special function to get the ID of the current task assigned to the robot.

        :returns: The current task ID for this Robot, if it exists.
        :rtype: integer
        """
        current_task = self.get_tasks(status='WORKING')
        if current_task == []:
            return None
        else:
            return current_task[0].id
