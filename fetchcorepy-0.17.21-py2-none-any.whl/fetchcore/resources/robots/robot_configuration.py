# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard Library
import re

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.exceptions import ValidationError
from fetchcore.definitions import REGEX_CAPITAL_UNDERSCORE

CAPITAL_UNDERSCORE_PATTERN = re.compile(REGEX_CAPITAL_UNDERSCORE)


class RobotConfiguration(TimestampedResource):
    """
    A class to represent a Fetchcore robot configuration document.
    """

    endpoint = 'robots/configurations'
    pk = 'name'

    def __init__(self, id=None, name=None, available_actions=None, created=None, modified=None, **kwargs):
        """
        :param id: (integer) The resource ID of this robot configuration.
        :param name: (string) The unique name of this configuration.
        :param available_actions: (array[string]) The names of the associated available actions.
        :param created: (string|datetime.datetime) The date and time this robot configuration was created.
        :param modified: (string|datetime.datetime) The date and time this robot configuration was last modified.
        """
        super(RobotConfiguration, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name
        self.available_action_names = available_actions

    @property
    def name(self):
        """Get the unique name of this configuration.

        :return: The robot configuration's unique name.
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Set the unique name of this configuration.

        :param name: (string) The new name for this robot.
        :raises fetchcore.exceptions.ValidationError: Thrown if the new name is:
            - A non-string
            - An empty string
            - A string that does not contain only capital letters and underscores
        """
        if isinstance(name, basestring):
            if not name:
                raise ValidationError("Name cannot be an empty string")
            if not re.match(CAPITAL_UNDERSCORE_PATTERN, name):
                raise ValidationError("Name %s does not match the pattern %s" % (name, REGEX_CAPITAL_UNDERSCORE))
            self._set("name", name)
        else:
            raise ValidationError("Name must be a string, not a %s" % type(name).__name__)

    @property
    def available_action_names(self):
        """Gets the available action names for this configuration.

        :return: (list) A list of available action names.
        """
        return self._get("available_actions")

    @available_action_names.setter
    def available_action_names(self, available_actions):
        """Sets the available action names for this configuration.

        :param available_actions: (list) The list of available action names comprised of only capital letters and
        underscores.
        :raise fetchcore.exceptions.ValidationError: Thrown if available_actions is not a list or if any item in
        available_actions is not a string in the correct format
        """
        if available_actions is None:
            self._set("available_actions", [])
        elif not isinstance(available_actions, list):
            raise ValidationError("Available actions must be a list")
        else:
            for available_action in available_actions:
                try:
                    if not re.match(CAPITAL_UNDERSCORE_PATTERN, available_action):
                        raise ValidationError("Available action %s does not match the pattern %s"
                                              % (available_action, REGEX_CAPITAL_UNDERSCORE))
                except TypeError:
                    raise ValidationError("All items in available actions must be string (%s is a %s)."
                                          % (available_action, type(available_action).__name__))
            self._set("available_actions", available_actions)
