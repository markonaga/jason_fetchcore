# Copyright 2016 Fetch Robotics Inc.
# Author(s): Cappy Pitts

# Standard Library
import re

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.exceptions import UndefinedFieldError, ValidationError
from fetchcore.definitions import FootprintTypes, REGEX_CAPITAL_NUMBER_UNDERSCORE
from fetchcore.utils import Number

CAPITAL_UNDERSCORE_PATTERN = re.compile(REGEX_CAPITAL_NUMBER_UNDERSCORE)


class RobotFootprint(TimestampedResource):
    """
    A class to represent a Fetchcore robot footprint document.
    """

    endpoint = 'robots/footprints'
    pk = 'name'

    def __init__(self, id=None, name=None, clearing_collision_model=None, clearing_robot_radius=None,
                 clearing_inflation_factor=None, clearing_polygon=None, clearing_footprint_type=None,
                 planning_collision_model=None, planning_robot_radius=None, planning_inflation_factor=None,
                 planning_footprint_type=None, created=None, modified=None, **kwargs):
        """
        :param int id: The resource ID of this robot configuration.

        :param str name: The unique name of this configuration.
        :param str clearing_collision_model: The collision model type of the robot configuration.
        :param float clearing_robot_radius: The robot's estimated radius used for clearing.
        :param float clearing_inflation_factor: The factor by which to inflate the robot's radius for clearing.
        :param clearing_polygon: A representation of the polygon used for representing a robot for clearing.
        :param str clearing_footprint_type: The type of clearing footprint described for this configuration.

        :param str planning_collision_model: The collision model type of the robot configuration.
        :param float planning_robot_radius: The robot's estimated radius used for planning.
        :param float planning_inflation_factor: The factor by which to inflate the robot's radius for planning.
        :param str planning_footprint_type: The type of planning footprint described for this configuration.

        :param created: The date and time this robot configuration was created.
        :param modified: The date and time this robot configuration was last modified.

        :type clearing_polygon: list, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(RobotFootprint, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.name = name
        self.clearing_collision_model = clearing_collision_model
        if clearing_footprint_type == FootprintTypes.RADIUS and \
                any(item is None for item in (clearing_robot_radius, clearing_inflation_factor)):
            raise ValidationError("Cannot set clearing footprint type to '%s' without also providing clearing robot "
                                  "radius and clearing inflation factor." % FootprintTypes.RADIUS)
        else:
            self.clearing_footprint_type = FootprintTypes.POINTS  # Temporary footprint type to prevent ValidationError
            self.clearing_robot_radius = clearing_robot_radius
            self.clearing_inflation_factor = clearing_inflation_factor
            self.clearing_footprint_type = clearing_footprint_type
        self.clearing_polygon = clearing_polygon

        self.planning_collision_model = planning_collision_model
        self.planning_footprint_type = planning_footprint_type
        self.planning_robot_radius = planning_robot_radius
        self.planning_inflation_factor = planning_inflation_factor

    @property
    def name(self):
        """Get the unique name of this configuration.

        :return: The robot configuration's unique name.
        """
        return self._get("name")

    @name.setter
    def name(self, name):
        """Set the unique name of this configuration.

        :param str name: The new name for this robot.
        :raises fetchcore.exceptions.ValidationError: Thrown if the new name is:

            - A non-string.
            - An empty string.
            - A string that does not contain only capital letters and underscores.
        """
        if isinstance(name, basestring):
            if not name:
                raise ValidationError("Name cannot be an empty string")
            if not re.match(CAPITAL_UNDERSCORE_PATTERN, name):
                raise ValidationError("Name %s does not match the pattern %s" % (name, REGEX_CAPITAL_NUMBER_UNDERSCORE))
            self._set("name", name)
        else:
            raise ValidationError("Name must be a string, not a %s" % type(name).__name__)

    @property
    def clearing_collision_model(self):
        """Get the clearing collision model type of the configuration.

        :return: The clearing collision model.
        """
        return self._get('clearing_collision_model')

    @clearing_collision_model.setter
    def clearing_collision_model(self, clearing_collision_model):
        """Set the collision model type of the configuration.

        :param str clearing_collision_model: The collision model.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
        """
        if isinstance(clearing_collision_model, basestring):
            if not clearing_collision_model:
                raise ValidationError("Clearing collision model cannot be empty.")
            self._set('clearing_collision_model', clearing_collision_model)
        else:
            raise ValidationError(
                "Clearing collision model must be a string, not a %s." % type(clearing_collision_model).__name__)

    @property
    def planning_collision_model(self):
        """Get the planning collision model type of the configuration.

        :return: The planning collision model.
        """
        return self._get('planning_collision_model')

    @planning_collision_model.setter
    def planning_collision_model(self, planning_collision_model):
        """Set the collision model type of the configuration.

        :param str planning_collision_model: The collision model.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
        """
        if isinstance(planning_collision_model, basestring):
            if not planning_collision_model:
                raise ValidationError("Planning collision model cannot be empty.")
            self._set('planning_collision_model', planning_collision_model)
        else:
            raise ValidationError(
                "Planning collision model must be a string, not a %s." % type(planning_collision_model).__name__)

    @property
    def clearing_robot_radius(self):
        """Get the robot's estimated radius for clearing.

        :return: The robot radius for clearing.
        """
        return self._get('clearing_robot_radius')

    @clearing_robot_radius.setter
    def clearing_robot_radius(self, clearing_robot_radius):
        """Set the robot's estimated radius for clearing.

        :param float clearing_robot_radius: The robot radius for clearing.
        :raise: fetchcore.exceptions.ValidationError: Thrown if clearing_robot_radius is:

          - not a finite non-negative number.
          - None while the clearing footprint type is 'radius'.
        """
        if clearing_robot_radius is None:
            if self.clearing_footprint_type == FootprintTypes.RADIUS:
                raise ValidationError("Clearing robot radius cannot be set to None if clearing footprint type is %s." %
                                      FootprintTypes.RADIUS)
            self._set('clearing_robot_radius', clearing_robot_radius)
        elif Number.is_real_number(clearing_robot_radius):
            if not Number.is_finite_non_negative(clearing_robot_radius):
                raise ValidationError("Robot radius must be a finite non-negative number (was given as %s)." %
                                      clearing_robot_radius)
            self._set('clearing_robot_radius', clearing_robot_radius)
        else:
            raise ValidationError("Clearing robot radius must be a real number (was given as %s)." %
                                  clearing_robot_radius)

    @property
    def planning_robot_radius(self):
        """Get the robot's estimated radius for planning.

        :return: The robot radius for planning.
        """
        return self._get('planning_robot_radius')

    @planning_robot_radius.setter
    def planning_robot_radius(self, planning_robot_radius):
        """Set the robot's estimated radius for planning.

        :param float planning_robot_radius: The robot radius for planning.
        :raise: fetchcore.exceptions.ValidationError: Thrown if planning_robot_radius is:

          - not a finite non-negative number.
          - None while the planning footprint type is 'radius'.
        """
        if planning_robot_radius is None:
            if self.planning_footprint_type == FootprintTypes.RADIUS:
                raise ValidationError("Planning robot radius cannot be set to None if planning footprint type is %s." %
                                      FootprintTypes.RADIUS)
            self._set('planning_robot_radius', planning_robot_radius)
        elif Number.is_real_number(planning_robot_radius):
            if not Number.is_finite_non_negative(planning_robot_radius):
                raise ValidationError("Planning robot radius must be a finite non-negative number (was given as %s)." %
                                      planning_robot_radius)
            self._set('planning_robot_radius', planning_robot_radius)
        else:
            raise ValidationError("Planning Robot radius must be a real number (was given as %s)." %
                                  planning_robot_radius)

    @property
    def clearing_inflation_factor(self):
        """Get the factor by which to inflate the robot's radius for clearing.

        :return: The inflation factor for clearing.
        """
        return self._get('clearing_inflation_factor')

    @clearing_inflation_factor.setter
    def clearing_inflation_factor(self, clearing_inflation_factor):
        """Set the factor by which to inflate the robot's radius for clearing.

        :param float clearing_inflation_factor: The inflation factor for clearing.
        :raise: fetchcore.exceptions.ValidationError: Thrown if clearing_inflation_factor is:

          - not a finite non-negative number.
          - None while the planning footprint type is 'radius'.
        """
        if clearing_inflation_factor is None:
            if self.clearing_footprint_type == FootprintTypes.RADIUS:
                raise ValidationError("Clearing robot radius cannot be set to None if planning footprint type is %s." %
                                      FootprintTypes.RADIUS)
            self._set('clearing_inflation_factor', clearing_inflation_factor)
        elif Number.is_real_number(clearing_inflation_factor):
            if not Number.is_finite_non_negative(clearing_inflation_factor):
                raise ValidationError("Clearing inflation factor must be a finite positive number (was given as %s)."
                                      % clearing_inflation_factor)
            self._set('clearing_inflation_factor', clearing_inflation_factor)
        else:
            raise ValidationError(
                "Clearing inflation factor must be a real number (was given as %s)." % clearing_inflation_factor)

    @property
    def planning_inflation_factor(self):
        """Get the factor by which to inflate the robot's radius for planning.

        :return: The inflation factor for planning.
        """
        return self._get('planning_inflation_factor')

    @planning_inflation_factor.setter
    def planning_inflation_factor(self, planning_inflation_factor):
        """Set the factor by which to inflate the robot's radius for planning.

        :param float planning_inflation_factor: The inflation factor for planning.
        :raise: fetchcore.exceptions.ValidationError: Thrown if planning_inflation_factor is:

          - not a finite non-negative number.
          - None while the planning footprint type is 'radius'.
        """
        if planning_inflation_factor is None:
            if self.planning_footprint_type == FootprintTypes.RADIUS:
                raise ValidationError("Planning robot radius cannot be set to None if planning footprint type is %s." %
                                      FootprintTypes.RADIUS)
            self._set('planning_inflation_factor', planning_inflation_factor)
        elif Number.is_real_number(planning_inflation_factor):
            if not Number.is_finite_non_negative(planning_inflation_factor):
                raise ValidationError("Planning inflation factor must be a finite positive number (was given as %s)."
                                      % planning_inflation_factor)
            self._set('planning_inflation_factor', planning_inflation_factor)
        else:
            raise ValidationError(
                "Planning inflation factor must be a real number (was given as %s)." % planning_inflation_factor)

    @property
    def clearing_footprint_type(self):
        """Get the type of clearing footprint described for this configuration.

        :return: The footprint type for clearing.
        """
        return self._get('clearing_footprint_type')

    @clearing_footprint_type.setter
    def clearing_footprint_type(self, clearing_footprint_type):
        """Set the type of clearing footprint described for this configuration.

        :param str clearing_footprint_type: The footprint type for clearing.
        :raise fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
        """
        if isinstance(clearing_footprint_type, basestring):
            if not clearing_footprint_type:
                raise ValidationError("Footprint type cannot be empty.")
            if clearing_footprint_type == FootprintTypes.RADIUS:
                try:
                    if self.clearing_robot_radius is None or self.clearing_inflation_factor is None:
                        raise ValidationError("Cannot set clearing footprint type to %s when either clearing robot "
                                              "radius or clearing inflation factor is None." % FootprintTypes.RADIUS)
                except UndefinedFieldError:
                    raise ValidationError("Cannot set clearing footprint type to %s when either clearing robot radius "
                                          "or clearing inflation factor is not set." % FootprintTypes.RADIUS)
            self._set('clearing_footprint_type', clearing_footprint_type)
        else:
            raise ValidationError("Clearing footprint type must be a string, not a %s." %
                                  type(clearing_footprint_type).__name__)

    @property
    def planning_footprint_type(self):
        """Get the type of planning footprint described for this configuration.

        :return: The footprint type for planning.
        """
        return self._get('planning_footprint_type')

    @planning_footprint_type.setter
    def planning_footprint_type(self, planning_footprint_type):
        """Set the type of planning footprint described for this configuration.

        :param str planning_footprint_type: The footprint type for planning.
        :raise fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
        """
        if isinstance(planning_footprint_type, basestring):
            if not planning_footprint_type:
                raise ValidationError("Footprint type cannot be empty.")
            if planning_footprint_type != FootprintTypes.RADIUS:
                raise ValidationError("Planning footprint type must be '%s'." % FootprintTypes.RADIUS)
            self._set('planning_footprint_type', planning_footprint_type)
        else:
            raise ValidationError("Planning footprint type must be a string, not a %s." %
                                  type(planning_footprint_type).__name__)

    @property
    def clearing_polygon(self):
        """Get the clearing polygon for this configuration.

        :return: The polygon for clearing.
        """
        return self._get('clearing_polygon')

    @clearing_polygon.setter
    def clearing_polygon(self, clearing_polygon):
        """Set the clearing polygon for this configuration.

        :param clearing_polygon: The polygon for clearing.
        :type: A list of three or more dicts, each containing number values for keys 'x' and 'y'
        """
        if clearing_polygon is None:
            self._set('clearing_polygon', clearing_polygon)
        elif isinstance(clearing_polygon, (list, tuple)):
            if len(clearing_polygon) < 3:
                raise ValidationError("Length of clearing polygon entry must be greater than or equal to 3 (given "
                                      "length was %s)." % len(clearing_polygon))
            for item in clearing_polygon:
                if not isinstance(item, dict):
                    raise ValidationError("Provided point '%s' for clearing polygon entry is a %s instead of a dict." %
                                          (item, type(item).__name__))
                if len(item) == 2 and all(key in item for key in ('x', 'y')) and \
                        all(Number.is_finite(num) and Number.is_real_number(num) for num in item.values()):
                    continue
                else:
                    raise ValidationError("Provided point %s for clearing polygon is not a length 2 dictionary "
                                          "containing real, finite numbers for 'x' and 'y'." % item)
            self._set('clearing_polygon', clearing_polygon)
        else:
            raise ValidationError("Clearing polygon must be a list, tuple, or None, not a %s." %
                                  type(clearing_polygon).__name__)
