# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard library
import re

# Fetchcore SDK Python
from fetchcore.definitions import REGEX_CAPITAL_UNDERSCORE, VERSION_PATTERN
from fetchcore.exceptions import ValidationError
from fetchcore.resources import TimestampedResource

VERSION_REGEX = re.compile(VERSION_PATTERN)
CAP_UND_REGEX = re.compile(REGEX_CAPITAL_UNDERSCORE)


class InstalledAction(TimestampedResource):
    """
    A class to represent a Fetchcore robot's installed action.

    :var str ~InstalledAction.pk: The corresponding field for this Resource's primary key.
    :var str ~InstalledAction.endpoint: The relative URL for this Resource's endpoint.
    """

    endpoint = 'robots/actions'
    pk = 'id'

    def __init__(self, id=None, action_definition=None, version=None, created=None, modified=None, **kwargs):
        """
        :param str id: The resource ID of this installed action.
        :param action_definition: The action definition associated with this installed action.
        :param version: The version of this installed action. Must be in MAJOR.MINOR.PATCH format.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        """
        super(InstalledAction, self).__init__(id=id, created=created, modified=modified, **kwargs)
        self.action_definition = action_definition
        self.version = version

    @property
    def action_definition(self):
        """Gets the action definition that is associated with this installed action.

        :return: The associated action definition.
        """
        return self._get("action_definition")

    @action_definition.setter
    def action_definition(self, value):
        """Sets the action definition that this action is associated with

        :param value: The associated action definition
        :raises ValidationError: if value is not a string
        :raises ValidationError: if value does not contain only capital letters and underscores
        """
        try:
            if CAP_UND_REGEX.match(value):
                self._set("action_definition", value)
            else:
                raise ValidationError("%s does not match the pattern %s" % (value, REGEX_CAPITAL_UNDERSCORE))
        except TypeError:
            raise ValidationError("Action definition must be a string")

    @property
    def version(self):
        """
        :return: The version number of the installed action.
        """
        return self._get("version")

    @version.setter
    def version(self, version):
        """
        :param version: The new version number for this installed action.
        :raise ValidationError: if value is not a string
        :raise ValidationError: if value does not match the version string pattern
        """
        try:
            if re.match(re.compile(VERSION_PATTERN), version):
                self._set("version", version)
            else:
                raise ValidationError("%s does not match the pattern %s"
                                      % (version, VERSION_PATTERN))
        except TypeError:
            raise ValidationError("Version must be a string (%s is %s)"
                                  % (version, type(version).__name__))
