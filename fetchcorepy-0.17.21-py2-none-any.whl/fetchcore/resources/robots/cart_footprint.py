# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Standard Library
import re

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.resources.robots import RobotFootprint
from fetchcore.exceptions import UndefinedFieldError, ValidationError
from fetchcore.definitions import CartCollisionModelTypes, FootprintTypes, REGEX_CAPITAL_NUMBER_UNDERSCORE, \
    ComponentShapes
from fetchcore.utils import Number

CAPITAL_UNDERSCORE_PATTERN = re.compile(REGEX_CAPITAL_NUMBER_UNDERSCORE)


class CartFootprint(RobotFootprint):
    """
    A class to represent a Fetchcore cart footprint document.
    """

    endpoint = 'robots/carts/footprints'
    pk = 'name'

    def __init__(self, id=None, name=None, clearing_collision_model=None, clearing_robot_radius=None,
                 clearing_inflation_factor=None, clearing_polygon=None, clearing_footprint_type=None,
                 planning_collision_model=None, planning_robot_radius=None, planning_inflation_factor=None,
                 planning_footprint_type=None, laser_clearing_collision_model=None, laser_clearing_robot_radius=None,
                 laser_clearing_inflation_factor=None, laser_clearing_footprint_type=None,
                 laser_clearing_components=None, created=None, modified=None, **kwargs):
        """
        :param int id: The resource ID of this robot configuration.

        :param str name: The unique name of this configuration.
        :param str clearing_collision_model: The collision model type of the robot configuration.
        :param float clearing_robot_radius: The robot's estimated radius used for clearing.
        :param float clearing_inflation_factor: The factor by which to inflate the robot's radius for clearing.
        :param clearing_polygon: A representation of the polygon used for representing a robot for clearing.
        :param str clearing_footprint_type: The type of clearing footprint described for this configuration.

        :param str planning_collision_model: The collision model type of the robot configuration.
        :param float planning_robot_radius: The robot's estimated radius used for planning.
        :param float planning_inflation_factor: The factor by which to inflate the robot's radius for planning.
        :param str planning_footprint_type: The type of planning footprint described for this configuration.

        :param created: The date and time this robot configuration was created.
        :param modified: The date and time this robot configuration was last modified.

        :type clearing_polygon: list, None
        :type created: str, ~datetime.datetime
        :type modified: str, ~datetime.datetime
        """
        super(CartFootprint, self).__init__(id=id, name=name, clearing_collision_model=clearing_collision_model,
                                            clearing_robot_radius=clearing_robot_radius,
                                            clearing_inflation_factor=clearing_inflation_factor,
                                            clearing_polygon=clearing_polygon,
                                            clearing_footprint_type=clearing_footprint_type,
                                            planning_collision_model=planning_collision_model,
                                            planning_robot_radius=planning_robot_radius,
                                            planning_inflation_factor=planning_inflation_factor,
                                            planning_footprint_type=planning_footprint_type, created=created,
                                            modified=modified, **kwargs)

        self.laser_clearing_collision_model = laser_clearing_collision_model
        self.laser_clearing_robot_radius = laser_clearing_robot_radius
        self.laser_clearing_inflation_factor = laser_clearing_inflation_factor
        self.laser_clearing_footprint_type = laser_clearing_footprint_type

        self._laser_clearing_components = []
        self.laser_clearing_components = laser_clearing_components

    @property
    def laser_clearing_collision_model(self):
        """Get the laser clearing collision model type of the configuration.

        :return: The laser clearing collision model.
        """
        return self._get('laser_clearing_collision_model')

    @laser_clearing_collision_model.setter
    def laser_clearing_collision_model(self, laser_clearing_collision_model):
        """Set the collision model type of the configuration.

        :param str laser_clearing_collision_model: The collision model.
        :raise: fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
          - a string not defined in CartCollisionModelTypes
        """
        if isinstance(laser_clearing_collision_model, basestring):
            if not laser_clearing_collision_model:
                raise ValidationError("Laser clearing collision model cannot be empty.")
            if laser_clearing_collision_model not in CartCollisionModelTypes:
                raise ValidationError("Laser clearing collision model is not a valid defined CartCollisionModelType.")
            self._set("laser_clearing_collision_model", laser_clearing_collision_model)
        else:
            raise ValidationError(
                "Laser clearing collision model must be a string, not a %s." % type(
                    laser_clearing_collision_model).__name__)

    @property
    def laser_clearing_robot_radius(self):
        """Get the robot's estimated radius for laser_clearing.

        :return: The robot radius for laser_clearing.
        """
        return self._get('laser_clearing_robot_radius')

    @laser_clearing_robot_radius.setter
    def laser_clearing_robot_radius(self, laser_clearing_robot_radius):
        """Set the robot's estimated radius for laser_clearing.

        :param float laser_clearing_robot_radius: The robot radius for laser_clearing.
        :raise: fetchcore.exceptions.ValidationError: Thrown if laser_clearing_robot_radius is:

          - not a finite non-negative number.
        """
        if laser_clearing_robot_radius is None:
            self._set('laser_clearing_robot_radius', laser_clearing_robot_radius)
        elif Number.is_real_number(laser_clearing_robot_radius):
            if not Number.is_finite_non_negative(laser_clearing_robot_radius):
                raise ValidationError("Robot radius must be a finite non-negative number (was given as %s)." %
                                      laser_clearing_robot_radius)
            self._set('laser_clearing_robot_radius', laser_clearing_robot_radius)
        else:
            raise ValidationError("Laser clearing robot radius must be a real number (was given as %s)." %
                                  laser_clearing_robot_radius)

    @property
    def laser_clearing_inflation_factor(self):
        """Get the factor by which to inflate the robot's radius for laser_clearing.

        :return: The inflation factor for laser_clearing.
        """
        return self._get('laser_clearing_inflation_factor')

    @laser_clearing_inflation_factor.setter
    def laser_clearing_inflation_factor(self, laser_clearing_inflation_factor):
        """Set the factor by which to inflate the robot's radius for laser_clearing.

        :param float laser_clearing_inflation_factor: The inflation factor for laser_clearing.
        :raise: fetchcore.exceptions.ValidationError: Thrown if laser_clearing_inflation_factor is:

          - not a finite non-negative number.
        """
        if laser_clearing_inflation_factor is None:
            self._set('laser_clearing_inflation_factor', laser_clearing_inflation_factor)
        elif Number.is_real_number(laser_clearing_inflation_factor):
            if not Number.is_finite_non_negative(laser_clearing_inflation_factor):
                raise ValidationError(
                    "Laser clearing inflation factor must be a finite positive number (was given as %s)."
                    % laser_clearing_inflation_factor)
            self._set('laser_clearing_inflation_factor', laser_clearing_inflation_factor)
        else:
            raise ValidationError(
                "Laser clearing inflation factor must be a real number (was given as %s)." %
                laser_clearing_inflation_factor)

    @property
    def laser_clearing_footprint_type(self):
        """Get the type of laser clearing footprint described for this configuration.

        :return: The footprint type for laser_clearing.
        """
        return self._get('laser_clearing_footprint_type')

    @laser_clearing_footprint_type.setter
    def laser_clearing_footprint_type(self, laser_clearing_footprint_type):
        """Set the type of laser clearing footprint described for this configuration.

        :param str laser_clearing_footprint_type: The footprint type for laser_clearing.
        :raise fetchcore.exceptions.ValidationError: Thrown if value is:

          - not a string
          - a string not defined in FootprintTypes
        """
        if isinstance(laser_clearing_footprint_type, basestring):
            if not laser_clearing_footprint_type:
                raise ValidationError("Footprint type cannot be empty.")
            if laser_clearing_footprint_type not in FootprintTypes:
                raise ValidationError("Provided laser clearing footprint type '%s' is not a valid FootprintType." %
                                      laser_clearing_footprint_type)
            self._set('laser_clearing_footprint_type', laser_clearing_footprint_type)
        else:
            raise ValidationError("Laser clearing footprint type must be a string, not a %s." %
                                  type(laser_clearing_footprint_type).__name__)

    def add_component(self, component, pos=None):
        """Add a component to specified position in this resource's internal list of components.

        If `pos` is not provided, the component will be added to the end of the list.

        :param component: The component to add
        :param pos: The position to add the component

        :type component: Component or dict
        """
        if pos is None:
            pos = len(self._laser_clearing_components)

        if isinstance(component, Component):
            self._laser_clearing_components.insert(pos, component)
        elif isinstance(component, dict):
            self._laser_clearing_components.insert(pos, Component.set_response(component))
        else:
            raise ValidationError(
                "Component should either be a Component or dict, not a %s." % type(component).__name__)

    @property
    def laser_clearing_components(self):
        """Get the laser clearing polygon for this configuration.

        :return: The polygon for laser_clearing.
        """
        return self._laser_clearing_components

    @laser_clearing_components.setter
    def laser_clearing_components(self, laser_clearing_components):
        """Set the laser clearing polygon for this configuration.

        :param laser_clearing_components: The polygon for laser_clearing.
        :type: A list of three or more dicts, each containing number values for keys 'x' and 'y'
        """
        if laser_clearing_components is None:
            self._set('laser_clearing_components', laser_clearing_components)
        elif isinstance(laser_clearing_components, (list, tuple)):
            original_components = self._laser_clearing_components[:]
            self._laser_clearing_components = []
            try:
                for item in laser_clearing_components:
                    self.add_component(item)
            except (AttributeError, ValidationError) as e:
                self._laser_clearing_components = original_components
                raise e
        else:
            raise ValidationError("Laser clearing polygon must be a list, tuple, or None, not a %s." %
                                  type(laser_clearing_components).__name__)

    def to_json_dict(self):
        """Gets the resource with queue_point documents as a json dictionary.

        :return: (dict) The JSON dictionary
        """
        # Get json dict from each action
        comp_json = [comp.to_json_dict() for comp in self._laser_clearing_components]
        self._set("laser_clearing_components", comp_json)
        return super(CartFootprint, self).to_json_dict()


class Component(TimestampedResource):
    def __init__(self, id=None, footprint=None, radius=None, shape_name=None, p1=None, p2=None, p3=None,
                 created=None, modified=None, **kwargs):
        super(Component, self).__init__(id=id, created=created, modified=modified, **kwargs)
        if footprint:
            self.footprint = footprint
        self.radius = radius
        self.shape_name = shape_name
        self.p1 = p1
        self.p2 = p2
        self.p3 = p3

    def _validate_point(self, point):
        """Validate a point entry.

        :returns: True if the point is a dictionary with exact keys 'x' and 'y' that are each real, finite numbers.
        """
        return isinstance(point, dict) and {'x', 'y'} == set(point.keys()) and all(
            Number.is_finite(num) and Number.is_real_number(num) for num in point.values()
        )

    @property
    def radius(self):
        """The radius of this component.

        :getter: Return the radius
        :setter: Set the radius for any real, finite N >= 0
        :type: float
        """
        return self._get('radius')

    @radius.setter
    def radius(self, value):
        if Number.is_real_number(value) and (Number.is_finite_positive(value) or value == 0):
            self._set('radius', value)
        else:
            raise ValidationError("Radius must be a real, finite, positive number, not '%s'" % value)

    @property
    def shape_name(self):
        """The shape name of this component.

        :getter: Return the shape name
        :setter: Set the shape name of this component, as long as it is defined in
         `fetchcore.definitions.ComponentShapes`
        :type: string
        """
        return self._get('shape_name')

    @shape_name.setter
    def shape_name(self, value):
        if not isinstance(value, basestring):
            raise ValidationError("Shape name must be a string, not a %s" % type(value).__name__)
        elif value not in ComponentShapes:
            raise ValidationError("Shape name '%s' is not a valid component shape." % value)
        else:
            self._set('shape_name', value)

    @property
    def footprint(self):
        """The associated footprint for this component.

        :getter: Return the footprint's ID
        :setter: Set the ID for the associated footprint, using either a valid ID or a CartFootprint resource with an
         assigned ID.
        :type: int
        """
        return self._get('footprint')

    @footprint.setter
    def footprint(self, value):
        if isinstance(value, CartFootprint):
            try:
                cart_id = CartFootprint.id
            except UndefinedFieldError:
                raise ValidationError("Provided footprint must possess an ID before being assigned.")
            self._set('footprint', cart_id)
        elif Number.is_finite_positive(value) and Number.is_integer(value):
            self._set('footprint', value)
        elif value is None:
            self._set('footprint', value)
        else:
            raise ValidationError("Footprint must be either an ID-assigned CartFootprint or a positive integer.")

    @property
    def p1(self):
        """The first point of this component.

        :getter: Return the representation of the first point
        :setter: Set the representation of the first point. It must contain only keys 'x' and 'y' bound to real,
         finite numbers.
        :type: dict
        """
        return self._get('p1')

    @p1.setter
    def p1(self, value):
        if self._validate_point(value):
            self._set('p1', value)
        else:
            raise ValidationError("Provided value for p1 '%s' is not a valid point." % str(value))

    @property
    def p2(self):
        """The second point of this component.

        :getter: Return the representation of the second point
        :setter: Set the representation of the second point. It must contain only keys 'x' and 'y' bound to real,
         finite numbers.
        :type: dict
        """
        return self._get('p2')

    @p2.setter
    def p2(self, value):
        if self._validate_point(value):
            self._set('p2', value)
        else:
            raise ValidationError("Provided value for p2 '%s' is not a valid point." % str(value))

    @property
    def p3(self):
        """The third point of this component.

        :getter: Return the representation of the third point
        :setter: Set the representation of the third point. It must contain only keys 'x' and 'y' bound to real,
         finite numbers.
        :type: dict
        """
        return self._get('p3')

    @p3.setter
    def p3(self, value):
        if self._validate_point(value):
            self._set('p3', value)
        else:
            raise ValidationError("Provided value for p3 '%s' is not a valid point." % str(value))
