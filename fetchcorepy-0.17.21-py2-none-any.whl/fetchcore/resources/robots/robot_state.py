# Copyright 2016 Fetch Robotics Inc.
# Author(s): Michael Hwang

# Fetchcore SDK Python
from fetchcore.resources import TimestampedResource
from fetchcore.exceptions import ValidationError
from fetchcore.utils import Pose, Timestamp


class RobotState(TimestampedResource):
    """
    A class to represent a Fetchcore robot document.

    :var stream: The data stream this resource should **publish** to.
    """

    endpoint = 'robots/states'
    pk = 'robot'
    stream = 'robot-states'

    def __init__(self,
                 id=None,
                 robot=None,
                 battery_level=None,
                 wifi_strength=None,
                 current_pose=None,
                 localization_weight=None,
                 last_deep_charge=None,
                 robot_battery_voltage=None,
                 created=None,
                 modified=None,
                 **kwargs):
        """
        :param id: The resource ID of this robot state.
        :param robot: The robot represented by this state.
        :param battery_level: The robot's current battery level.
        :param wifi_strength: The robot's current wifi signal strength.
        :param current_pose: The robot's current pose, in a dictionary with keys 'x', 'y', and 'theta'.
        :param last_deep_charge: The last time the robot deep charged.
        :param created: The date and time this resource was created.
        :param modified: The date and time this resource was last modified.
        """
        super(RobotState, self).__init__(created=created, modified=modified, **kwargs)
        if id:
            self._set("id", id)
        self.robot = robot
        self.battery_level = battery_level
        self.wifi_strength = wifi_strength
        self.current_pose = current_pose
        if robot_battery_voltage:
            self.robot_battery_voltage = robot_battery_voltage
        if localization_weight:
            self.localization_weight = localization_weight
        if last_deep_charge:
            self.last_deep_charge = last_deep_charge

    @property
    def id(self):
        """
        :returns: This robot resource's ID.
        """
        return self._get("id")

    @property
    def robot(self):
        """
        :return: The name of the robot this state represents.
        """
        return self._get("robot")

    @robot.setter
    def robot(self, value):
        """
        :param value: The new robot's name this state will represent.
        :raises ValidationError if value is not a string
        """
        if isinstance(value, basestring):
            self._set("robot", value)
        else:
            raise ValidationError("Robot name must be a string, not %s." % type(value).__name__)

    @property
    def battery_level(self):
        """
        :return: The robot's current battery level, in the interval [0.0, 1.0].
        """
        return self._get("battery_level")

    @battery_level.setter
    def battery_level(self, value):
        """
        :param value: The robot's new current battery level.
        :raise ValidationError if value is:
            - Not a number
            - A number not contained in the interval [0.0, 1.0]
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Battery level must be a number, not a %s." % type(value).__name__)

        if 0 <= value <= 1:
            self._set("battery_level", value)
        else:
            raise ValidationError("Battery level must be set between 0.0 and 1.0.")

    @property
    def wifi_strength(self):
        """
        :return: The robot's current wifi reception level, in the interval [0.0, 1.0].
        """
        return self._get("wifi_strength")

    @wifi_strength.setter
    def wifi_strength(self, value):
        """
        :param value: The robot's new current wifi reception level.
        :raise ValidationError if value is:
            - Not a number
            - A number not contained in the interval [0.0, 1.0]
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Wifi strength must be a number, not a %s." % type(value).__name__)

        if 0 <= value <= 1:
            self._set("wifi_strength", value)
        else:
            raise ValidationError("Wifi strength must be set between 0.0 and 1.0.")

    @property
    def current_pose(self):
        """
        :return: The robot's current pose, in a dictionary with keys 'x', 'y', and 'theta'
        """
        return self._get("current_pose")

    @property
    def current_pose_actual(self):
        """
        :return: The robot's current pose as a pose list [x, y, theta].
        """
        if self._get("current_pose") is None:
            return self._get("current_pose")
        else:
            curr_pose = self._get("current_pose")
            return [curr_pose['x'], curr_pose['y'], curr_pose['theta']]

    @current_pose.setter
    def current_pose(self, value):
        """
        :param value: The robot's new current pose, as a pose string or pose list.
        :raise ValidationError if value is not a pose dict or pose list
        """
        if value is None or value is "":
            self._set("current_pose", None)
        elif Pose.is_pose_dict(value):
            self._set("current_pose", value)
        elif Pose.is_pose(value):
            self._set("current_pose", {'x': value[0], 'y': value[1], 'theta': value[2]})
        else:
            raise ValidationError("%s is not a valid pose or pose string" % value)

    @property
    def localization_weight(self):
        """
        :return: The robot's last known AMCL weight of its last known position.
        """
        return self._get("localization_weight")

    @localization_weight.setter
    def localization_weight(self, value):
        """
        :param value: The robot's new recorded AMCL weight.
        :raise ValidationError if value is not a number.
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Localization weight must be a number, not a %s." % type(value).__name__)
        self._set("localization_weight", value)

    @property
    def robot_battery_voltage(self):
        """
        :return: The robot's last known battery voltage.
        """
        return self._get("robot_battery_voltage")

    @robot_battery_voltage.setter
    def robot_battery_voltage(self, value):
        """
        :param value: The robot's new recorded battery voltage.
        :raise ValidationError if value is not a number.
        """
        if isinstance(value, int) and not isinstance(value, bool):
            value = float(value)
        elif isinstance(value, float):
            pass
        else:
            raise ValidationError("Robot battery voltage must be a number, not a %s." % type(value).__name__)
        self._set("robot_battery_voltage", value)

    @property
    def last_deep_charge(self):
        """Gets the timestamp that indicates when the robot was lat charged

        :return: (datetime.datetime) The last_deep_charge timestamp
        """
        return self._get("last_deep_charge")

    @last_deep_charge.setter
    def last_deep_charge(self, last_deep_charge):
        """Sets the timestamp that indicates when the robot was last charged

        :param last_deep_charge: (string|datetime.datetime) A timestamp
        """
        if last_deep_charge is None:
            self._set("last_deep_charge", last_deep_charge)
        else:
            try:
                self._set("last_deep_charge", Timestamp.to_datetime(last_deep_charge))
            except (TypeError, ValueError) as e:
                raise ValidationError(e)

    def publish(self, client):
        """Publish this resource over a websocket connection.

        This first converts the resource into a JSON dictionary formatted into a channels payload, then sends it over
        the wire using the *send* method of the provided **client**.

        :param client: A websocket client with a valid *send* method.
        """
        data = {
            'stream': self.stream,
            'payload': {
                'action': 'update',
                'data': self.to_json_dict()
            }
        }

        return client.send(data)
